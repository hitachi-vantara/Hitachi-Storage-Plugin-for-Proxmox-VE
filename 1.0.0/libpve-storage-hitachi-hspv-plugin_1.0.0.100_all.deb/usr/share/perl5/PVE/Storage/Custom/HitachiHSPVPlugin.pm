####################################################
# PVE::Storage::Custom::HitachiHSPVPlugin package
####################################################
package PVE::Storage::Custom::HitachiHSPVPlugin {

    use strict;
    use warnings;
    use Scalar::Util qw(blessed);
    use List::Util qw(any);

    BEGIN {
        *Log:: = *HSPV::Log::;
        *Util:: = *HSPV::Util::;
        *Capacity:: = *HSPV::Util::Capacity;
        *BlockDevice:: = *HSPV::Util::BlockDevice::;
        *Context:: = *PVE::Storage::Custom::HitachiHSPVPlugin::Context::;
        *PersistentCache:: = *HSPV::PersistentCache::;
        *SC:: = *PVE::Storage::Custom::HitachiHSPVPlugin::StorageConfig::;
        *throw = \&HSPV::Util::throw;
    }

    use base qw(PVE::Storage::Plugin);

    #################
    # Constants
    #################

    use constant HSPV_PLUGIN_VERSION => '1.0.0.100';

    use constant PLUGIN_TYPE => "hitachi_hspv";

    use constant {
        LOG_DEBUG_FUNC   => 1,
        LOG_VERBOSE_FUNC => 2,
    };

    # This is the name header/separator that we use for all HSPV objects that
    # we can.
    use constant {
        HSPV_NAME_HEADER => 'HSPV:',
        MAX_NAME_LENGTH  => 32,
    };

    use constant MAX_VMID_LENGTH => 9;

    use constant PERSISTENT_CACHE_CACHING_CATEGORY => 'cache';

    use constant MIN_SUPPORTED_API_VERSION => 14;
    use constant MAX_SUPPORTED_API_VERSION => 15;

    use constant UDEV_SETTLE_TIMEOUT => 30;
    use constant CHECK_DISKFILE_TIMEOUT => 30;

    #######################
    # Proxmox Functionality
    #######################

    sub api {
        my $curver = PVE::Storage::APIVER();

        if($curver <= MIN_SUPPORTED_API_VERSION) {
            return MIN_SUPPORTED_API_VERSION;
        } elsif($curver >= MAX_SUPPORTED_API_VERSION) {
            return MAX_SUPPORTED_API_VERSION;
        }

        return $curver;
    }

    sub type {
        my $dflog = Log->function(LOG_VERBOSE_FUNC);
        return PLUGIN_TYPE;
    }

    sub plugindata {
        my $dflog = Log->function(LOG_VERBOSE_FUNC);
        return {
            content => [ { images => 1, rootdir => 1, none => 1 },
                        { images => 1, rootdir => 1 } ],
            format  => [ { raw => 1 }, 'raw' ],
            'sensitive-properties' => { hspv_password => 1 },
        };
    }

    sub properties {
        my $dflog = Log->function(LOG_VERBOSE_FUNC);
        return {
            hspv_address       => {
                description => 'Hitachi controller IP address or DNS name.',
                type        => 'string',
            },
            hspv_username       => {
                description => 'Storage username.',
                type        => 'string',
            },
            hspv_password       => {
                description => 'Storage password.',
                type        => 'string',
            },
            hspv_pool           => {
                description => 'The storage pool to use (name or #).',
                type        => 'string',
            },
            hspv_ports          => {
                description => 'Storage ports to use (comma-separated).',
                type        => 'string',
            },
            hspv_ldev_range     => {
                description => 'The LDEV range to use (start#-end#, in ' .
                               'decimal or LDEV format). If not provided, ' .
                               'the full LDEV range will be used.',
                type        => 'string',
            },
        };
    }

    sub options {
        my $dflog = Log->function(LOG_VERBOSE_FUNC);
        return {
            hspv_address    => { },
            hspv_username   => { },
            # This value is not really optional, but having it marked as both
            # required and sensitive forces you to fight proxmox to the death.
            # So, it's listed as optional, but our own code will validate it's
            # been provided.
            hspv_password   => { optional => 1 },
            hspv_pool       => { fixed => 1 }, # Cannot change the pool.
            hspv_ports      => { },
            hspv_ldev_range => { optional => 1 },
            nodes           => { optional => 1 },
            disable         => { optional => 1 },
            content         => { optional => 1 },
            format          => { optional => 1 },
            shared          => { optional => 1 },
        };
    }

    sub activate_storage {
        my ( $class, $storeid, $scfg, $cache ) = @_;
        SC::init_cfg($storeid, $scfg);
        my $flog = Log->function(LOG_VERBOSE_FUNC);

        # Do not remove as this needs to overwrite the default behavior.
        return;
    }

    sub deactivate_storage {
        my ($class, $storeid, $scfg, $cache) = @_;
        SC::init_cfg($storeid, $scfg);
        my $flog = Log->function();


        return;
    }

    # Status of storage pool.
    sub status {
        my ($class, $storeid, $scfg, $cache) = @_;
        SC::init_cfg($storeid, $scfg);
        my $dflog = Log->function(LOG_VERBOSE_FUNC);

        my $total = 0;
        my $free = 0;
        my $used = 0;
        my $active = 0;

        eval {
            my $context = $class->_get_context($storeid, $scfg, $cache);
            my $pool = $context->get_pool(1);

            $total = $pool->{total_capacity}->as_bytes();
            $free = $pool->{free_capacity}->as_bytes();
            $used = $pool->{used_capacity}->as_bytes();
            $active = 1;

            1;
        } or do {
            my $e = $@; # Copy exception

            # A HSPV::NotFoundException should set active to 0.
            # Other exceptions should re-throw.
            if(blessed($e) && $e->isa('HSPV::NotFoundException')) {
                # This is the default, but we'll be explicit here.
                $active = 0;
            } else {
                die $e; # Re-throw.
            }
        };

        return ($total, $free, $used, $active);
    }

    # Storage pool being added.
    sub on_add_hook {
        my ($class, $storeid, $scfg, %sensitive) = @_;
        my $dflog = Log->function();

        SC::log_storage_config($storeid, $scfg, 0);
        SC::log_storage_config($storeid, \%sensitive, 0, "SENSITIVE CONFIG");

        # Validate the given configuration on add.
        # This will "die" if the configuration is invalid.
        SC::validate_or_die($storeid, $scfg, \%sensitive);

        # Set our credentials.
        SC::set_credentials($storeid, $sensitive{hspv_password});

        # This will load our initial configuration and fully validate our
        # storage config against the storage.
        # The configuration will be written to a cache for quick loading
        # on subsequent calls.
        eval {
            $class->_create_context($storeid, $scfg);
            1;
        } or do {
            my $error = $@ || 'An unknown error occurred.';
            # Clean up the password if we failed to create our context.
            SC::destroy_credentials($storeid);
            throw $error;
        };

        return;
    }

    # Storage pool configuration update.
    sub on_update_hook_full {
        my ($class, $storeid, $scfg, $update, $delete, $sensitive) = @_;
        SC::init_cfg($storeid, $scfg);
        my $dflog = Log->function();

        # Log our potential changes.
        _log_on_update($storeid, $scfg, $update, $delete, $sensitive);

        # Check any parameters we've been given that need checking.
        _check_param_on_update($update, $delete, $sensitive);

        # update_state contains values that were alread queried by a prior
        # update.
        #
        my %update_state;

        # Note: It's possible for certain settings to succeed with effectively
        # irreversible changes, and something else fail later due to caching
        # and password saving, etc.
        # 1. Connection settings must always be independent.  Particularly
        # since the connection values may need to apply to the new changes.
        # (address, username, password - change together).
        # 2. Non-invasive (no changes other than storage.cfg which we don't
        # handle) must all go next.
        # (ldev range).
        # 3. Finally, only one of any other invasive change can also be
        # included.
        # (ports)
        my $connection_change = $update->{hspv_address} ||
                                $update->{hspv_username} ||
                                $sensitive->{hspv_password};
        my $ldev_change = $update->{hspv_ldev_range};
        my $port_change = $update->{hspv_ports};

        if($connection_change && ($port_change || $ldev_change)) {
            throw 'Connection settings must be changed separately from ' .
                  'other settings.';
        }

        # 1. Connection settings
        my $connection_update;
        if($connection_change) {
            Log::info('Attempting to update connection settings.');
            $connection_update = $class->_on_update_connection($storeid,
                $scfg, $update, $sensitive, \%update_state);
        }

        # 2. Non-invasive changes
        # (should never occur if there's connection settings).
        my $ldev_range_update;
        if($ldev_change || any { $_ eq 'hspv_ldev_range' } @$delete) {
            Log::info('Attempting to update LDEV range.');

            $ldev_range_update = $class->_on_update_ldev_range($storeid, $scfg,
                                                               $update,
                                                               !$ldev_change,
                                                               \%update_state);
        }

        # 3. Invasive changes.
        # (should never occur if there's connection settings, and only one
        # of these should ever be possible).
        my $port_update;
        if($port_change) {
            Log::info('Attempting to update ports.');
            $port_update = $class->_on_update_ports($storeid, $scfg, $update,
                                                    \%update_state);
        }

        if($connection_update) {
            Log::info('Updated connection settings.');
        }
        if($ldev_range_update) {
            Log::info('Updated LDEV range.');
        }
        if($port_update) {
            Log::info('Updated ports.');
        }

        return;
    }

    # Storage pool being deleted.
    sub on_delete_hook {
        my ($class, $storeid, $scfg) = @_;
        SC::init_cfg($storeid, $scfg);
        my $dflog = Log->function();

        SC::log_storage_config($storeid, $scfg, 0);

        my %cache;
        my $images = $class->list_images($storeid, $scfg, undef, undef,
                                         \%cache);
        my $img_count = @$images;
        throw "Storage pool still has $img_count image(s)!" if  @$images > 0;

        my $context = $class->_get_context($storeid, $scfg, \%cache);
        $context->kill_storage_pool();
        SC::destroy_credentials($storeid);

        return;
    }

    # Allocate volume.
    sub alloc_image {
        my ($class, $storeid, $scfg, $vmid, $fmt, $name, $size) = @_;
        SC::init_cfg($storeid, $scfg);
        my $dflog = Log->function();

        Log::info("Creating LDEV for $storeid and VM $vmid of size " .
                  "${size}KB and format '$fmt'.");

        # Validate no name was provided as we do not support it.
        throw "Custom names are not supported." if
                        (defined $name && length($name)>0);

        # Validate the format.
        throw "Unsupported format: '$fmt'." if $fmt ne 'raw';

        # Convert to MB from KB.
        my $capacity = Capacity->new($size, Util::SIZE_KB());
        if(!$capacity->aligned_mb()) {
            throw "The size (${size}KB) must be aligned to MB.";
        }

        # Create our name.
        my $ldev_name = $class->_format_ldev_name($storeid, $vmid);

        # Get our context and create our LDEV.
        my $context = $class->_get_context($storeid, $scfg);

        my $ldev = $context->create_virtual_ldev($capacity, $ldev_name);

        # Format our volname with the newly created LDEV.
        my $volname = $class->_format_volname($vmid,
                                              $context->serial(),
                                              $ldev);

        Log::info("Created LDEV $ldev for $storeid and VM $vmid of size " .
                  "$capacity with name '$ldev_name'. " .
                  "Volname: $volname");

        return $volname;
    }

    # Delete volume.
    sub free_image {
        my ($class, $storeid, $scfg, $volname, $isBase) = @_;
        SC::init_cfg($storeid, $scfg);
        my $dflog = Log->function();

        Log::info("Attempting to delete LDEV with volname '$volname'.");

        my ($vmid, $serial, $ldev_id) = $class->_parse_volname($volname);

        Log::debug("Deleting VMID: $vmid, Serial: $serial, LDEV: $ldev_id.");

        my $context = $class->_get_context($storeid, $scfg);

        # Validate that our volume is correct.
        # NOTE: deactivate_volume will do this for us, but since this is a
        # destructive operation it doesn't hurt to leave this here for
        # double validation (or if deactivate_volume changes for some reason).
        $class->_validate_volume($context, $volname);

        # We need to deactivate first.  In some situations the volume
        # will still be attached.
        # Example: If you resize with a size of 0, it attaches for
        # some unknown reason.
        $class->deactivate_volume($storeid, $scfg, $volname, undef);

        $class->_purge_naa_cache($serial, $ldev_id);

        $context->delete_ldev($ldev_id);
        return;
    }

    sub list_images {
        my ($class, $storeid, $scfg, $vmid, $vollist, $cache) = @_;
        SC::init_cfg($storeid, $scfg);
        my $dflog = Log->function();

        # If we have no VMID, we only want a partial format string that
        # will do a wider search.
        use constant ALLOW_PARTIAL_FORMAT => 1;

        my $name = $class->_format_ldev_name(
                                    $storeid, $vmid, ALLOW_PARTIAL_FORMAT);

        my $context = $class->_get_context($storeid, $scfg, $cache);
        my $ldevs = $context->find_ldevs($name, !defined $vmid);

        my @list;

        for my $ldev (@$ldevs) {

            my ($parsed_storeid, $parsed_vmid) =
                    $class->_parse_ldev_name($ldev->{name});
            my $volname = $class->_format_volname($parsed_vmid,
                        $context->serial(), $ldev->{id});
            my $volid = $class->_format_volid($parsed_storeid, $volname);

            my $info = {
                volid  => $volid,
                format => 'raw',
                size   => $ldev->{total_capacity}->as_bytes(),
                vmid   => $parsed_vmid,
                used   => $ldev->{used_capacity}->as_bytes(),
                serial => $context->serial(),
                ldev   => $ldev->{id},
            };

            push @list, $info;
        }

        my $print_vmid = $vmid // '';
        Log::debug("list_images[$storeid,$print_vmid]=" .
                   "items[@{[scalar @list]}].");

        return \@list;
    }

    # Get size information for the volume.
    sub volume_size_info {
        my ($class, $scfg, $storeid, $volname, $timeout) = @_;
        SC::init_cfg($storeid, $scfg);
        my $dflog = Log->function();

        my $ldev_id = $class->_parse_volname($volname);

        my $context = $class->_get_context($storeid, $scfg);
        my $ldev = $context->get_ldev($ldev_id);

        my $size = $ldev->{total_capacity}->as_bytes();
        my $used = $ldev->{used_capacity}->as_bytes();

        Log::debug("volume_size_info[$volname]=size[$size],used[$used].");

        return wantarray ? ($size, 'raw', $used, undef) : $size;
    }

    # Connect the volume to host group(s) and map them on the host.
    sub map_volume {
        my ($class, $storeid, $scfg, $volname, $snapname, $hints) = @_;
        SC::init_cfg($storeid, $scfg);
        my $dflog = Log->function();

        # Get context.
        my $context = $class->_get_context($storeid, $scfg);

        # Validate that our volume is correct.
        $class->_validate_volume($context, $volname);

        # check multipath requirement is satisfied or not.
        if ($context->is_multipath()) {
            if (!SC::satisfy_multipath_req($context)) {
                throw "Multipath(iSCSI/FC) is required but " .
                      "environment does not satisfy the requirement.";
            }
        }

        # Get our HBAs.
        my $hbas;
        if($context->is_fc()) {
            $hbas = BlockDevice::get_local_node_active_wwpns();
            if(!$hbas) {
                throw "Coult not find local node active WWPNs!";
            }
        } elsif($context->is_iscsi()) {
            $hbas = BlockDevice::get_local_node_iscsi_initiator_name();
            if(!$hbas) {
                throw "Could not find local node IQN!";
            }
        } else {
            my $protocol = $context->port_type();
            throw "Protocol $protocol is not supported.";
        }

        # Create connection.
        my (undef, $serial, $ldev_id) = $class->_parse_volname($volname);
        $context->create_connection($ldev_id, $hbas);

        # Do initial NAA discovery.
        my $naa = $class->_find_naa($serial, $ldev_id, $context);
        if(!defined $naa) {
            throw "Could not find NAA for LDEV $ldev_id.";
        }

        # Connect volume.
        # Establish OS-level sessions and scan for the block device (and
        # aggregate multipath if multiple ports are configured). This
        # must happen here so that the device path exists by the time
        # qemu_blockdev_options() is called.
        if($context->is_iscsi()) {
            $class->_map_volume_iscsi($context, $volname, $naa);
        } elsif($context->is_fc()) {
            $class->_map_volume_fc($context, $volname, $naa, $hbas);
        } else {
            my $protocol = $context->port_type();
            throw "Protocol $protocol is not supported.";
        }

        my ($path) = $class->path($scfg, $volname, $storeid, $snapname);
        return $path;
    }

    # Connect the volume to host group(s) and map them on the host.
    sub unmap_volume {
        my ($class, $storeid, $scfg, $volname, $snapname) = @_;
        SC::init_cfg($storeid, $scfg);
        my $dflog = Log->function();

        my (undef, $serial, $ldev_id) = $class->_parse_volname($volname);

        my $context = $class->_get_context($storeid, $scfg);

        # Validate that our volume is correct.
        $class->_validate_volume($context, $volname);

        my $naa = $class->_find_naa($serial, $ldev_id, $context);
        if(!defined $naa) {
            # We do not throw here as we need to deactivate when we delete.
            # If the NAA couldn't be retrieved for some real reason, we'll
            # probably get an error later on.
            Log::debug("Did not find NAA for LDEV $ldev_id, " .
                "skipping unmap for $volname.");
            return;
        } else {
            Log::debug("Found NAA($naa) for LDEV: $ldev_id. " .
                "Will do unmap for $volname.");
        }

        # Clean up OS-level block devices (SCSI device removal,
        # multipath map deletion) before removing the Hitachi API-side
        # connection, so the host sees no orphaned /dev/sdX entries.
        if($context->is_iscsi() || $context->is_fc()) {
            $class->_unmap_volume_scsi($context, $volname, $naa);
        } else {
            my $protocol = $context->port_type();
            throw "Protocol $protocol is not supported.";
        }

        $context->delete_connection($ldev_id);

        if($context->is_iscsi()) {
            # 1. Looks like unnessary to wait Storage cleanup done.
            # 2. If no active LUNs remain in this iSCSI session,
            #    logout the session and delete the local node record.
            $class->_delete_iscsi_session_and_node($context);
        }

        return 1;
    }

    # Connect the volume to host group(s) and map them on the host.
    sub activate_volume {
        my ($class, $storeid, $scfg, $volname, $snapname, $cache, $hints) = @_;
        SC::init_cfg($storeid, $scfg);
        my $dflog = Log->function();

        $class->map_volume($storeid, $scfg, $volname, $snapname,
                           $hints);
        return 1;
    }

    # Remove the volume from the host and disconnect from host group(s).
    sub deactivate_volume {
        my ($class, $storeid, $scfg, $volname, $snapname, $cache) = @_;
        SC::init_cfg($storeid, $scfg);
        my $dflog = Log->function();

        return $class->unmap_volume($storeid, $scfg, $volname, $snapname);
    }

    # Resize the volume.
    sub volume_resize {
        my ($class, $scfg, $storeid, $volname, $size, $running) = @_;
        SC::init_cfg($storeid, $scfg);
        my $dflog = Log->function();

        my $capacity = Capacity->new($size, Util::SIZE_B());
        if(!$capacity->aligned_mb()) {
            throw "The size (${size}B) must be aligned to MB.";
        }

        # The storage can handle resizing a connected volume fine, but
        # the proxmox tool does not handle this situation and errors out,
        # resulting in a larger volume with a failure attached.
        if($running) {
            throw "Running VM volumes cannot be resized.";
        }

        my $ldev_id = $class->_parse_volname($volname);

        my $context = $class->_get_context($storeid, $scfg);

        # Validate that our volume is correct.
        $class->_validate_volume($context, $volname);

        $context->resize_ldev($ldev_id, $capacity);

        Log::info("Resized LDEV $ldev_id to $capacity " .
                  "for $storeid. Volname: $volname");

        return;
    }

    sub create_base {
        my ($class, $storeid, $scfg, $volname) = @_;
        SC::init_cfg($storeid, $scfg);
        my $dflog = Log->function();
        return;
    }

    sub clone_image {
        my ($class, $scfg, $storeid, $volname, $vmid, $snap) = @_;
        SC::init_cfg($storeid, $scfg);
        my $dflog = Log->function();

        if(defined $snap) {
            throw "Snapshots are not supported.";
        }

        my $ldev_id = $class->_parse_volname($volname);

        # Create our name.
        my $ldev_name = $class->_format_ldev_name($storeid, $vmid);

        # Get our context and create our LDEV.
        my $context = $class->_get_context($storeid, $scfg);

        # Validate that our volume is correct.
        $class->_validate_volume($context, $volname);

        my $cloned_ldev_id = $context->clone_ldev($ldev_id, $ldev_name);

        # Format our volname with the newly created LDEV.
        my $clone_volname = $class->_format_volname($vmid,
                                              $context->serial(),
                                              $cloned_ldev_id);

        Log::info("Created LDEV $cloned_ldev_id (clone of $ldev_id) " .
                  "for $storeid and VM $vmid with name '$ldev_name'. " .
                  "Clone volname: $clone_volname");

        return $clone_volname;
    }

    # Determine the feature support of the volume.
    sub volume_has_feature {
        my ($class, $scfg, $feature, $storeid, $volname, $snapname,
            $running) = @_;
        SC::init_cfg($storeid, $scfg);
        my $dflog = Log->function();

        my $features = {
            snapshot => 0,
            clone => 1, # Linked clone
            template => 0,
            copy => 1, # Full clone
            sparseinit => 1,
            rename => 0,
        };

        return $features->{$feature};
    }

    # Parse the volume name.
    # See _parse_volname for an internal version with more info.
    sub parse_volname {
        my ($class, $volname) = @_;
        my $dflog = Log->function(LOG_VERBOSE_FUNC);

        my ($vmid, undef, undef) = $class->_parse_volname($volname);

        return ('images', '', $vmid, undef, undef, undef, 'raw');
    }

    # Return the filesystem path.
    sub filesystem_path {
        my ($class, $scfg, $volname, $snapname) = @_;
        SC::init_cfg(undef, $scfg);
        my $dflog = Log->function(LOG_VERBOSE_FUNC);

        if(defined $snapname) {
            throw "Snapshots are not supported.";
        }

        my ($vmid, $serial, $ldev_id) = $class->_parse_volname($volname);

        # Find our NAA.  Note that this will always only query the cache.
        my $naa = $class->_find_naa($serial, $ldev_id, undef);

        # Build path from NAA if we have one.
        my $path = '';
        if($naa) {
            if(Context::is_multipath_from_scfg($scfg)) {
                $path = $class->_format_multipath_filesystem_path($naa);
            } else {
                $path = $class->_format_filesystem_path($naa);
            }
        }
        if($path ne '') {
            Log::debug("Found filesystem_path for LDEV $ldev_id: $path");
        }

        return wantarray ? ($path, $vmid, 'images') : $path;
    }

    # Return blockdev options for QEMU.
    sub qemu_blockdev_options {
        my ($class, $scfg, $storeid, $volname, $machine_version, $options) = @_;
        SC::init_cfg($storeid, $scfg);
        my $dflog = Log->function();

        throw "Snapshots not supported." if $options->{'snapshot-name'};

        my $path = $class->filesystem_path($scfg, $volname, undef);
        if(!defined $path || $path eq '') {
            throw "Could not determine block device path for $volname.";
        }
        if(!-e $path) {
            throw "Block device '$path' does not exist for $volname. " .
                    "iSCSI session or device scan may have failed.";
        }

        Log::info("qemu_blockdev_options: using host_device '$path' " .
                    "for $volname");
        return {
            driver   => 'host_device',
            filename => $path,
        };
    }

    #######################
    # Infrastructure
    #######################

    # Validate that the volume is for the current storage and that
    # we actually own the volume (has the correct name with storeid and
    # vmid).
    sub _validate_volume {
        my ($class, $context, $volname) = @_;

        my $valid = 1;
        my ($vmid, $serial, $ldev_id) = $class->_parse_volname($volname);

        if($serial!=$context->serial()) {
            Log::error("Validating '$volname': Serial number does not match " .
                       "($serial!=${\$context->serial()})!");
            $valid = 0;
        }

        my $ldev;
        if($valid) {
            eval {
                $ldev = $context->get_ldev($ldev_id);
                1;
            } or do {
                my $e = $@; # Copy exception

                if(blessed($e) && $e->isa('HSPV::NotFoundException')) {
                    Log::error("Validating '$volname': LDEV does not exist.");
                    $valid = 0;
                } else {
                    die $e; # Re-throw.
                }
            };
        }

        if($valid) {
            my $name = $class->_format_ldev_name($context->storeid(), $vmid);
            if($ldev->{name} ne $name) {
                Log::error("Validating '$volname': LDEV name does not match " .
                           "expected name ('$ldev->{name}'!='$name')!");
                $valid = 0;
            }
        }

        if(!$valid) {
            throw "'$volname' is not a valid volume.";
        }
        return;
    }

    # Map a connected iSCSI volume to the host.
    sub _map_volume_iscsi {
        my ($class, $context, $volname, $naa) = @_;

        my $dflog = Log->function();

        my $path = $class->_format_filesystem_path($naa);
        Log::debug("_map_volume_iscsi: filesystem_path for $volname: $path");

        my $target_info = $context->get_iscsi_port_info();
        if(!defined $target_info || !@$target_info) {
            throw "Could not find iSCSI target info for this storage.";
        }

        # Ensure each target+portal has an active session.
        foreach my $target (@$target_info) {
            my $target_iqn = $target->{iqn};
            my $portal = $target->{ipv4_address};
            if(!defined $target_iqn || $target_iqn eq "" ||
                    !defined $portal || $portal eq "") {
                throw "Invalid iSCSI target info for this storage.";
            }

            my $port = $target->{tcp_port};
            if(defined $port) {
                $portal .= ":$port";
            }

            Log::info("iSCSI: Checking session for target $target_iqn" .
                       " at Portal: $portal.");

            if(!BlockDevice::iscsi_session_exists($target_iqn, $portal)) {
                BlockDevice::iscsi_discover($portal);
                if(!BlockDevice::iscsi_login($target_iqn, $portal)) {
                    throw "Failed iSCSI login for target '$target_iqn' at " .
                          "portal '$portal'.";
                }
            } elsif(!BlockDevice::iscsi_rescan($target_iqn, $portal)) {
                throw "Failed iSCSI rescan for target" .
                      " '$target_iqn' at portal '$portal'.";
            }
        }

        if(!BlockDevice::udev_settle(UDEV_SETTLE_TIMEOUT)) {
            Log::warning("udevadm settle failed after iSCSI rescan.");
        }

        # For multipath configurations, trigger multipath aggregation and
        # return the multipath device path instead of a single-path device.
        if($context->is_multipath()) {
            # Do multipath aggregation and return the multipath device path
            if(!BlockDevice::multipath_reload()) {
                Log::warning("multipath(S) reload failed; path may not be " .
                             "aggregated.");
            }
            if(!BlockDevice::udev_settle(UDEV_SETTLE_TIMEOUT)) {
                Log::warning("udevadm settle failed after multipath reload.");
            }

            my $mp_path = $class->_format_multipath_filesystem_path($naa);
            if(defined $mp_path) {
                if (Util::check_disk_file_exist($mp_path,
                        CHECK_DISKFILE_TIMEOUT)) {
                    Log::info("Multipath(S) path for $volname: $mp_path");
                    return $mp_path;
                } else {
                    Log::warning("Multipath(S) path '$mp_path' does not ".
                        "exist. Multipath device not found for $volname");
                }
            } else {
                Log::warning("Multipath(S) path '$mp_path' undefined.");
            }
        } else {
            # For single-path configurations, return the device path
            if(defined $path) {
                if (Util::check_disk_file_exist($path,
                        CHECK_DISKFILE_TIMEOUT)) {
                    Log::info("Path(S) for $volname: $path");
                    return $path;
                } else {
                    Log::warning("Path(S) '$path' does not exist.");
                }
            } else {
                Log::warning("Path(S) '$path' undefined.");
            }
        }

       return $path;
    }

    # Map a connected FC volume to the host.
    # $hbas: the local node's active WWPNs used for this connection.
    sub _map_volume_fc {
        my ($class, $context, $volname, $naa, $hbas) = @_;

        my $dflog = Log->function();

        my $path = $class->_format_filesystem_path($naa);
        Log::debug("_map_volume_fc: filesystem_path for $volname: $path. " .
                   "HBAs: @{[join(', ', @$hbas)]}");

        # Trigger a rescan on all local FC HBAs so the kernel discovers
        # the newly-mapped LUN.
        if(!BlockDevice::fc_rescan($hbas)) {
            throw "Failed FC rescan after LUN mapping.";
        }
        if(!BlockDevice::udev_settle(UDEV_SETTLE_TIMEOUT)) {
            Log::warning("udevadm settle failed after FC rescan.");
        }

        # For multipath configurations, trigger multipath aggregation and
        # return the multipath device path instead of a single-path device.
        if($context->is_multipath()) {
            # Do multipath aggregation and return the multipath device path
            if(!BlockDevice::multipath_reload()) {
                Log::warning("multipath(F) reload failed; path may not be " .
                             "aggregated.");
            }
            if(!BlockDevice::udev_settle(UDEV_SETTLE_TIMEOUT)) {
                Log::warning("udevadm settle failed after multipath reload.");
            }
            my $mp_path = $class->_format_multipath_filesystem_path($naa);
            if(defined $mp_path) {
                if (Util::check_disk_file_exist($mp_path,
                        CHECK_DISKFILE_TIMEOUT)) {
                    Log::info("Multipath(F) path for $volname: $mp_path");
                    return $mp_path;
                } else {
                    Log::warning("Multipath(F) path '$mp_path' does not " .
                        "exist. Multipath device not found for $volname." .
                        " May need trigger a Loop Initialization Protocol" .
                        " (LIP) on FC HBA card");
                    # Eg. echo "1" > /sys/class/fc_host/hostXYZ/issue_lip
                }
            } else {
                Log::warning("Multipath(F) path '$mp_path' undefined.");
            }
        } else {
            # For single-path configurations, return the device path
            if(defined $path) {
                if (Util::check_disk_file_exist($path,
                        CHECK_DISKFILE_TIMEOUT)) {
                    Log::info("Path(F) for $volname: $path");
                    return $path;
                } else {
                    Log::warning("Path(F) '$path' does not exist. " .
                        "May need trigger a Loop Initialization Protocol" .
                        " (LIP) on FC HBA card");
                    # Eg. echo "1" > /sys/class/fc_host/hostXYZ/issue_lip
                }
            } else {
                Log::warning("Path(F) '$path' undefined.");
            }
        }

        return undef;
    }

    # Unmap /dev/sdABC or /dev/dm-XYZ from Linux.
    sub _unmap_volume_scsi {
        my ($class, $context, $volname, $naa) = @_;

        my $dflog = Log->function();

        # Identify this volume's block devices by NAA so we touch nothing else.
        my ($vmid, $serial, $ldev_id) = $class->_parse_volname($volname);

        my $wwid = "3$naa";     # 3 + NAA

        if($context->is_multipath()) {
            # Collect the sdX slaves BEFORE removing the dm device, while the
            # sysfs slaves directory is still intact.
            my @slaves = BlockDevice::get_dm_slaves($wwid);
            Log::debug("_unmap_volume_scsi: multipath slaves for $wwid: " .
                       join(',', @slaves));

            # Remove only this volume's multipath map.  'multipathd del map'
            # is daemon-coordinated and leaves every other mpath device
            # untouched.
            if(!BlockDevice::multipath_del_map($wwid)) {
                Log::warning("_unmap_volume_scsi: could not remove mpath " .
                             "map $wwid; continuing with sdX cleanup.");
            }

            # Delete each sdX that was a slave of this map so no zombie
            # /dev/sdX entries remain.  The iSCSI session itself is NOT
            # logged out — other LUNs on the same target are still running.
            foreach my $dev (@slaves) {
                if(!BlockDevice::remove_dev_disk($dev)) {
                    Log::warning("_unmap_volume_scsi: failed to delete " .
                                 "SCSI device $dev.");
                }
            }
        } else {
            # Single-path: resolve the wwn symlink to the bare sdX name and
            # remove it via sysfs.
            my $wwn_path = $class->_format_filesystem_path($naa);
            my $dev = BlockDevice::resolve_block_device($wwn_path);
            if(defined $dev) {
                Log::debug("_unmap_volume_scsi: resolved block device".
                    " $wwn_path: $dev. wwid is: $wwid");
                if(!BlockDevice::remove_dev_disk($dev)) {
                    Log::warning("_unmap_volume_scsi: failed to delete " .
                                 "SCSI device $dev.");
                }
            } else {
                Log::warning("_unmap_volume_scsi: could not resolve block " .
                             "device for $wwn_path; may already be gone.");
            }
        }

        # Let udev process the removal events and clean up symlinks.
        if(!BlockDevice::udev_settle(UDEV_SETTLE_TIMEOUT)) {
            Log::warning("udevadm settle failed after block device cleanup.");
        }

        # NOTE: We deliberately do NOT log out the iSCSI session here.
        # Other LUNs on the same target IQN may still be in active use.
        return 1;
    }

    sub _delete_iscsi_session_and_node {
        my ($class, $context) = @_;
        my $dflog = Log->function();

        my $target_info;
        eval {
            $target_info = $context->get_iscsi_port_info();
            1;
        } or do {
            my $e = $@; # Copy exception

            if(blessed($e) && $e->isa('HSPV::NotFoundException')) {
                # We never created a server, and are likely being called
                # from free_image().
                # We can safely bail out.
                return;
            } else {
                die $e; # Re-throw.
            }
        };

        if(!defined $target_info || !@$target_info) {
            Log::info("Could not find iSCSI target info for this storage.");
            return;
        }

        foreach my $target (@$target_info) {
            my $target_iqn = $target->{iqn};
            my $portal = $target->{ipv4_address};
            if(!defined $target_iqn || $target_iqn eq "" ||
                    !defined $portal || $portal eq "") {
                next;
            }

            my $port = $target->{tcp_port};
            if(defined $port) {
                $portal .= ":$port";
            }

            BlockDevice::clean_iscsi_session_and_node($target_iqn, $portal);
        }
    }

    #######################
    # Helpers
    #######################

    # Get the context object.
    sub _get_context {
        my ($class, $storeid, $scfg, $cache, $is_first_create) = @_;

        if(defined $cache && defined $cache->{context}) {
            my $cache_context = $cache->{context};
            Log::verbose("Retrieved context from cache: $cache_context.");
            return $cache_context;
        }

        my $context = Context->new($storeid, $scfg, $is_first_create);
        if($is_first_create) {
            Log::info("Created new context: $context.");
        } else {
            Log::verbose("Initialized new context: $context.");
        }

        if(defined $cache) {
            $cache->{context} = $context;
        }
        return $context;
    }

    # Create the context object.
    # Only use this when ading a new storage pool.
    sub _create_context {
        my ($class, $storeid, $scfg) = @_;

        return $class->_get_context($storeid, $scfg, undef, 1);
    }

    use constant NAA_CACHE_CATEGORY => "naa_cache";

    sub _format_naa_cache_context {
        my ($class, $serial, $ldev_id) = @_;

        return "$serial-$ldev_id";
    }

    # Find the NAA for the given volume.
    # If the context is provided and the NAA is not in the cache, the NAA
    # will be looked up.  If the context is not provied, only the cache will
    # be used.
    sub _find_naa {
        my ($class, $serial, $ldev_id, $context) = @_;

        my $cache_context = $class->_format_naa_cache_context($serial,
                                                              $ldev_id);

        my %naa_cache;
        if(HSPV::PersistentCache::read_cache(NAA_CACHE_CATEGORY,
                                             $cache_context,
                                             \%naa_cache,
                                             0)) {
            if(defined $naa_cache{naa}) {
                Log::debug("Returning cached NAA for LDEV $ldev_id: " .
                           "$naa_cache{naa}");
                return $naa_cache{naa};
            }
        }

        if(!defined $context) {
            return;
        }

        my $naa = $context->get_ldev_naa($ldev_id);
        if(defined $naa) {
            Log::info("Found NAA for LDEV $ldev_id: $naa");
        } else {
            Log::error("Could not find NAA for LDEV $ldev_id.");
        }

        if(defined $naa) {
            my %naa_cache_write = (naa => $naa);
            my $untainted_context = Util::untaint($cache_context);
            HSPV::PersistentCache::write_cache(NAA_CACHE_CATEGORY,
                                               $untainted_context,
                                               \%naa_cache_write,
                                               0);
        }

        return $naa;
    }

    # Purge the NAA cache for the given serial/LDEV.
    # This should occur when we delete a volume.
    sub _purge_naa_cache {
        my ($class, $serial, $ldev_id) = @_;

        my $cache_context = $class->_format_naa_cache_context($serial,
                                                              $ldev_id);

        my $untainted_context = Util::untaint($cache_context);
        return HSPV::PersistentCache::delete_cache(
                                NAA_CACHE_CATEGORY,
                                $untainted_context);
    }

    # Format the LDEV name for a HSPV volume.
    # Format is "HSPV:{storeid}:{vmid}".
    #   $storeid: storage pool id
    #   $vmid: VM ID
    #   $allow_partial: true to allow a partial format for searching.
    #                   If $storeid is not included, $vmid will be ignored.
    sub _format_ldev_name {
        my ($class, $storeid, $vmid, $allow_partial) = @_;

        if(!$allow_partial) {
            if(!defined $storeid || !defined $vmid) {
                throw "Cannot format name without storeid and/or vmid.";
            }
        }

        my $format = "${\HSPV_NAME_HEADER}";
        if(defined $storeid) {
            $format .= "$storeid:";

            if(defined $vmid) {
                $format .= $vmid;
            }
        }

        return $format;
    }

    # Parse the LDEV name for a HSPV volume.
    sub _parse_ldev_name {
        my ($class, $name) = @_;

        my $hdr = HSPV_NAME_HEADER;
        if($name =~ m/^$hdr(\S+):(\d+)$/) {
            my $storeid = $1;
            my $vmid = $2;
            return $storeid, $vmid;
        }

        throw "Invalid name identifier: '$name'.";
    }

    # Format the volume name.
    # Format is "{vmid}/vm-{serial}-{ldev}".
    sub _format_volname {
        my ($class, $vmid, $serial, $ldev) = @_;

        return "$vmid/vm-$serial-$ldev";
    }

    # Format a volid, which is the storeid separated by a colon with the
    # volname.
    sub _format_volid {
        my ($class, $storeid, $volname) = @_;

        return "$storeid:$volname";
    }

    # Internal version that reports on the parts that are not static/undef.
    # If an array is requested, the values returned are VMID, SERIAL, LDEV.
    # If an array is not requested, this returns the LDEV.
    sub _parse_volname {
        my ($class, $volname) = @_;

        if($volname =~ m/^(\d+)\/vm-(\d+)-(\d+)$/) {
            my $vmid = $1;
            my $serial = $2;
            my $ldev = $3;

            return wantarray ? ($vmid, $serial, $ldev) : $ldev;
        }

       throw "Invalid volname: '$volname'.";
    }

    # Format a non-multipath filesystem path.
    sub _format_filesystem_path {
        my ($class, $naa) = @_;

        my $untainted_naa = Util::untaint($naa);
        return "/dev/disk/by-id/wwn-0x$untainted_naa";
    }

    # Get the multipath device path for a volume using the given NAA.
    # The multipath WWID is the NAA with a leading '3' (NAA type 3), which
    # maps to /dev/disk/by-id/dm-uuid-mpath-3<naa>.
    sub _format_multipath_filesystem_path {
        my ($class, $naa) = @_;

        my $untainted_naa = Util::untaint($naa);
        return "/dev/disk/by-id/dm-uuid-mpath-3$untainted_naa";
    }

    # Log information coming into on_update_hook_full
    sub _log_on_update {
        my ($storeid, $scfg, $update, $delete, $sensitive) = @_;

        SC::log_storage_config($storeid, $scfg, 0);
        if(defined $update) {
            SC::log_storage_config($storeid, $update, 0, 'CONFIG UPDATE');
        }
        if(defined $sensitive && %$sensitive) {
            SC::log_storage_config($storeid, $sensitive, 0,
                                   'SENSITIVE CONFIG UPDATE');
        }
        if(defined $delete) {
            Log::info("DELETE CONFIG: storeid = $storeid");
            for my $item (@$delete) {
                Log::info("DELETE CONFIG: $item");
            }
        }
    }

    # Check parameter values for on_update_hook_full.
    # This only checks the input, not whether or not it can be set
    # in accordance with the storage state.
    sub _check_param_on_update {
        my ($update, $delete, $sensitive) = @_;

        # LDEV range must be parsable.
        # Note: We always allow deleting the LDEV range since no range
        # equals the entire range, which is a legal change.
        if(defined $update->{hspv_ldev_range}) {
            SC::validate_ldev_range_or_die($update->{hspv_ldev_range});
        }

        # Ports must be parsable.
        if(defined $update->{hspv_ports}) {
            SC::validate_ports_or_die($update->{hspv_ports});
        }

        # Address, username, and password must not be empty.
        if(defined $update->{hspv_address} &&
                !length($update->{hspv_address})) {
            throw "The address must not be empty.";
        }
        if(defined $update->{hspv_username} &&
                !length($update->{hspv_username})) {
            throw "The username must not be empty.";
        }
        if(defined $sensitive->{hspv_password} &&
                !length($sensitive->{hspv_password})) {
            throw "The password must not be empty.";
        }

        # Password cannot be removed despite being optional.
        if(defined $delete && any { $_ eq "hspv_password" } @$delete ) {
            throw "The storage password may not be removed.";
        }
    }

    sub _on_update_init {
        my ($class, $storeid, $scfg, $update_state, $want_ldevs) = @_;

        $update_state->{context} = $class->_get_context($storeid, $scfg) if
            !defined $update_state->{context};

        if($want_ldevs) {
            $update_state->{ldevs} = $update_state->{context}->find_ldevs(
                    $class->_format_ldev_name($storeid, undef,
                    ALLOW_PARTIAL_FORMAT), 1) if
                !defined $update_state->{ldevs};
        }

        return;
    }

    # Called to update connection settings from on_update_hook_full.
    sub _on_update_connection {
        my ($class, $storeid, $scfg, $update, $sensitive, $update_state) = @_;

        $class->_on_update_init($storeid, $scfg, $update_state, 0);

        my $existing_address = SC::address($scfg);
        my $existing_username = SC::username($scfg);
        my $existing_password = SC::load_credentials($storeid);

        my $address = $update->{hspv_address} // $existing_address;
        my $username = $update->{hspv_username} // $existing_username;
        my $password = $sensitive->{hspv_password} // $existing_password;

        # If nothing has changed, bail out.
        if($address eq $existing_address && $username eq $existing_username &&
                $password eq $existing_password) {
            Log::info('New connection settings match existing settings.');
            return;
        }

        if(!$update_state->{context}->check_storage_connection_config_change(
                $address, $username, $password)) {
            throw 'The storage for the given updated configuration does not ' .
                  'match the existing storage.';
        }

        if(defined $sensitive->{hspv_password}) {
            SC::set_credentials($storeid, $sensitive->{hspv_password});
        }
        return 1;
    }

    # Called to update the LDEV range from on_update_hook_full.
    sub _on_update_ldev_range {
        my ($class, $storeid, $scfg, $update, $deleted, $update_state) = @_;

        # If we're deleting, we only need to check if we already didn't
        # have a range since that change is always legal.
        if($deleted) {
            if(!defined SC::ldev_range($scfg)) {
                Log::info('new LDEV range settings match existing ' .
                          'settings.');
                return;
            }

            # We can always allow the full range.
            return 1;
        }

        $class->_on_update_init($storeid, $scfg, $update_state, 1);

        my ($existing_start, $existing_end) = SC::ldev_range($scfg);
        my ($start, $end) = SC::ldev_range($update);

        # If nothing has changed, bail out.
        # We don't need to check $existing_end as they'll both either
        # be undef or have values.
        # If we get to here, the new range will not be undef.
        if(defined $existing_start && $start==$existing_start &&
                $end==$existing_end) {
            Log::info('New LDEV range settings match existing settings.');
            return;
        }

        # If any of our LDEVs are out of range, we need to bail out.
        for my $ldev (@{ $update_state->{ldevs} }) {
            if($ldev->{id}<$start || $ldev->{id}>$end) {
                throw 'The LDEV range could not be updated as it does not ' .
                      'include the full range of LDEVs currently being used ' .
                      'by this storage pool.'
            }
        }

        return 1;
    }

    # Called to update ports from on_update_hook_full.
    sub _on_update_ports {
        my ($class, $storeid, $scfg, $update, $update_state) = @_;

        $class->_on_update_init($storeid, $scfg, $update_state, 1);

        my $existing_ports = SC::ports($scfg);
        my $ports = SC::ports($update);

        # If nothing has changed, bail out.
        # If our lengths do not match, we're not matching.
        if(@$ports == @$existing_ports) {
            # Both arrays will be sorted, so we can just compare sequentially.
            my $mismatch;
            for my $i (0 .. $#$ports) {
                if($ports->[$i] ne $existing_ports->[$i]) {
                    $mismatch = 1;
                    last;
                }
            }

            if(!$mismatch) {
                Log::info('New port settings match existing settings.');
                return;
            }
        }

        # If any of our LDEVs are on ports, we need to bail out.
        for my $ldev (@{ $update_state->{ldevs} }) {
            # TODO: For NVMe we'll have to use the non-admin query to
            # figure this out.
            if($ldev->{is_on_port}) {
                throw 'To change ports, no LDEVs currently being used by ' .
                      'this storage pool may be on a port.';
            }

        }

        $update_state->{context}->change_ports($ports);
        return 1;
    }

}

####################################################
# PVE::Storage::Custom::HitachiHSPVPlugin::Context package
####################################################

package PVE::Storage::Custom::HitachiHSPVPlugin::Context {

    use strict;
    use warnings;
    use List::Util qw(any);

    BEGIN {
        *Log:: = *HSPV::Log::;
        *Util:: = *HSPV::Util::;
        *Capacity:: = *HSPV::Util::Capacity;
        *Init:: =
            *PVE::Storage::Custom::HitachiHSPVPlugin::Context::Init::;
        *ApiClient:: = *HSPV::ApiClient::;
        *ApiClientAdmin:: = *HSPV::ApiClientAdmin::;
        *SC:: = *PVE::Storage::Custom::HitachiHSPVPlugin::StorageConfig::;
        *ServerConnector:: =
            *PVE::Storage::Custom::HitachiHSPVPlugin::Connector::ServerConnector::;
        *HostGroupConnector:: =
            *PVE::Storage::Custom::HitachiHSPVPlugin::Connector::HostGroupConnector::;
        *NvmSubsystemConnector:: =
            *PVE::Storage::Custom::HitachiHSPVPlugin::Connector::NvmSubsystemConnector::;
        *throw = \&HSPV::Util::throw;
    }

    # This will use to_string() as a string conversion.
    use overload (
        '""'     => \&to_string,
        fallback => 1,
    );

    use constant {
        _PORT_TYPE_ISCSI    => 'iSCSI',
        _PORT_TYPE_FC       => 'FC',
        _PORT_TYPE_NVME_TCP => 'NVME_TCP',
        _PORT_TYPE_NVME_FC  => 'NVME_FC',
    };

    use constant {
        _STORAGE_NOT_SUPPORTED_MESSAGE =>
            "This storage is not currently supported.",
        _OPERATION_NOT_SUPPORTED_MESSAGE =>
            "This operation is not currently supported.",
    };

    use constant _PERSISTENT_CACHE_STORAGE_STATE_CATEGORY => "state";

    use constant _MANAGED_DRS_PARENT_NAME => "HSPV:VCP";

    use constant VCP_DELETE_LOCK_TIMEOUT => 600;

    ################
    # Creation & infrastructure.
    ################

    # Create the API client and connect to the storage if there is no token
    # in the cache and credentials have been provided.
    # If the username or password are undef, this class will be created as
    # a non-auth only class - don't do this (will likely just die on first
    # call).
    # If $is_new_storage_pool is true, this class will also initialize related
    # objects on the storage.
    sub new {
        my ($class, $storeid, $scfg, $is_new_storage_pool) = @_;

        if($is_new_storage_pool) {
            Log::debug("Creating first new context for $storeid.");
        } else {
            Log::verbose("Initializing context for $storeid.");
        }

        my %scfg_copy = %$scfg;

        my $api;
        my $state;

        if(!$is_new_storage_pool) {
            $state = Init::_load_storage_state_from_cache($storeid);
        }

        if(!defined $state) {
            $api = _create_api_client($storeid, $scfg, 0);

            # If we don't have a state stored, or we're a new pool,
            # query the storage and update our API to admin if we have it.
            my $storage = $api->get_storage();
            if(Init::_has_admin_api($storage->{storage_id})) {
                # We have admin, so upgrade our client.
                $api = _create_api_client($storeid, $scfg, 1);
            }

            # Build our storage state. This will also cache it.
            $state = Init::_build_storage_state($storeid, $scfg, $api,
                                               $storage, $is_new_storage_pool);
        } else {
            $api = _create_api_client($storeid, $scfg, $state->{has_admin});
        }

        my $ports = SC::ports($scfg);

        my $connector = _create_connector($storeid, $state->{serial}, $ports,
            SC::hmo($scfg), $state->{port_type}, $api, $is_new_storage_pool);

        my $self = {
            _storeid        => $storeid,
            _scfg           => \%scfg_copy,
            _api            => $api,
            _storage_state  => $state,
            _ports          => $ports,
            _connector      => $connector,
        };

        return bless $self, $class;
    }

    # Generally this should not be used directly.  It may be used only when
    # we don't have the necessary information to create a full context.
    # Currently, this means only in filesystem_path().
    sub _create_api_client {
        my ($storeid, $scfg, $create_admin) = @_;

        return _create_api_client_raw(SC::address($scfg),
                                      SC::username($scfg),
                                      SC::load_credentials($storeid),
                                      $create_admin);
    }

    # Create an API client with the raw parameters needed.
    sub _create_api_client_raw {
        my ($address, $username, $password, $create_admin) = @_;

        if($create_admin) {
            return ApiClientAdmin->new($address,
                                       $username,
                                       $password);
        } else {
            return ApiClient->new($address,
                                  $username,
                                  $password);
        }
    }

    sub _create_connector {
        my ($storeid, $serial, $ports, $hmo, $port_type, $api,
            $is_new_storage_pool) = @_;

        my $connector;
        if($port_type eq _PORT_TYPE_ISCSI || $port_type eq _PORT_TYPE_FC) {
            if($api->has_server_support()) {
                $connector = ServerConnector->new($storeid, $serial, $ports,
                    $api, $hmo, $port_type eq _PORT_TYPE_ISCSI);
            } else {
                $connector = HostGroupConnector->new($storeid, $serial, $ports,
                    $api);
            }
        } elsif($port_type eq _PORT_TYPE_NVME_TCP ||
                  $port_type eq _PORT_TYPE_NVME_FC) {
            $connector = NvmSubsystemConnector->new($storeid, $serial, $ports,
                                                    $api);
        } else {
            throw "Unsupported protocol found: $port_type.";
        }

        if($is_new_storage_pool) {
            $connector->on_create_storage_pool();
        }

        return $connector;
    }

    sub is_multipath_from_scfg {
        my ($scfg) = @_;

        my $ports = SC::ports($scfg);
        return @$ports>1;
    }

    # Convert this object to a string.
    sub to_string {
        my ($class) = @_;

        my $storeid = $class->storeid();
        my $serial = $class->serial();
        my $model = $class->model();
        my $port_type = $class->port_type();
        my $is_iscsi = $class->is_iscsi();
        my $is_fc = $class->is_fc();
        my $is_nvme_tcp = $class->is_nvme_tcp();
        my $is_nvme_fc = $class->is_nvme_fc();
        my $pool = $class->pool_id();

        return "Context=$storeid\{serial[$serial],model[$model], " .
               "port_type[$port_type],is_iscsi[$is_iscsi],is_fc[$is_fc]," .
               "is_nvme_tcp[$is_nvme_tcp],is_nvme_fc[$is_nvme_fc]pool[$pool]}";
    }

    ####################################################
    # PVE::Storage::Custom::HitachiHSPVPlugin::Context::Init package
    ####################################################

    # This package is for initialization code that is outside of the class
    # itself.

    package PVE::Storage::Custom::HitachiHSPVPlugin::Context::Init {
        use strict;
        use warnings;
        use List::Util qw(any);

        BEGIN {
            *Log:: = *HSPV::Log::;
            *Util:: = *HSPV::Util::;
            *Context:: =
                *PVE::Storage::Custom::HitachiHSPVPlugin::Context::;
            *ApiClient:: = *HSPV::ApiClient::;
            *throw = \&HSPV::Util::throw;
        }

        # Load the storage state from the cache.
        # If it could not be loaded, or the cache was invalid,
        # this will return undef.
        sub _load_storage_state_from_cache {
            my ($storeid) = @_;

            my %storage_state;
            if(!HSPV::PersistentCache::read_cache(
                        Context::_PERSISTENT_CACHE_STORAGE_STATE_CATEGORY(),
                        $storeid, \%storage_state, 0) ||
                    !_validate_storage_state(\%storage_state)) {
                return undef;
            }

            return \%storage_state;
        }

        # Get the state of the storage based on the configuration.
        # This comes from the persistent cache or is generated if the
        # persistent cache does not have the data or could not be read.
        # This will retrieve:
        #   - serial
        #   - model
        #   - storage_id
        #   - port_type
        #   - is_drs
        #   - has_admin
        #   - pool
        # If $is_new_storage_pool is true, we will guarantee that the pool
        # exists even if it's a number.
        sub _build_storage_state {
            my ($storeid, $scfg, $api, $storage, $is_new_storage_pool) = @_;

            Log::info("Building storage state & caching.");

            my %storage_state;

            my $ctl_micro = "";
            if(defined $storage->{ctl1_micro}) {
                $ctl_micro .= ", CTL1 Micro[$storage->{ctl1_micro}]";
            }
            if(defined $storage->{ctl2_micro}) {
                $ctl_micro .= ", CTL2 Micro[$storage->{ctl2_micro}]";
            }
            Log::info("Found storage: Serial[$storage->{serial}], " .
                    "Model[$storage->{model}], " .
                    "ID[$storage->{storage_id}], " .
                    "Micro[$storage->{dkc_micro}]" .
                    "$ctl_micro.");

            $storage_state{serial} = $storage->{serial};
            $storage_state{model} = $storage->{model};
            $storage_state{storage_id} = $storage->{storage_id};

            # Die if storage device is not supported.
            if(!_is_supported_storage($storage->{storage_id})) {
                throw Context::_STORAGE_NOT_SUPPORTED_MESSAGE();
            }

            my $has_admin = _has_admin_api($storage->{storage_id});
            $storage_state{has_admin} = $has_admin;
            $storage_state{is_drs} = _requires_drs($storage->{storage_id});

            # _validate_ports_and_find_port_type() will die if the port
            # configuration is invalid.
            $storage_state{port_type} =
                _validate_ports_and_find_port_type(SC::ports($scfg), $api);

            # _find_pool_id() will die if the pool does not exist.
            $storage_state{pool} = _find_pool_id($scfg, $api,
                                                 $is_new_storage_pool);

            # Write our cache.
            HSPV::PersistentCache::write_cache(
                    Context::_PERSISTENT_CACHE_STORAGE_STATE_CATEGORY(),
                    $storeid, \%storage_state, 0);

            return \%storage_state;
        }

        # Make sure the storage state has the members we expect.  If it does
        # not, we need to rebuild it.
        sub _validate_storage_state {
            my ($storage_state) = @_;

            my $good_state = defined $storage_state->{has_admin} &&
                defined $storage_state->{is_drs} &&
                defined $storage_state->{pool} &&
                defined $storage_state->{port_type} &&
                ($storage_state->{port_type} eq Context::_PORT_TYPE_ISCSI() ||
                 $storage_state->{port_type} eq Context::_PORT_TYPE_FC()) &&
                defined $storage_state->{model} &&
                defined $storage_state->{serial};

            if(!$good_state) {
                Log::error("Storage state cache found to be in invalid " .
                           "state.");
            }

            return $good_state;
        }

        # Determine if the storage type is B20.
        sub _is_b20 {
            my ($storage_id) = @_;

            use constant {
                B20_STORAGE_ID_HEADER => "A34000",
            };
            return Util::starts_with($storage_id, B20_STORAGE_ID_HEADER);
        }

        # Determine if the storage type is B85.
        sub _is_b85 {
            my ($storage_id) = @_;

            use constant {
                B85_STORAGE_ID_HEADER => "A00000",
            };
            return Util::starts_with($storage_id, B85_STORAGE_ID_HEADER);
        }

        # Determine if the storage has admin API.
        sub _has_admin_api {
            my ($storage_id) = @_;

            return _is_b20($storage_id) || _is_b85($storage_id);
        }

        # Determine if the storage requires DRS.
        sub _requires_drs {
            my ($storage_id) = @_;

            return _is_b20($storage_id) || _is_b85($storage_id);
        }

        # Determine if the storage is supported.
        sub _is_supported_storage {
            my ($storage_id) = @_;

            return _is_b20($storage_id) || _is_b85($storage_id);
        }

        # Determine if the port protocol is supported.
        sub _is_supported_port_protocol {
            my ($protocol) = @_;

            return $protocol eq Context::_PORT_TYPE_ISCSI() ||
                   $protocol eq Context::_PORT_TYPE_FC();
        }

        # Find the port type and die if more than one port type is represented
        # by the ports, we have invalid ports, not found ports, etc.
        sub _validate_ports_and_find_port_type {
            my ($configured_ports, $api) = @_;

            my $all_ports = $api->get_ports();

            use constant TARGET_ATTR => 'TAR';

            my %port_hash;
            foreach my $port (@$all_ports) {
                my $id = $port->{port};
                $port_hash{$id} = {};
                $port_hash{$id}->{protocol} = $port->{protocol};
                $port_hash{$id}->{security} = $port->{security};
                $port_hash{$id}->{is_tar} =
                    any { $_ eq TARGET_ATTR } @{ $port->{attributes} };
                $port_hash{$id}->{has_ip} = defined $port->{ipv4_address};
            }

            my $protocol;
            foreach my $port (@$configured_ports) {
                if(!defined $port_hash{$port}) {
                    throw "Port $port does not exist.";
                }
                my $check_protocol = $port_hash{$port}->{protocol};
                if(!_is_supported_port_protocol($check_protocol)) {
                    throw "Port $port protocol $check_protocol is " .
                        "not supported.";
                }
                if(defined $protocol && $protocol ne $check_protocol) {
                    throw "All port protocols must match.";
                }
                if(!$port_hash{$port}->{security}) {
                    throw "Port security must be enabled for all ports.";
                }
                if(!$port_hash{$port}->{is_tar}) {
                    throw "All ports must have the target attribute.";
                }
                if($check_protocol eq Context::_PORT_TYPE_ISCSI() &&
                        !$port_hash{$port}->{has_ip}) {

                    if(!$api->has_ip_info_for_all_ports_query()) {
                        # TODO: Must query each iSCSI port for IP address as
                        # the underlying API does not support returning it
                        # with all ports.
                        throw "This storage is not supported."
                    }

                    throw "All iSCSI ports must be configured with an IP.";
                }
                $protocol = $check_protocol;
            }

            if(!defined $protocol) {
                throw "No ports could be found.";
            }

            return $protocol;
        }

        # Get the pool ID.  If the pool is numeric in the config it will be
        # returned.
        # Otherwise the pool will be looked up and the ID returned.
        # $is_new_storage_pool, if true, will force a pool lookup even if
        # we've been given a pool number.
        sub _find_pool_id {
            my ($scfg, $api, $is_new_storage_pool) = @_;

            my $pool_id_or_name = SC::pool($scfg);
            if(Util::is_numeric($pool_id_or_name)) {
                if($is_new_storage_pool) {
                    my $pool = $api->get_pool($pool_id_or_name);
                    return $pool->{id} if defined $pool;
                } else {
                    return $pool_id_or_name;
                }
            } else {
                my $pools;
                # We will force get_pools to not log if we're not
                # a new storage pool.
                $pools = $api->get_pools(
                                        verbose_log=>!$is_new_storage_pool,
                                        name_hint=>$pool_id_or_name);
                foreach my $pool (@$pools) {
                    if($pool_id_or_name eq $pool->{name}) {
                        return $pool->{id};
                    }
                }
            }

            throw HSPV::NotFoundException->new(
                            "Could not find pool named $pool_id_or_name.");
        }

    }

    ####################################################
    # Internal Context attributes / helpers.
    ####################################################

    # The following are shortcuts to access members, and members from the
    # storage state.
    sub _api { my ($class) = @_; return $class->{_api}; }
    sub _scfg { my ($class) = @_; return $class->{_scfg}; }
    sub _is_drs {
        my ($class) = @_; return $class->{_storage_state}->{is_drs}; }
    sub _csv {
        my ($class) = @_;
        return $class->_is_drs() ? ApiClient::CSV_DEDUPLICATION_COMPRESSION() :
            ApiClient::CSV_DISABLED();
    }
    sub _storage_id {
        my ($class) = @_; return $class->{_storage_state}->{storage_id}; }
    sub _connector { my ($class) = @_; return $class->{_connector}; }

    ################
    # Context attributes.
    ################

    # Attributes of the context.
    sub storeid { my ($class) = @_; return $class->{_storeid}; }
    sub serial {
        my ($class) = @_; return $class->{_storage_state}->{serial}; }
    sub model {
        my ($class) = @_; return $class->{_storage_state}->{model}; }
    sub port_type { my ($class) = @_;
        return $class->{_storage_state}->{port_type}; }
    sub is_iscsi { my ($class) = @_;
        return $class->{_storage_state}->{port_type} eq _PORT_TYPE_ISCSI; }
    sub is_fc { my ($class) = @_;
        return $class->{_storage_state}->{port_type} eq _PORT_TYPE_FC; }
    sub is_nvme_tcp { my ($class) = @_;
        return $class->{_storage_state}->{port_type} eq _PORT_TYPE_NVME_TCP; }
    sub is_nvme_fc { my ($class) = @_;
        return $class->{_storage_state}->{port_type} eq _PORT_TYPE_NVME_FC; }
    sub pool_id { my ($class) = @_;
        return $class->{_storage_state}->{pool}; }
    sub ports { my ($class) = @_; return $class->{_ports}; }
    sub is_multipath { my ($class) = @_; return @{$class->ports()}>1; }

    ################
    # General Functionality.
    ################

    # Call this when removing the storage pool from proxmox. This will remove
    # specific cache information, and will remove the storage pool's
    # server.
    # This ensures that objects are deleted in case a new configuration is
    # created with the same storeid, but totally different settings.
    sub kill_storage_pool {
        my ($class) = @_;

        $class->_clear_cache();
        $class->_connector()->on_remove_storage_pool();
    }

    sub _clear_cache {
        my ($class) = @_;

        HSPV::PersistentCache::delete_cache(
                        _PERSISTENT_CACHE_STORAGE_STATE_CATEGORY,
                        $class->storeid());
    }

    # Check if the given address/username/password will resolve to the
    # same storage as this context.
    # Note that if the cache for this context gets deleted and the
    # location/credentials no longer work, we'll have failed before this point.
    sub check_storage_connection_config_change {
        my ($class, $address, $username, $password) = @_;

        my $api = _create_api_client_raw($address, $username, $password, 0);
        my $storage = $api->get_storage();
        return $storage->{serial} == $class->serial();
    }

    # Attempt to change the port configuration.
    sub change_ports {
        my ($class, $new_ports) = @_;

        # Do our port validation first.
        my $port_type = Init::_validate_ports_and_find_port_type(
            $new_ports, $class->_api());

        # Change ports.  This may throw if we violate port grouping.
        $class->_connector()->on_change_ports($new_ports);

        # Finally, if our port type has changed, we need to clear our cache.
        # because we store our port type in the cache.
        # The cache will reload next time the script executes.
        if($class->port_type() ne $port_type) {
            $class->_clear_cache();
        }
    }

    ################
    # APIs.  Admin API status is used to determine which APIs to call.
    ################

    # Get the pool according to this context.
    # This call will die with NotFoundException if the pool does not exist.
    # If $is_status_request is true, the verbose_log tag will be added
    # to the request to avoid log spam from the status() call.
    sub get_pool {
        my ($class, $is_status_request) = @_;

        my $pool_id = $class->pool_id();

        my $pool;
        $pool = $class->_api()->get_pool($pool_id,
                                         verbose_log=>$is_status_request);

        if(!defined $pool) {
            throw HSPV::NotFoundException->new(
                            "Could not find pool $pool_id.");
        }

        return $pool;
    }

    # Create a virtual LDEV according to this context.
    # capacity must be a HSPV::Util:Capacity object.  It should be MB-aligned,
    # but it will not be checked..
    sub create_virtual_ldev {
        my ($class, $capacity, $name) = @_;

        if($class->_is_drs()) {
            return $class->_create_managed_drs_ldev($capacity, $name);
        }

        return $class->_create_ldev($capacity, $name);
    }

    # Find the LDEVs based on the given name (or prefix).
    sub find_ldevs {
        my ($class, $name, $name_is_prefix) = @_;

        my %opts;
        $opts{match_type} = ApiClient::LDEV_MATCH_START() if
                            $name_is_prefix;

        # Narrow our search down by our LDEV range and pool.

        # If no range was provided, these will be undef and use the
        # default.
        my ($start_range, $end_range) = SC::ldev_range($class->_scfg());
        $opts{start_ldev_id} = $start_range;
        $opts{end_ldev_id} = $end_range;

        $opts{pool} = $class->pool_id();

        my $ldevs = $class->_api()->get_ldevs_by_name($name, %opts);

        return $ldevs;

    }

    # Get the given LDEV.
    sub get_ldev {
        my ($class, $ldev_id) = @_;

        my $ldev = $class->_api()->get_ldev($ldev_id);

        if(!defined $ldev) {
            throw HSPV::NotFoundException->new(
                            "Could not find ldev $ldev_id.");
        }

        return $ldev;
    }

    # Get the NAA for the given LDEV.
    # This will throw NotFoundException if the LDEV does not exist.
    # If the LDEV exists, but is not on a port, this will return undef.
    # Otherwise the NAA will be returned.
    sub get_ldev_naa {
        my ($class, $ldev_id) = @_;

        my $ldev = $class->_api()->get_ldev($ldev_id, want_naa => 1);

        if(!defined $ldev) {
            throw HSPV::NotFoundException->new(
                            "Could not find ldev $ldev_id.");
        }

        return $ldev->{naa}; # Will be undef if not connected to port.
    }

    # Resize the given LDEV.
    # capacity must be a HSPV::Util:Capacity object.  It should be MB-aligned,
    # but it will not be checked.
    sub resize_ldev {
        my ($class, $ldev_id, $capacity) = @_;

        my $ldev_cfg = $class->_get_ldev_config($ldev_id);

        my $ldev = $ldev_cfg->{ldev};
        my $add_capacity = $capacity - $ldev->{total_capacity};

        if($ldev_cfg->{is_drs_managed}) {
            $class->_resize_drs_managed_ldev($ldev_cfg, $add_capacity);
        } else {
            $class->_api()->resize_ldev($ldev_id, $add_capacity);
        }

        return;
    }

    # Clone the given LDEV and return the LDEV ID.
    sub clone_ldev {
        my ($class, $ldev_id, $clone_ldev_name) = @_;

        my $ldev = $class->get_ldev($ldev_id);

        if($ldev->{is_drs}) {
            return $class->_clone_drs_ldev($ldev_id, $ldev->{total_capacity},
                                           $clone_ldev_name);
        }

        throw "Non-DRS clones are not currently supported.";
    }

    # Delete the given LDEV according to this context.
    sub delete_ldev {
        my ($class, $ldev_id) = @_;

        my $ldev_cfg = $class->_get_ldev_config($ldev_id);

        if($ldev_cfg->{ldev}->{data_reduction_status} eq
                ApiClient::DRSTAT_FAILED()) {

            throw "Cannot delete volume $ldev_cfg->{ldev}->{id} as " .
                  "consistency is not guaranteed.";
        }

        if($ldev_cfg->{is_drs_managed}) {
            $class->_delete_managed_drs_ldev($ldev_cfg);
        } else {
            $class->_api()->delete_ldev($ldev_id);
        }
        return;
    }

    # Create an iSCSI or FC connection according to the connector in this
    # context.
    sub create_connection {
        my ($class, $ldev, $hbas) = @_;

        $class->_connector()->create_connection($ldev, $hbas);
        return;
    }

    # Get the IQNs and IPs for the ports that this storage pool has
    # connections to according to the connector in this context.
    # Returns an array of hashes containing port, IP, and IQN data
    # associated with the server's ports (and narrowed down by ports
    # we support in case server has been modified outside HSPV).
    # Result Hashes:
    #   port: The port.
    #   iqn: The IQN.
    #   ipv4_address: The ipv4 address.
    #   tcp_port: The TCP port.
    sub get_iscsi_port_info {
        my ($class) = @_;

        return $class->_connector()->get_iscsi_port_info();
    }

    # Delete a LUN/LUNs according to the connector in this context.
    sub delete_connection {
        my ($class, $ldev) = @_;

        $class->_connector()->delete_connection($ldev);
        return;
    }

    ################
    # Internal APIs/helpers to help avoid megafunctions.
    ################

    # Create an LDEV.
    # It is important to use this method instead of calling the API directly
    # so that naming can be accounted for (not all APIs support directly
    # naming an LDEV in the API call).
    # capacity must be a HSPV::Util:Capacity object.  It should be MB-aligned,
    # but it will not be checked.
    sub _create_ldev {
        my ($class, $capacity, $name) = @_;

        # If no range was provided, these will be undef and use the
        # default.
        my ($start_range, $end_range) = SC::ldev_range($class->_scfg());
        my %opts = (
            start_ldev_id => $start_range,
            end_ldev_id   => $end_range,
            name          => $name,
            is_drs        => $class->_is_drs(),
            csv           => $class->_csv(),
        );

        my $ldev_id = $class->_api()->create_virtual_ldev(
            $class->pool_id(), $capacity, %opts);

        if(!$class->_api()->has_name_ldev_on_create_support()) {

            # TODO: When we support non-admin API storage, we must set the
            # LDEV name here. If it fails to set, we need to delete the LDEV
            # and rethrow the error.
            throw _OPERATION_NOT_SUPPORTED_MESSAGE;
        }

        return $ldev_id;
    }

    # Clone the given LDEV usign the given capacity value and name for the
    # clone. This will use the context's pool for cloning.
    # capacity must be a HSPV::Util:Capacity object.  It should be MB-aligned,
    # but it will not be checked.
    sub _clone_drs_ldev {
        my ($class, $ldev_id, $capacity, $clone_ldev_name) = @_;

        my $cloned_ldev_id;
        my $snapshot_mu;
        eval {
            $cloned_ldev_id = $class->_create_ldev($capacity,
                                                   $clone_ldev_name);

            $snapshot_mu = $class->_api()->create_snapshot($ldev_id,
                $cloned_ldev_id, $class->pool_id(),
                $class->_format_snapshot_group_name(
                        $ldev_id, $cloned_ldev_id, 1),
                is_csv => 1, is_cascade => 1);

            $class->_wait_for_snapshot_status($ldev_id, $snapshot_mu,
                                              ApiClient::PAIRSTAT_PAIR());

            $class->_api()->snapshot_vclone($ldev_id, $snapshot_mu,
                                            ApiClient::VCLONE_CREATE());

            1;
        } or do {
            my $error = $@ || 'An unknown error occurred.';

            $class->_cleanup_or_log_error([$ldev_id, $snapshot_mu],
                                          [$cloned_ldev_id]);
            throw $error;
        };

        return $cloned_ldev_id;
    }

    # Create a managed DRS LDEV.
    # This will create a parent volume, snapshot, and vClone to the
    # managed volume.  The managed volume will be returned.
    # capacity must be a HSPV::Util:Capacity object.  It should be MB-aligned,
    # but it will not be checked.
    sub _create_managed_drs_ldev {
        my ($class, $capacity, $name) = @_;

        my $parent_ldev_id = $class->_create_ldev($capacity,
                                                  _MANAGED_DRS_PARENT_NAME);

        my $ldev_id;
        eval {

            $ldev_id = $class->_clone_drs_ldev($parent_ldev_id, $capacity,
                                               $name);

            1;
        } or do {
            my $error = $@ || 'An unknown error occurred.';

            $class->_cleanup_or_log_error(undef, $parent_ldev_id);
            throw $error;
        };

        return $ldev_id;
    }

    # Resize a managed DRS LDEV.  This first checks for a parent
    # and resizes it first if necessary.
    # add_capacity must be a HSPV::Util:Capacity object.  It should be
    # MB-aligned, but it will not be checked.
    sub _resize_drs_managed_ldev {
        my ($class, $ldev_cfg, $add_capacity) = @_;

        my $new_capacity = $ldev_cfg->{ldev}->{total_capacity} + $add_capacity;
        my $parent_capacity = $ldev_cfg->{parent_ldev}->{total_capacity};

        # Resize our parent if it's not big enough.
        if($parent_capacity < $new_capacity) {
            $class->_api()->resize_ldev(
                $ldev_cfg->{parent_ldev}->{id},
                $new_capacity - $parent_capacity);
        }

        # Resize our vClone.
        $class->_api()->resize_ldev($ldev_cfg->{ldev}->{id},
                                    $add_capacity);

        return;
    }

    # Get the lock name for deleting the VCP (to avoid race conditions with
    # other deleters).
    sub _delete_vcp_lock_name {
        my ($class, $parent_ldev_id) = @_;

        my $untained_serial = Util::untaint($class->serial());
        my $untained_ldev_id = Util::untaint($parent_ldev_id);

        return "hspv-delete-vcp-$untained_serial-$untained_ldev_id";
    }

    use constant {
        _DELETE_VC_STATUS_CHECK_INTERVAL_S => 1,
        _DELETE_VC_STATUS_TIMEOUT_S        => 600,
    };

    # Wait for a a VC volume to remove from the snapshot family.
    #   $ldev_id: The ID of the VC.
    #   $parent_ldev_id: The ID of the VCP.
    #   $check_interval_s: The check interval in seconds. Defaults to
    #       _DELETE_VC_STATUS_CHECK_INTERVAL_S if not provided.
    #   $timeout_s: The timeout to return after reaching if status is not
    #       found.
    #       Defaults to _DELETE_VC_STATUS_TIMEOUT_S if not provided.
    # This subroutine will not throw exceptions.  It will return 1 if the
    # snapshot successfully removes, or 0 if a problem occurred (while logging
    # an error).
    sub _wait_for_vc_removal_from_family {
        my ($class, $ldev_id, $parent_ldev_id, $check_interval_s,
            $timeout_s) = @_;

        $check_interval_s //= _DELETE_VC_STATUS_CHECK_INTERVAL_S;
        $timeout_s //= _DELETE_VC_STATUS_TIMEOUT_S;

        my $removed = 0;
        my $start_time = time();
        while(1) {

            my $family_list = $class->_api()->get_snapshot_family(
                $parent_ldev_id);

            my $found = 0;
            foreach my $member (@$family_list) {
                $found = defined $member->{ldev} &&
                         defined $member->{parent_ldev} &&
                         $member->{ldev} == $ldev_id &&
                         $member->{parent_ldev} == $parent_ldev_id;

                if($found) {
                    last;
                }
            }

            if(!$found) {
                # Our item was removed, so skip the checks below.
                $removed = 1;
                last;
            }

            if((time() - $start_time) >= $timeout_s) {
                Log::error("Timed out while waiting for family removal for " .
                          "$ldev_id and parent $parent_ldev_id.");
                # Timeout, so bail.
                last;
            }

            sleep($check_interval_s);
        }

        return $removed;
    }

    # Delete the given managed DRS LDEV according to this context.
    # This will delete the VCP if it no longer has children after the
    # operation.
    sub _delete_managed_drs_ldev {
        my ($class, $ldev_cfg) = @_;

        # Delete vClone first.
        $class->_api()->delete_ldev($ldev_cfg->{ldev}->{id});

        # Check that parent can be deleted based on DR status.
        if($ldev_cfg->{parent_ldev}->{data_reduction_status} eq
            ApiClient::DRSTAT_FAILED()) {

            Log::error("Cannot delete parent volume " .
                       "$ldev_cfg->{parent_ldev}->{id} as consistency is " .
                       "not guaranteed.");
            return;
        }

        # Wait for our VC removal from the family.
        if(!$class->_wait_for_vc_removal_from_family(
                            $ldev_cfg->{ldev}->{id},
                            $ldev_cfg->{parent_ldev}->{id})) {
            return;
        }

        my $parent_delete = sub {

            my $ldev = $class->_api()->get_ldev(
                                        $ldev_cfg->{parent_ldev}->{id});

            # Return if someone else got here first and deleted it.
            if(!defined $ldev) {
                Log::info("Did not delete managed VCP " .
                          "$ldev_cfg->{parent_ldev}->{id} (seems another " .
                          "caller did it first).");
                return;
            }

            # If we're no longer a VCP, we can delete our VCP.
            if(!$ldev->{is_vcp}) {

                eval {
                    $class->_api()->delete_ldev(
                        $ldev_cfg->{parent_ldev}->{id});

                    1;
                } or do {
                    Log::error("Failed to delete managed VCP " .
                               "$ldev_cfg->{parent_ldev}->{id}. It must be " .
                               "cleaned up manually.");
                }
            } else {
                Log::info("Not cleaning up managed VCP " .
                          "$ldev_cfg->{parent_ldev}->{id} as it still " .
                          "has children.");
            }
            return;
        };

        # Lock our domain so we only have one parent killer at a time for the
        # given parent.
        my $lock_name =
            $class->_delete_vcp_lock_name($ldev_cfg->{parent_ldev}->{id});
        eval {
            PVE::Cluster::cfs_lock_domain(
                $lock_name,
                VCP_DELETE_LOCK_TIMEOUT,
                $parent_delete);

            1;
        } or do {
            my $e = $@; # Copy exception

            Log::error("Failed to lock domain for $lock_name: $e");
        };

        return;
    }

    # Format the name of a snapshot group.
	# Format is "HSPV:{pvol_id}:{svol_id}
    #   OR
    # Format is "HSPV:{pvol_id}:{svol_id}:temp
    #   (depending on $is_temp flag).
    sub _format_snapshot_group_name {
        my ($class, $pvol_id, $svol_id, $is_temp) = @_;

        my $header =
            PVE::Storage::Custom::HitachiHSPVPlugin::HSPV_NAME_HEADER();
        my $temp_suffix = $is_temp ? ':temp' : '';
        return "$header$pvol_id:$svol_id$temp_suffix";
    }

    # Get the LDEV config in a hash.
    #  Keys:
    #   - ldev: LDEV object
    #   - parent_ldev: parent object (or undef/no key if no parent)
    #   - is_drs_managed: management flag
    sub _get_ldev_config {
        my ($class, $ldev_id) = @_;

        my %ldev_config;

        my $ldev = $class->get_ldev($ldev_id);
        $ldev_config{ldev} = $ldev;
        if(defined $ldev->{parent_ldev}) {
            my $parent_ldev = $class->get_ldev($ldev->{parent_ldev});
            $ldev_config{parent_ldev} = $parent_ldev;
            $ldev_config{is_drs_managed} =
                ($parent_ldev->{name} eq _MANAGED_DRS_PARENT_NAME);
        } else {
            $ldev_config{is_drs_managed} = 0;
        }

        return \%ldev_config;
    }

    use constant {
        _SNAPSHOT_STATUS_CHECK_INTERVAL_S => 1,
        _SNAPSHOT_STATUS_TIMEOUT_S        => 600,
    };

    # Wait for a certain snapshot status.
    #   $pvol_id: The ID of the PVOL.
    #   $mu: The mirror unit of the pair.
    #   $wait_status: A single status or a list of statuses to wait for one of.
    #   $fail_status: A single status or a list of statuses to throw an error
    #       for if found. If this is undef, the following statuses will be
    #       used for this purpose (define empty array if no checking desired):
    #       PFUL, PFUS, PSUE (unless they are also in $wait_status).
    #   $check_interval_s: The check interval in seconds. Defaults to
    #       _SNAPSHOT_STATUS_CHECK_INTERVAL_S if not provided.
    #   $timeout_s: The timeout to throw after reaching if status is not found.
    #       Defaults to _SNAPSHOT_STATUS_TIMEOUT_S if not provided.
    sub _wait_for_snapshot_status {
        my ($class, $pvol_id, $mu, $wait_status, $fail_status,
            $check_interval_s, $timeout_s) = @_;

        $check_interval_s //= _SNAPSHOT_STATUS_CHECK_INTERVAL_S;
        $timeout_s //= _SNAPSHOT_STATUS_TIMEOUT_S;

        my $wait_status_array = $wait_status;
        if(!Util::is_array_ref($wait_status)) {
            $wait_status_array = [$wait_status];
        }
        my $fail_status_array;
        if(!defined $fail_status) {
            $fail_status_array = [];
            if(!any {$_ eq ApiClient::PAIRSTAT_PFUL()} @$wait_status_array) {
                push @$fail_status_array, ApiClient::PAIRSTAT_PFUL();
            }
            if(!any {$_ eq ApiClient::PAIRSTAT_PFUS()} @$wait_status_array) {
                push @$fail_status_array, ApiClient::PAIRSTAT_PFUS();
            }
            if(!any {$_ eq ApiClient::PAIRSTAT_PSUE()} @$wait_status_array) {
                push @$fail_status_array, ApiClient::PAIRSTAT_PSUE();
            }
        } elsif(!Util::is_array_ref($fail_status)) {
            $fail_status_array = [$fail_status];
        }

        my $start_time = time();
        while(1) {
            my $snapshot = $class->_api()->get_snapshot($pvol_id, $mu);
            if(!defined $snapshot) {
                throw "Snapshot could not be found.";
            }

            if(any {$_ eq $snapshot->{status}} @$wait_status_array) {
                last;
            }

            if(any {$_ eq $snapshot->{status}} @$fail_status_array) {
                throw "Found unexpected status '$snapshot->{status}' while " .
                    "waiting for snapshot state.";
            }

            if((time() - $start_time) >= $timeout_s) {
                throw "Timed out while waiting for snapshot status.";
            }

            sleep($check_interval_s);
        }

        return;
    }

    # This takes in values of storage objects and cleans them up.
    # The values themselves may be undef *, so you can have a structure
    # that may not have completed and still perform cleanups without
    # checking all values.
    # * Values that are required to be pairs/tuples may not have undef
    #   entries, but elements within them may be.
    #
    # This subroutine will only log errors for items that fail to clean up
    # (i.e. it will not throw exceptions).
    #
    # This subroutine currently only supports cleaning up LDEVs and snapshots.
    #
    # Cleanup group ordering:
    #   1. Snapshots
    #   2. LDEVs
    # Cleanup list ordering:
    #   - By order of array index.
    #
    # Parameters:
    #   snapshots: undef, single pair, or array of pairs of snapshots to
    #       delete, with each pair consisting of PVOL,MU.
    #   ldevs: undef, single LDEV, or array of LDEVs to delete.
    #
    # This logs and returns the number of failures encountered.
    sub _cleanup_or_log_error {
        my ($class, $snapshots, $ldevs) = @_;

        Log::debug("Cleaning up objects.");

        my $fail_count = 0;

        # Cleanup snapshots.

        # Normalize our list first.
        my $clean_snapshots = $snapshots // [];
        # If we're a list of 2 and our first element is not a list
        # we will assume we've been given a single snapshot pair.
        if(@$clean_snapshots == 2 && !Util::is_array_ref(
                                            $clean_snapshots->[0])) {
            $clean_snapshots = [$clean_snapshots];
        }

        # Cleanup
        foreach my $snapshot (@$clean_snapshots) {
            # Cleanup and log errors for anything that could not be cleaned up.

            if(!Util::is_array_ref($snapshot) || @$snapshot != 2) {
                Log::error(
                    "Found unexpected data while cleaning up snapshots.");
                ++$fail_count;
            } elsif(defined $snapshot->[0] && defined $snapshot->[1]) {
                my $pvol = $snapshot->[0];
                my $mu = $snapshot->[1];
                eval {
                    $class->_api()->delete_snapshot($pvol,
                                                    $mu);

                    1;
                } or do {
                    Log::error("Failed to clean up snapshot for PVOL for " .
                               "LDEV $pvol with MU $mu.");
                    ++$fail_count;
                }
            }
        }


        # Cleanup LDEVs.

        # Normalize our list first.
        my $clean_ldevs = $ldevs // [];
        if(!Util::is_array_ref($clean_ldevs)) {
            $clean_ldevs = [$clean_ldevs];
        }

        # Cleanup
        foreach my $ldev_id (@$clean_ldevs) {
            if(defined $ldev_id) {
                eval {
                    $class->_api()->delete_ldev($ldev_id);

                    1;
                } or do {
                    Log::error("Failed to clean up LDEV $ldev_id.");
                    ++$fail_count;
                }
            }
        }

        if($fail_count) {
            Log::error("Failed to clean up $fail_count objects.");
        } else {
            Log::debug("Successfully cleaned up all objects.");
        }

        return $fail_count;
    }

}

####################################################
# PVE::Storage::Custom::HitachiHSPVPlugin::Connector package
####################################################

package PVE::Storage::Custom::HitachiHSPVPlugin::Connector {

    use strict;
    use warnings;

    BEGIN {
        *Log:: = *HSPV::Log::;
        *Util:: = *HSPV::Util::;
        *Context:: = *PVE::Storage::Custom::HitachiHSPVPlugin::Context::;
        *Connections:: =
            *PVE::Storage::Custom::HitachiHSPVPlugin::Connections::;
        *throw = \&HSPV::Util::throw;
    }

    sub new {
        my ($class, $storeid, $serial, $ports, $api) = @_;

        my $self = {
            storeid => $storeid,
            serial => $serial,
            ports => $ports,
            api => $api,
            # This is lazy-loaded, so do not use directly.
            __port_group_id => undef,
        };

        return bless $self, $class;
    }

    # Call this when the storage pool is being created.
    sub on_create_storage_pool {
        my ($class) = @_;

        $class->{__port_group_id} = Connections::add_storage_pool($class);
        return;
    }

    # Call this when the storage pool is being deleted.
    sub on_remove_storage_pool {
        my ($class) = @_;

        Connections::remove_storage_pool($class);
        return;
    }

    sub on_change_ports {
        my ($class, $new_ports) = @_;

        # Change our port settings if possible.
        Connections::change_ports($class, $new_ports);
        return;
    }

    sub storeid { my ($class) = @_; return $class->{storeid}; }
    sub serial { my ($class) = @_; return $class->{serial}; }
    sub ports { my ($class) = @_; return $class->{ports}; }
    sub _api { my ($class) = @_; return $class->{api}; }

    # Get or find the port group ID associated with this context.
    sub get_port_group_id {
        my ($class) = @_;

        if(defined $class->{__port_group_id}) {
            return $class->{__port_group_id};
        }

        $class->{__port_group_id} = Connections::find_port_group_id($class);
        if(!defined $class->{__port_group_id}) {
            Log::error("Could not find port group ID. Configuration file " .
                       "have been removed or is in accessible.");
            throw "Could not find port group ID.";
        }

        return $class->{__port_group_id};
    }

    # Create a connection for the given LDEV and HBAs according to this
    # connector.
    sub create_connection {
        my ($class, $ldev, $hbas) = @_;

        throw "Not Supported.";
    }

    # Remove the given connection groups.
    sub cleanup_connections {
        my ($class, $connection_groups) = @_;

        throw "Not Supported.";
    }

    # Get the IQNs and IPs for the ports that the storage pool has
    # connections to for this connecotr.
    # Returns an array of hashes containing port, IP, and IQN data
    # associated with the server's ports (and narrowed down by ports
    # we support in case server has been modified outside HSPV).
    # Result Hashes:
    #   port: The port.
    #   iqn: The IQN.
    #   ipv4_address: The ipv4 address.
    sub get_iscsi_port_info {
        my ($class) = @_;

         throw "Not Supported.";
    }

    # Delete the connection for the given LDEV according to this connector.
    sub delete_connection {
        my ($class, $ldev) = @_;

        throw "Not Supported.";
    }
}

####################################################
# PVE::Storage::Custom::HitachiHSPVPlugin::Connector::ServerConnector package
####################################################

package PVE::Storage::Custom::HitachiHSPVPlugin::Connector::ServerConnector {

    use strict;
    use warnings;

    BEGIN {
        *Log:: = *HSPV::Log::;
        *Util:: = *HSPV::Util::;
        *Context:: = *PVE::Storage::Custom::HitachiHSPVPlugin::Context::;
        *Connections:: =
            *PVE::Storage::Custom::HitachiHSPVPlugin::Connections::;
        *throw = \&HSPV::Util::throw;
    }

    use base qw(PVE::Storage::Custom::HitachiHSPVPlugin::Connector);

    sub new {
        my ($class, $storeid, $serial, $ports, $api, $hmo, $is_iscsi) = @_;

        my $self = $class->SUPER::new($storeid, $serial, $ports, $api);


        # This is lazy-loaded and should not be used directly.
        $self->{_is_iscsi} = $is_iscsi;
        $self->{_hmo} = $hmo;
        $self->{__server_id} = undef;

        return $self;
    }

    sub is_iscsi { my ($class) = @_; return $class->{_is_iscsi}; }
    sub hmo { my ($class) = @_; return $class->{_hmo}; }
    # This returns "wwn" if we're FC and "iqn" if we're iSCSI.
    sub _hba_type_name {
        my ($class) = @_;
        return $class->is_iscsi() ? "iqn" : "wwn";
    }

    # Create a connection from the LDEV to the given HBAs.
    sub create_connection {
        my ($class, $ldev, $hbas) = @_;

        Log::info("Creating connection for LDEV $ldev.");

        my $server_id = $class->_get_server_id_or_create($hbas);
        Log::info("Using server ID $server_id for connection.");

        # Add our LUNs if they don't exist.
        my $luns = $class->_api()->get_server_ldev_luns($server_id,
                                                        $ldev);
        if(!defined $luns) {
            $class->_api()->add_server_luns($server_id, $ldev);
        }

        return;
    }

    # Cleanup connections returned by the Connections store.
    sub cleanup_connections {
        my ($class, $connection_groups) = @_;

        my $servers = $class->_api()->get_servers();
        my %server_lookup = map { $_->{name} => $_->{id} } @$servers;

        # Delete all servers we find.
        for my $connection_group (@$connection_groups) {

            if(defined $server_lookup{$connection_group}) {
                $class->_api()->delete_server(
                            $server_lookup{$connection_group});
            }
        }
    }

    # Throws if not iSCSI.
    sub get_iscsi_port_info {
        my ($class) = @_;

        if(!$class->is_iscsi()) {
            throw "This is only supported for iSCSI connectors.";
        }

        my @port_info;

        # Query the actual IQNs on the server.
        my $port_iqns = $class->_api()->get_server_port_iqns(
                                                $class->_get_server_id());

        if(!$class->_api()->has_ip_info_for_all_ports_query()) {
            # TODO: Must query each iSCSI port for IP address below as
            # the underlying API does not support returning it with all
            # ports.
            throw "This storage is not supported."
        }

        # Query all iSCSI ports.
        my $ports = $class->_api()->get_ports(
                                protocol => Context::_PORT_TYPE_ISCSI());

        my $configured_ports = $class->ports();

        # Map by port for the IQNs and ports.
        my %iqn_map = map { $_->{port} => $_ } @$port_iqns;
        my %port_map = map { $_->{port} => $_ } @$ports;

        foreach my $port (@$configured_ports) {
            if(defined $iqn_map{$port} && defined $port_map{$port}) {
                push @port_info, { port => $port,
                                    iqn => $iqn_map{$port}->{iqn},
                                    ipv4_address =>
                                    $port_map{$port}->{ipv4_address},
                                    tcp_port =>
                                    $port_map{$port}->{tcp_port}
                                    };
            }
        }

        return \@port_info;
    }


    # This does not deregister paths or hbas.
    sub delete_connection {
        my ($class, $ldev) = @_;

        use constant RETURN_UNDEF_ON_NOT_FOUND => 1;

        my $server_id = $class->_get_server_id(RETURN_UNDEF_ON_NOT_FOUND);
        if(!defined $server_id) {
            # If we didn't even find our server, there's no connection
            # to sever.
            return;
        }

        # Get a list of LUNs for this LDEV. If the return value is undef
        # (server doesn't exist), or the LUN list is empty then do not
        # proceed further as no LUNs exist.
        # The negative cases could theoretically happen depending on
        # proxmox workflows.
        my $luns = $class->_api()->get_server_ldev_luns($server_id,
                                                                $ldev);
        if(defined $luns && @{$luns->{luns}}>0) {
            $class->_api()->remove_server_luns($server_id, $ldev);
        }

        return;
    }

    # Initialize a server.
    # The expectation is that the domain has been locked appropriately
    # when this is called.
    # This will further check to see if the server exists in case
    # another caller has created the server while we were waiting on
    # the lock.
    sub _init_server_locked {
        my ($class, $server_name, $hbas) = @_;

        my $server = $class->_api()->get_server_by_name($server_name);
        if(defined $server) {
            return $server->{id};
        }

        my $protocol;
        if($class->is_iscsi()) {
            $protocol = ApiClient::SERVER_PROTOCOL_ISCSI();
        } else {
            $protocol = ApiClient::SERVER_PROTOCOL_FC();
        }


        my $server_id = $class->_api()->create_server(
                                $server_name,
                                $protocol,
                                ApiClient::SERVER_OS_LINUX(),
                                hmo => $class->hmo());

        eval {
            $class->_api()->add_server_hbas($server_id, $hbas,
                                            !$class->is_iscsi());

            Connections::add_connection($class, $server_name);
            1;
        } or do {
            my $e = $@; # Copy exception

            # If we failed to add our HBA, we don't want to leave an
            # inconsistent state.
            $class->_api()->delete_server($server_id);

            die $e; # Re-throw.
        };

        return $server_id;
    }

    sub _find_missing_server_paths {
        my ($class, $server, $hba) = @_;

        # Build a list of the ports we do have.
        my %found_ports;
        foreach my $path (@{$server->{paths}}) {
            if($path->{$class->_hba_type_name()} eq $hba) {
                foreach my $port (@{$path->{ports}}) {
                    $found_ports{$port} = 1;
                }
            }
        }

        # Iterate our required ports vs. our known ports and push
        # any that are missing.
        my @missing_ports;
        foreach my $port (@{$class->ports()}) {
            push @missing_ports, $port if !exists $found_ports{$port};
        }

        return \@missing_ports;
    }

    sub _init_server_paths_locked {
        my ($class, $server_id, $hbas) = @_;

        my @hba_list;
        if(Util::is_array_ref($hbas)) {
            @hba_list = @$hbas;
        } else {
            @hba_list = ($hbas);
        }

        my %missing_ports;
        my $server = $class->_api()->get_server($server_id);
        foreach my $hba (@hba_list) {
            my $missing = $class->_find_missing_server_paths($server,
                                                             $hba);
            $missing_ports{$hba} = $missing if @$missing > 0;
        }

        foreach my $hba (keys %missing_ports) {
            my $ports = $missing_ports{$hba};
            Log::info("Adding missing paths for server $server_id, " .
                    "HBA $hba, ports: " . join(", ", @$ports));
            $class->_api()->add_server_paths($server_id,
                    $hba, $ports, !$class->is_iscsi());
        }

        return;
    }

    # Format the name of a server or host group.
	# Format is "HSPV:{node_ip}:{port_group}
    sub _format_server_or_host_group_name {
        my ($name_suffix, $port_group_id) = @_;

        my $header =
            PVE::Storage::Custom::HitachiHSPVPlugin::HSPV_NAME_HEADER();
        return "$header$name_suffix:$port_group_id";
    }

    sub _generate_server_name {
        my ($class) = @_;

        # For now both protocols will use the same server name as
        # FC may have several WWPNs and we'll put them all on one server.
        my $name_suffix = Util::get_current_node_ip();
        if(!$name_suffix) {
            throw "Could not resolve local node IP!";
        }

        my $port_group_id = $class->get_port_group_id();

        return _format_server_or_host_group_name($name_suffix, $port_group_id);
    }

    sub _get_server_id {
        my ($class, $no_throw_on_not_found) = @_;

        use constant CAN_NOT_CREATE => 0;

        my %server_name;
        my $server_id = $class->_init_server(CAN_NOT_CREATE, undef,
                                             \%server_name);
        if(!defined $server_id && !$no_throw_on_not_found) {
            my $server_name = $server_name{name};
            throw HSPV::NotFoundException->new(
                            "Could not find server named $server_name.");
        }
        return $server_id;
    }

    sub _get_server_id_or_create {
        my ($class, $hbas) = @_;

        use constant CAN_CREATE => 1;
        return $class->_init_server(CAN_CREATE, $hbas);
    }

    sub _server_init_lock_name {
        my ($class, $server_name, $init_type) = @_;

        # Untaint $server_name before passing to cfs_lock_domain.
        # $server_name is built from the node IP (external) and a port group ID
        # (read from JSON cache), both of which are tainted under -T.
        my $untainted_server_name = Util::untaint($server_name);

        return "hspv-$untainted_server_name-$init_type";
    }

    # If the server ID has been cached, it is returned.  Otherwise the
    # server is searched for.  If it cannot be found, it is created with
    # necessary paths set up if $can_create is true. Otherwise this will return
    # undef.
    # if $can_create is true, the given $hbas will be attached to the server
    # if it's created.
    # $out_server_name, if provided, will return the server name in a hash
    # (name=>"name") if the server could not be found and $can_create is false.
    sub _init_server {
        my ($class, $can_create, $hbas, $out_server_name) = @_;

        if(defined $class->{__server_id}) {
            my $ret = $class->{__server_id};
            Log::debug("Returning cached server ID $ret.");
            return $class->{__server_id};
        }

        # Lazy load our ID. This may include creating or updating the server
        # itself.

        # Generate our server name.
        my $server_name = $class->_generate_server_name();
        Log::info("DBG: $server_name.");

        use constant SERVER_LOCK_TIMEOUT => 120;

        my $server_id;
        # Try to find our server. If we cannot find it, we will lock and
        # attempt to create it.
        # note that _init_server_locked() will double check that the
        # $server_name does not exist since another caller may have
        # created if if we waited for the lock.
        my $server = $class->_api()->get_server_by_name($server_name);
        if(!defined $server) {
            if(!$can_create) {
                if(defined $out_server_name) {
                    $out_server_name->{name} = $server_name;
                }
                return;
            }

            PVE::Cluster::cfs_lock_domain(
                $class->_server_init_lock_name($server_name, "create-server"),
                SERVER_LOCK_TIMEOUT,
                sub {
                    $server_id = $class->_init_server_locked($server_name,
                                                             $hbas);
                }
            );

            if($@) {
                throw $@;
            }
        } else {
            $server_id = $server->{id};
        }

        if($can_create && defined $hbas) {
            # We only need to check missing paths this time if we didn't create
            # our server.
            my $missing_ports;
            if(defined $server) {
                $missing_ports = $class->_find_missing_server_paths($server,
                                                                    $hbas);
            }
            # Like the above, if we actually end up locking here we will
            # double check that another caller did not add the missing paths.
            if(!defined $missing_ports || @$missing_ports > 0) {
                PVE::Cluster::cfs_lock_domain(
                    $class->_server_init_lock_name($server_name, "add-paths"),
                    SERVER_LOCK_TIMEOUT,
                    sub {
                        $class->_init_server_paths_locked($server_id, $hbas);
                    }
                );

                if($@) {
                    throw $@;
                }
            }
        }

        # Cache our ID and return.
        $class->{__server_id} = $server_id;
        return $server_id;
    }

}

####################################################
# PVE::Storage::Custom::HitachiHSPVPlugin::Connector::HostGroupConnector
# package
####################################################

package PVE::Storage::Custom::HitachiHSPVPlugin::Connector::HostGroupConnector {

    use strict;
    use warnings;

    BEGIN {
        *Log:: = *HSPV::Log::;
        *Util:: = *HSPV::Util::;
        *Context:: = *PVE::Storage::Custom::HitachiHSPVPlugin::Context::;
        *Connections:: =
            *PVE::Storage::Custom::HitachiHSPVPlugin::Connections::;
        *throw = \&HSPV::Util::throw;
    }

    use base qw(PVE::Storage::Custom::HitachiHSPVPlugin::Connector);

    sub new {
        my ($class, $storeid, $serial, $ports, $api) = @_;

        my $self = $class->SUPER::new($storeid, $serial, $ports, $api);

        # TODO: Add host group elements that need to be stored.

        return $self;
    }
}

####################################################
# PVE::Storage::Custom::HitachiHSPVPlugin::Connector::NvmSubsystemConnector
# package
####################################################

package PVE::Storage::Custom::HitachiHSPVPlugin::Connector::NvmSubsystemConnector {

    use strict;
    use warnings;

    BEGIN {
        *Log:: = *HSPV::Log::;
        *Util:: = *HSPV::Util::;
        *Context:: = *PVE::Storage::Custom::HitachiHSPVPlugin::Context::;
        *Connections:: =
            *PVE::Storage::Custom::HitachiHSPVPlugin::Connections::;
        *throw = \&HSPV::Util::throw;
    }

    use base qw(PVE::Storage::Custom::HitachiHSPVPlugin::Connector);

    sub new {
        my ($class, $storeid, $serial, $ports, $api) = @_;

        my $self = $class->SUPER::new($storeid, $serial, $ports, $api);

        # TODO: Add NVM subsystem elements that need to be stored.

        return $self;
    }
}

#####################################################
# PVE::Storage::Custom::HitachiHSPVPlugin::Connections package
#####################################################

# This package manages connections we have to the host groups/servers,
# and port configurations.
# We should be locked using the lock name returned by '_lock_name' when
# using any calls in this package.
package PVE::Storage::Custom::HitachiHSPVPlugin::Connections {

    BEGIN {
        *Log:: = *HSPV::Log::;
        *Util:: = *HSPV::Util::;
        *PC:: = *HSPV::PersistentCache::;
        *SC:: = *PVE::Storage::Custom::HitachiHSPVPlugin::StorageConfig::;
        *throw = \&HSPV::Util::throw;
    }

    use constant _CONNECTIONS_CATEGORY             => "connections";
    use constant _CONNECTIONS_NOLOCK               => 1;
    # This needs to be a large value as during cleanup several host groups
    # may be removed.
    use constant _CONNECTIONS_LOCK_TIMEOUT         => 600;
    use constant _CONNECTIONS_PORT_STR_SEPARATOR   => ',';

    sub _lock_name {
        my ($connector) = @_;

        use constant CONNECTION_LOCK_NAME_HEADER => 'hspv-connection-lock-';
        my $serial = $connector->serial();

        # Untaint $serial: it originates from the storage API (external data).
        my $untainted_serial = Util::untaint($serial);
        return CONNECTION_LOCK_NAME_HEADER . "$untainted_serial";
    }

    sub _is_legal_port_config {
        my ($conn_cfg, $ports) = @_;

        my %port_lookup = map { $_ => 1 } @$ports;

        my $is_illegal;
        foreach my $key (keys %{$conn_cfg->{port_groups}}) {
            foreach my $port
                        (@{$conn_cfg->{port_groups}->{$key}->{ports}}) {
                if(defined $port_lookup{$port}) {
                    $is_illegal = 1;
                    last;
                }
            }

            last if $is_illegal;
        }

        return !$is_illegal;
    }

    sub _get_all_port_configs {
        my ($conn_cfg) = @_;

        my @port_cfgs;
        foreach my $key (keys %{$conn_cfg->{port_groups}}) {
            push @port_cfgs, $conn_cfg->{port_groups}->{$key}->{ports};
        }
        return \@port_cfgs;
    }

    sub _get_free_port_group_id {
        my ($conn_cfg) = @_;

        my %id_lookup = map { $conn_cfg->{port_groups}->{$_}->{id} => 1 }
                                        keys %{$conn_cfg->{port_groups}};

        my $found;
        my $id = 0;
        while(!$found) {
            if(!defined $id_lookup{$id}) {
                $found = 1;
            } else {
                ++$id;
            }
        }
        return $id;
    }

    sub _add_new_port_group {
        my ($conn_cfg, $storeid, $port_str, $ports) = @_;

        # A legal port configuration is one that fully matches another port
        # configuration, or one that has all unique ports that are not part
        # of any configuration.
        if(!_is_legal_port_config($conn_cfg, $ports)) {
            my $port_cfgs = _get_all_port_configs($conn_cfg);

            my $msg = "The given ports must either be unique or match " .
                      "the ports from another storage pool.\n" .
                      "Current port configurations:";

            for my $port_cfg (@$port_cfgs) {
                $msg .= "\n" . join(', ', @$port_cfg);
            }

            throw $msg;
        }

        my $port_group_id = _get_free_port_group_id($conn_cfg);

        $conn_cfg->{port_groups}->{$port_str} = {
            id => $port_group_id,
            ports => $ports,
            storage_pools => {$storeid => Util::json_bool(1)},
        };
        $conn_cfg->{connection_groups}->{$port_group_id} = [];

        return $port_group_id;
    }

    # Get the connections configuration.
    # If nothrow is true, this will also initialize a basic config if the
    # config was not loaded.
    sub _read_conf {
        my ($connector, $no_throw) = @_;

        my %conn_cfg;
        my $untainted_serial = Util::untaint($connector->serial());
        if(!HSPV::PersistentCache::read_cache(_CONNECTIONS_CATEGORY,
                                              $untainted_serial,
                                              \%conn_cfg,
                                              0,
                                              _CONNECTIONS_NOLOCK)) {

            if(!$no_throw) {
                throw "Could not read connection configuration.";
            }
        }

        if(!defined $conn_cfg{port_groups}) {
            $conn_cfg{port_groups} = {};
        }
        if(!defined $conn_cfg{connection_groups}) {
            $conn_cfg{connection_groups} = {};
        }

        return \%conn_cfg;
    }

    # Write the configuration.
    sub _write_conf {
        my ($connector, $conn_cfg) = @_;

        my $untainted_serial = Util::untaint($connector->serial());
        if(!HSPV::PersistentCache::write_cache(_CONNECTIONS_CATEGORY,
                                               $untainted_serial,
                                               $conn_cfg,
                                               0,
                                               _CONNECTIONS_NOLOCK)) {
            throw "Failed to write connection configuration.";
        }
    }

    sub _delete_conf {
        my ($connector) = @_;

        my $untainted_serial = Util::untaint($connector->serial());
        if(!HSPV::PersistentCache::delete_cache(_CONNECTIONS_CATEGORY,
                                                $untainted_serial,
                                                _CONNECTIONS_NOLOCK)) {
            throw "Failed to delete connection configuration.";
        }
    }

    # Find the port group ID for the given context.
    sub find_port_group_id {
        my ($connector) = @_;

        my $find = sub {
            my ($connector) = @_;

            my $conn_cfg = _read_conf($connector);

            my $ports = $connector->ports();
            my $port_str = join(_CONNECTIONS_PORT_STR_SEPARATOR, @$ports);

            return $conn_cfg->{port_groups}->{$port_str}->{id};
        };

        my $id;
        PVE::Cluster::cfs_lock_domain(_lock_name($connector),
                                      _CONNECTIONS_LOCK_TIMEOUT,
                                      sub { $id = $find->($connector); }
        );

        if($@) {
            throw $@;
        }

        return $id;
    }

    # Add a storage pool to the given conf.
    # This will not save anything.
    sub _add_storage_pool_to_conf {
        my ($conn_cfg, $storeid, $ports) = @_;

        my $port_str = join(_CONNECTIONS_PORT_STR_SEPARATOR, @$ports);

        my $port_group_id;
        if(defined $conn_cfg->{port_groups}->{$port_str}) {
            $port_group_id = $conn_cfg->{port_groups}->{$port_str}->{id};
            $conn_cfg->{port_groups}->{$port_str}->{storage_pools}->
                                {$storeid} = Util::json_bool(1);
        } else {
            $port_group_id = _add_new_port_group($conn_cfg, $storeid,
                                                 $port_str, $ports);
        }

        return $port_group_id;
    }

    # This will throw if the storage pool port configuration is not
    # compatible with the existing port configurations.
    # This returns the port group ID.
    sub add_storage_pool {
        my ($connector) = @_;

        my $add = sub {
            my ($connector) = @_;

            my $conn_cfg = _read_conf($connector, 1);

            my $port_group_id =
                _add_storage_pool_to_conf($conn_cfg, $connector->storeid(),
                                          $connector->ports());

            _write_conf($connector, $conn_cfg);
            return $port_group_id;
        };

        my $id;
        PVE::Cluster::cfs_lock_domain(_lock_name($connector),
                                      _CONNECTIONS_LOCK_TIMEOUT,
                                      sub { $id = $add->($connector); }
        );

        if($@) {
            throw $@;
        }

        return $id;
    }

    # Add a connection in the form of a group.
    # This does not track individual connections, only on the meta-level
    # servers, host groups, subsystems.
    sub add_connection {
        my ($connector, $connection_group_name) = @_;

        my $add = sub {
            my ($connector, $port_group_id, $connection_group_name) = @_;

            my $conn_cfg = _read_conf($connector);

            push @{ $conn_cfg->{connection_groups}->{$port_group_id} },
                $connection_group_name;

            _write_conf($connector, $conn_cfg);
            return;
        };

        PVE::Cluster::cfs_lock_domain(_lock_name($connector),
                                      _CONNECTIONS_LOCK_TIMEOUT,
                                      sub {
                                        $add->($connector,
                                               $connector->get_port_group_id(),
                                               $connection_group_name); }
        );

        if($@) {
            throw $@;
        }

        return;
    }

    # Remove the storage pool and other necessary entities from the given
    # configuration.
    # This will not write the configuration file.
    # This returns a list of connection groups that need to be cleaned up if
    # the changes are saved.
    sub _remove_storage_pool_from_conf {
        my ($conn_cfg, $storeid, $ports) = @_;

        my @connection_groups_to_clean;

        my $port_str = join(_CONNECTIONS_PORT_STR_SEPARATOR, @$ports);

        delete $conn_cfg->{port_groups}->{$port_str}->{storage_pools}->
                                                                {$storeid};

        # If we're the last key, there's no more storage pools using
        # this configuration and we can clean up the servers/host groups/
        # subsystems.
        if(!%{ $conn_cfg->{port_groups}->{$port_str}->{storage_pools} }) {

            Log::info("Removed last storage pool from connections for " .
                        "port group $port_str. Removing connection groups.");

            # Get the ID.
            my $id = $conn_cfg->{port_groups}->{$port_str}->{id};

            # Clean up the connections.
            my $connection_groups = $conn_cfg->{connection_groups}->{$id};
            push @connection_groups_to_clean, @$connection_groups;

            # Delete the group and connections.
            delete $conn_cfg->{port_groups}->{$port_str};
            delete $conn_cfg->{connection_groups}->{$id};
        }

        return \@connection_groups_to_clean;
    }

    # Call this with an array of connections and a connector to clean
    # up any connections in the list.
    sub _do_connection_cleanup {
        my ($connector, $connection_groups_to_clean) = @_;

        if(@$connection_groups_to_clean) {
            Log::info("Cleaning up @$connection_groups_to_clean " .
                        " connection groups.");
            $connector->cleanup_connections($connection_groups_to_clean);
        }
    }

    # Remove the storage pool from the connections config.
    # If this was the last storage pool in the port group, this
    # will tell the context to dispose of a list of connection groups
    # (servers/host groups).
    sub remove_storage_pool {
        my ($connector) = @_;

        my $remove = sub {
            my ($connector) = @_;

            my $conn_cfg = _read_conf($connector);

            my $connection_groups_to_clean =
                _remove_storage_pool_from_conf($conn_cfg,
                                               $connector->storeid(),
                                               $connector->ports());

            _do_connection_cleanup($connector, $connection_groups_to_clean);

            if(!%{ $conn_cfg->{port_groups} }) {
                _delete_conf($connector);
            } else {
                _write_conf($connector, $conn_cfg);
            }
        };

        PVE::Cluster::cfs_lock_domain(_lock_name($connector),
                                      _CONNECTIONS_LOCK_TIMEOUT,
                                      sub { $remove->($connector); }
        );

        if($@) {
            throw $@;
        }

        return;
    }

    # Change the ports in the connections config for this store.
    # This effectively adds and removes a storage pool from the connections
    # (including potential cleanup) without breaking things.
    sub change_ports {
        my ($connector, $new_ports) = @_;

        my $update = sub {
            my ($connector) = @_;

            my $conn_cfg = _read_conf($connector);

            my $connection_groups_to_clean =
                _remove_storage_pool_from_conf($conn_cfg,
                                               $connector->storeid(),
                                               $connector->ports());

            _do_connection_cleanup($connector, $connection_groups_to_clean);

            _add_storage_pool_to_conf($conn_cfg, $connector->storeid(),
                                      $new_ports);

            _write_conf($connector, $conn_cfg);
        };

        PVE::Cluster::cfs_lock_domain(_lock_name($connector),
                                      _CONNECTIONS_LOCK_TIMEOUT,
                                      sub { $update->($connector); }
        );

        if($@) {
            throw $@;
        }

        return;

    }
}

####################################################
# PVE::Storage::Custom::HitachiHSPVPlugin::StorageConfig package
####################################################

package PVE::Storage::Custom::HitachiHSPVPlugin::StorageConfig {

    use strict;
    use warnings;

    BEGIN {
        *Util:: = *HSPV::Util::;
        *Context:: =
            *PVE::Storage::Custom::HitachiHSPVPlugin::Context::;
        *throw = \&HSPV::Util::throw;
    }

    sub init_cfg {
        my ($storeid, $scfg) = @_;

        if(defined $storeid) {
            Log::set_id($storeid);
        }
        return;
    }

    use constant _PERSISTENT_CACHE_CREDENTIALS_CATEGORY => 'credentials';

    sub load_credentials {
        my ($storeid) = @_;

        my %out_data;
        if(HSPV::PersistentCache::read_cache(
                                        _PERSISTENT_CACHE_CREDENTIALS_CATEGORY,
                                        $storeid, \%out_data, 1)) {
            return $out_data{password};
        }

        return undef;
    }

    sub set_credentials {
        my ($storeid, $password) = @_;

        my $content = { password => $password };
        if(!HSPV::PersistentCache::write_cache(
                                        _PERSISTENT_CACHE_CREDENTIALS_CATEGORY,
                                        $storeid, $content, 1)) {
            throw "Failed to set credentials for '$storeid'.";
        }
        return;
    }

    sub destroy_credentials {
        my ($storeid) = @_;

        if(!HSPV::PersistentCache::delete_cache(
                                        _PERSISTENT_CACHE_CREDENTIALS_CATEGORY,
                                        $storeid)) {
            Log::error("Removing credientials for '$storeid' failed: $!");
        }

        return;
    }

    sub address {
        my ($scfg) = @_;
        return $scfg->{hspv_address};
    }

    sub username {
        my ($scfg) = @_;
        return $scfg->{hspv_username};
    }

    sub password {
        my ($scfg) = @_;
        return $scfg->{hspv_password};
    }

    sub is_named_pool {
        my ($scfg) = @_;
        !Util::is_numeric($scfg->{hspv_pool});
    }

    sub pool {
        my ($scfg) = @_;
        return $scfg->{hspv_pool};
    }

    sub ports {
        my ($scfg) = @_;

        return _parse_ports($scfg->{hspv_ports});
    }

    sub hmo {
        my ($scfg) = @_;

        return HSPV::Config::hmo();
    }

    sub ldev_range {
        my ($scfg) = @_;
        return _parse_ldev_range($scfg->{hspv_ldev_range});
    }

    sub _parse_ports {
        my ($ports, $leave_dupes) = @_;

        if(!defined $ports || $ports eq "") {
            return; # undefined
        }

        my @port_array = split(/,/, $ports);

        use constant {
            PORT_REGEX => "[Cc][Ll][0-9A-Ga-g]-[A-Ha-hJ-Nj-nP-Rp-r]",
        };

        my $port_regex = PORT_REGEX; # can't use constant directly.
        for my $i (0 .. $#port_array) {
            if($port_array[$i] !~ /\A$port_regex\z/) {
                return; # undefined
            }
            $port_array[$i] = uc($port_array[$i]);
        }

        if(!$leave_dupes) {
            my %port_hash;
            foreach my $port (@port_array) {
                $port_hash{$port} = undef;
            }
            @port_array = ();
            foreach my $port (keys %port_hash) {
                push @port_array, $port;
            }
        }

        # Sort the array so it will always match another configured
        # set of ports that are the same.
        @port_array = sort @port_array;
        return \@port_array;
    }

    sub _check_ldev {
        my ($ldev) = @_;

        use constant {
            MIN_LDEV => 0,
            MAX_LDEV => 65280,
        };
        if(!defined $ldev || $ldev<MIN_LDEV || $ldev>MAX_LDEV) {
            return;
        }
        return 1;
    }

    sub _check_ldev_range {
        my ($start, $end) = @_;

        if(!_check_ldev($start) || !_check_ldev($end)) {
            return;
        }
        if($start>$end) {
            return;
        }
        return 1;
    }

    sub _parse_cu_ldev {
        my ($cu_ldev) = @_;

        use constant {
            CU_LDEV_REGEX => "[0-9A-Fa-f][0-9A-Fa-f]:[0-9A-Fa-f][0-9A-Fa-f]",
        };

        my $cu_ldev_regex = CU_LDEV_REGEX; # Can't use constant directly.
        if($cu_ldev !~ /\A$cu_ldev_regex\z/) {
            return; # undefined
        }

        # This subroutine does not require any validation as it should
        # have already been validated.
        my @ldev_array = split(/:/, $cu_ldev, 2);
        my $value = hex($ldev_array[1]) + (hex($ldev_array[0]) << 8);
        return $value;
    }

    sub _parse_ldev_range {
        my ($ldev_range) = @_;

        # Having undef range is legal.
        if(!defined $ldev_range) {
            return;
        }

        my @ldev_array = split(/-/, $ldev_range, 2);
        if(@ldev_array==2) {
            my $is_numeric = Util::is_numeric($ldev_array[0]);
            my $is_numeric2 = Util::is_numeric($ldev_array[1]);

            if($is_numeric!=$is_numeric2) {
                return; # undefined
            }

            if(!$is_numeric) {
                $ldev_array[0] = _parse_cu_ldev($ldev_array[0]);
                $ldev_array[1] = _parse_cu_ldev($ldev_array[1]);
            }

            if(!_check_ldev_range($ldev_array[0], $ldev_array[1])) {
                return; # undefined
            }
        } else {
            return; # undefined
        }

        # Return it like this so it can be expanded.
        return $ldev_array[0], $ldev_array[1];
    }

    sub _validate_storeid {
        my ($storeid) = @_;

        # 1. The name must be no longer than
        #    PVE::Storage::Custom::HitachiHSPVPlugin::MAX_NAME_LENGTH
        #    characters minus the length of these two combined:
        #       - PVE::Storage::Custom::HitachiHSPVPlugin::HSPV_NAME_HEADER
        #       - PVE::Storage::Custom::HitachiHSPVPlugin::MAX_VMID_LENGTH
        #           +1 for VMID separator
        #    (17 characters max).
        # 2. PVE already has strict conventions otherwise, but we'll duplicate
        #    the same check they already make in case it changes.
        #    Namely, alphanumeric, understore, dash, period, and must start
        #    with an alpha character.
        #
        my $max_len =
            PVE::Storage::Custom::HitachiHSPVPlugin::MAX_NAME_LENGTH;
        my $header_len =
            length(PVE::Storage::Custom::HitachiHSPVPlugin::HSPV_NAME_HEADER);
        my $vmid_len =
            PVE::Storage::Custom::HitachiHSPVPlugin::MAX_VMID_LENGTH+1;

        # Case 1:
        my $max_id_len = $max_len-$header_len-$vmid_len;
        if(length($storeid)>$max_id_len) {
            throw "ID '$storeid' is too long. " .
                        "It must be <= $max_id_len characters.";
        }

        # Case 2:
        if(!Util::is_name_valid($storeid)) {
            throw "$storeid is not a valid ID.";
        }

        return;
    }

    sub validate_ldev_range_or_die {
        my ($ldev_range_str) = @_;

        my $ldev_range = SC::_parse_ldev_range($ldev_range_str);
        if(!defined $ldev_range) {
            Log::error("Invalid hspv_ldev_range.");
            throw "'hspv_ldev_range' must have a valid range in the " .
                "format #-# or CU:LDEV-CU:LDEV.";
        }

        return;
    }

    sub validate_ports_or_die {
        my ($ports_str) = @_;

        my $ports = _parse_ports($ports_str);
        if(!defined $ports) {
            Log::error("Invalid 'hspv_ports'.");
            throw "'hspv_ports' must at least one valid port in the format " .
                "CLX-Y.";
        } else {
            my $unfiltered_ports = _parse_ports($ports_str, 1);
            if(@$ports != @$unfiltered_ports) {
                Log::warning("Some ports were duplicated in the config.");
            }
        }

        return;
    }

    # Validate the configuration or die.
    sub validate_or_die {
        my ($storeid, $scfg, $sensitive) = @_;

        # Validate our storeid.
        _validate_storeid($storeid);

        # Fairly simple validation that we may choose to expand in the future.
        if(!defined $scfg->{hspv_address} || $scfg->{hspv_address} eq "") {
            Log::error("Invalid 'hspv_address'.");
            throw "'hspv_address' must be provided and not be empty.";
        }
        if(!defined $scfg->{hspv_username} || $scfg->{hspv_username} eq "") {
            Log::error("Invalid 'hspv_username'.");
            throw "'hspv_username' must be provided and not be empty.";
        }
        if(!defined $sensitive->{hspv_password} ||
                $sensitive->{hspv_password} eq "") {
            Log::error("Invalid 'hspv_password'.");
            throw "'hspv_password' must be provided and not be empty.";
        }
        if(!defined $scfg->{hspv_pool} || $scfg->{hspv_pool} eq "") {
            Log::error("Invalid 'hspv_pool'.");
            throw "'hspv_pool' must be provided and not be empty.";
        }
        if(!defined $scfg->{hspv_ports} || $scfg->{hspv_ports} eq "") {
            Log::error("Invalid 'hspv_ports'.");
            throw "'hspv_ports' must be provided and not be empty.";
        }
        validate_ports_or_die($scfg->{hspv_ports});
        if(defined $scfg->{hspv_ldev_range}) {
            validate_ldev_range_or_die($scfg->{hspv_ldev_range});
        }
    }

    sub _log_storage_config_value {
        my ($name, $value, $is_dbg, $context) = @_;

        $context = $context // "CONFIG";
        if(defined $is_dbg && $is_dbg) {
            Log::debug("$context: $name = $value");
        } else {
            Log::info("$context: $name = $value");
        }
    }

    # Log the storage config with the given context.
    # If no context is specified, the context will be "CONFIG".
    sub log_storage_config {
        my ($storeid, $scfg, $is_dbg, $context) = @_;

        _log_storage_config_value("storeid", $storeid, $is_dbg, $context);

        my $censor_text = Util::default_censor_string();

        my %printcfg = %$scfg;
        foreach my $key (keys %printcfg) {
            my $value = $censor_text;
            if($key ne "hspv_password") {
                $value = $printcfg{$key};
            }
            _log_storage_config_value($key, $value, $is_dbg, $context);
        }
    }

    # Check whether a multipath config file contains a vendor "HITACHI" entry,
    # ignoring comment lines.
    sub _file_has_hitachi_vendor {
        my ($file) = @_;

        open(my $fh, '<', $file) or return 0;
        while(my $line = <$fh>) {
            $line =~ s/#.*//;   # Strip inline/full-line comments
            if($line =~ /vendor\s+"HITACHI"/) {
                close($fh);
                return 1;
            }
        }
        close($fh);
        return 0;
    }

    # Check whether the multipath requirements for HITACHI are satisfied.
    # This is relevant only for Context::_PORT_TYPE_ISCSI and
    # Context::_PORT_TYPE_FC port types.
    # Returns true (1) if satisfied, false (0) otherwise.
    sub satisfy_multipath_req {
        my ($context) = @_;

        my $port_type = $context->port_type();
        if($port_type eq Context::_PORT_TYPE_ISCSI() ||
                $port_type eq Context::_PORT_TYPE_FC()) {
            # (1) Verify multipathd is installed/executable.
            if(! -x "/sbin/multipathd" && ! -x "/usr/sbin/multipathd") {
                Log::warning("multipathd is not installed or executable.");
                return 0;
            }

            # (2) Verify /etc/multipath.conf exists.
            if(! -e "/etc/multipath.conf") {
                Log::warning("/etc/multipath.conf does not exist.");
                return 0;
            }

            # (3) Check /etc/multipath.conf for a vendor "HITACHI" entry.
            if(_file_has_hitachi_vendor("/etc/multipath.conf")) {
                return 1;
            }

            # (4) Check each file under /etc/multipath/conf.d/
            #     for vendor "HITACHI".
            if(-d "/etc/multipath/conf.d/") {
                if(opendir(my $dh, "/etc/multipath/conf.d/")) {
                    my @files = grep { -f "/etc/multipath/conf.d/$_" }
                                    readdir($dh);
                    closedir($dh);
                    for my $file (sort @files) {
                        my $path = "/etc/multipath/conf.d/$file";
                        if(_file_has_hitachi_vendor($path)) {
                            return 1;
                        }
                    }
                }
                Log::warning("No HITACHI vendor entry found in " .
                             "/etc/multipath.conf or " .
                             "/etc/multipath/conf.d/.");
            }
        } else {
            Log::debug("$port_type does not require " .
                       "multipath validation at this moment.");
            return 1;
        }

        return 0;
    }

}

####################################################
# HSPV::ApiClient package
####################################################

package HSPV::ApiClient {

    use strict;
    use warnings;
    use Digest::MD5;
    use HTTP::Headers;
    use HTTP::Request;
    use JSON::XS        qw(decode_json encode_json);
    use LWP::UserAgent;
    use MIME::Base64    qw(encode_base64);
    use URI::Escape     qw(uri_escape);
    use Time::HiRes;

    BEGIN {
        *Log:: = *HSPV::Log::;
        *Util:: = *HSPV::Util::;
        *Capacity:: = *HSPV::Util::Capacity;
        *throw = \&HSPV::Util::throw;
    }

    # Format a URL with the given parameters.
    # Note that if a URL is given with parameters already attached, it should
    # not also provide a parameter hash.
    sub _url_format_with_params {
        my ($url, $params_ref) = @_;

        if(defined $params_ref && keys %$params_ref) {
            my @params;
            while(my($k, $v) = each(%$params_ref)) {
                push(@params, uri_escape($k) . '=' . uri_escape($v));
            }

            $url .= "?" . join('&', @params);
        }

        return $url;
    }

    # Description: Make a HTTP request.
    # Parameters:
    #   $method is a string.
    #   $url is a URL string.
    #   %opts is an optional hash to additional options.
    #       Options:
    #           body: the raw body of the request [default=undef]
    #           params: hash of URL parameters (1:1) [default=undef]
    #           headers: hash of headers (1:1) [default=undef]
    #           validate_ssl: boolean true to validate SSL,
    #                         false to not validate [default=1]
    #           ssl_ca_file: The CA file to use for SSL [default='']
    #           timeout: timeout to set for request
    #                    [default=LWP::UserAgent default]
    #           nolog: boolean true to defer logging, false to log [default=0]
    #           verbose_log: boolean true to log verbose on this rqeuest, false
    #                        to log debug [default=0]
    # Return Value: A HTTP::Response object.
    sub http_request {
        my ($method, $url, %opts) = @_;

        my $body =         $opts{body};
        my $params =       $opts{params};
        my $headers =      $opts{headers};
        my $validate_ssl = $opts{validate_ssl} // 1;
        my $ssl_ca_file =  $opts{ssl_ca_file} // '';
        my $timeout =      $opts{timeout};
        my $nolog =        $opts{nolog}        // 0;
        my $verbose_log =  $opts{verbose_log}  // 0;

        $url = _url_format_with_params($url, $params);

        if(!$nolog) {
            if($verbose_log) {
                Log::verbose("Request: $method $url");
            } else {
                Log::debug("Request: $method $url");
            }
        }

        my $http_headers;
        if(defined $headers) {
            $http_headers = HTTP::Headers->new(%$headers);
        }

        my $user_agent = LWP::UserAgent->new();
        if(defined $timeout) {
            $user_agent->timeout($timeout);
        }

        # Set up SSL Validation
        if($validate_ssl) {
            Log::verbose("Enabling SSL validation for request to " .
                         "$url using '$ssl_ca_file'.");
            $user_agent->ssl_opts(
                SSL_verify_mode => 0x01,         # verify peer's SSL certs
                verify_hostname => 0,            # Do not verify hostname
                SSL_ca_file     => $ssl_ca_file, # Use a specific CA file
            );

        } else {
            Log::verbose("SSL validation disabled for request to $url.");
            $user_agent->ssl_opts(
                SSL_verify_mode => 0x00, # Do not verify peer's SSL certs
                verify_hostname => 0,    # Do not verify hostname
            );
        }

        # Create and execute HTTP request
        my $request = HTTP::Request->new($method, $url, $http_headers, $body);
        return $user_agent->request($request);
    }

    sub _log_http {
        my ($msg, $verbose_log) = @_;

        if($verbose_log) {
            Log::verbose($msg);
        } else {
            Log::debug($msg);
        }

        return;
    }

    # Log a JSON request if DEBUG is enabled.
    sub _log_request {
        my ($method, $url, $encoded_json, $verbose_log) = @_;

        if((!$verbose_log && Log::is_debug_enabled()) ||
           ($verbose_log && Log::is_verbose_enabled())) {

            my $msg;
            if(defined $encoded_json) {
                $encoded_json = Util::strip_newlines($encoded_json);
                $msg = "Request: $method $url: $encoded_json";
            } else {
                $msg = "Request: $method $url";
            }

            _log_http($msg);
        }
        return;
    }

    # Log a JSON response if DEBUG is enabled.
    sub _log_json_response{
        my ($encoded_json, $censor_keys, $verbose_log) = @_;

        if((!$verbose_log && Log::is_debug_enabled()) ||
           ($verbose_log && Log::is_verbose_enabled())) {

            my $msg;
            if(defined $encoded_json) {
                if(defined $censor_keys && @$censor_keys>0) {
                    my $censored = Util::censor_json_string($encoded_json,
                        $censor_keys);
                    my $censored_out =
                        Util::strip_newlines($censored);
                    $msg = "Response JSON: $censored_out";
                } else {
                    $encoded_json = Util::strip_newlines($encoded_json);
                    $msg = "Response JSON: $encoded_json";
                }
            } else {
                $msg = "Response JSON: NONE.";
            }

            _log_http($msg);
        }
    }

    # Description: Make a HTTP request with known JSON data and JSON return
    #   value. This will set the appropriate Content-Type and Content-Length
    #   headers (if they have not been provided already), and will
    #   deserialize the return value if the Content-Type is JSON.
    # Parameters:
    #   $method is a string.
    #   $url is a URL string.
    #   $json is a hash to convert to JSON. May be undef to handle JSON
    #       response.
    #   %opts is an optional hash to additional options.
    #       Options:
    #           params: hash of URL parameters (1:1) [default=undef]
    #           headers: hash of headers (1:1) [default=empty hash]
    #           validate_ssl: boolean true to validate SSL,
    #                         false to not validate [default=1]
    #           ssl_ca_file: The CA file to use for SSL [default='']
    #           timeout: timeout to set for request
    #                    [default=LWP::UserAgent default]
    #           nolog: boolean true to defer logging, false to log [default=0]
    #           verbose_log: boolean true to log verbose on this request, false
    #                        to log debug [default=0]
    #           censor_keys: list of keys whose values need to be censored
    #               in return JSON. This currently only censors top-level
    #               keys [default=undef]
    # Return Value: A list containing a HTTP::Response object and a hash
    #   of the serialized JSON if JSON was returned.
    sub http_request_json {
        my ($method, $url, $json, %opts) = @_;

        my $params =       $opts{params};
        my $headers =      $opts{headers}      // {};
        my $validate_ssl = $opts{validate_ssl} // 1;
        my $ssl_ca_file =  $opts{ssl_ca_file} // '';
        my $timeout =      $opts{timeout};
        my $nolog =        $opts{nolog}        // 0;
        my $verbose_log =  $opts{verbose_log}  // 0;
        my $censor_keys =  $opts{censor_keys};

        $url = _url_format_with_params($url, $params);

        # Decode JSON and set Content-Type.
        my $encoded_json;
        if(defined $json) {
            $encoded_json = encode_json($json);
        }

        if(!$nolog) {
            _log_request($method, $url, $encoded_json, $verbose_log);
        }

        if(defined $encoded_json && !exists $headers->{"Content-Type"}) {
            $headers->{"Content-Type"} = 'application/json';
        }
        if(defined $encoded_json && !exists $headers->{"Content-Length"}) {
            $headers->{"Content-Length"} = length($encoded_json);
        }

        # Set options.  nolog is always 1 as we log in this subroutine.
        # Params is not included as we build the URL in this subroutine.
        my %new_opts = (
            body => $encoded_json,
            headers => $headers,
            validate_ssl => $validate_ssl,
            ssl_ca_file => $ssl_ca_file,
            timeout => $timeout,
            nolog => 1,
        );

        # Make HTTP request.
        my $response = http_request($method, $url, %new_opts);

        # If JSON was returned, decode it.
        my $json_content;
        my $decoded_content;
        if(($response->content_type // "") =~ m{^application/json}i) {
            $decoded_content = $response->decoded_content;
            $json_content = decode_json($decoded_content);
        }

        if(!$nolog) {
            _log_json_response($json_content ? $decoded_content : undef,
                               $censor_keys, $verbose_log);
        }

        return ($response, $json_content);
    }

    # Create a persistent cache context for a token based on the address,
    # username, and password.
    sub _create_token_context {
        my ($address, $username, $password) = @_;

        use constant {
            HASH_SEPARATOR => '\t',
            HASH_SALT      => 0x213,
        };

        my $hash = Digest::MD5->new();
        $hash->add($address);
        $hash->add(HASH_SEPARATOR);
        $hash->add($username);
        $hash->add(HASH_SEPARATOR);
        $hash->add($password);
        $hash->add(HASH_SEPARATOR);
        $hash->add(HASH_SALT);
        return $hash->hexdigest();
    }

    use constant _PERSISTENT_CACHE_TOKEN_CATEGORY => "tokens";

    # Create the API client and connect to the storage if there is no token
    # in the cache and credentials have been provided.
    # If the username or password are undef, this class will be created as
    # a non-auth only class.  Only functionality that does not require
    # authentication can be used without triggering a die.
    sub new {
        my ($class, $address, $username, $password) = @_;

        my $token;

        my $no_auth_only = !defined $username || !defined $password;

        if(!$no_auth_only) {
            my $context = _create_token_context($address, $username, $password);
            my %out_data = ();
            if(HSPV::PersistentCache::read_cache(
                                        _PERSISTENT_CACHE_TOKEN_CATEGORY,
                                        $context, \%out_data, 1)) {
                $token = $out_data{token};
            }
        }

        my $self = {
            address                   => $address,
            username                  => $username,
            password                  => $password,
            token                     => $token,
            timeout                   => HSPV::Config::http_timeout(),
            validate_ssl              => HSPV::Config::validate_ssl(),
            ssl_ca_file               => HSPV::Config::ssl_ca_file(),
            max_retries               => HSPV::Config::max_http_retries(),
            max_token_refresh_retries => 1,
            retry_wait                => HSPV::Config::http_retry_wait(),
            admin_async_wait_ms       => HSPV::Config::admin_async_wait_ms(),
            no_auth_only              => $no_auth_only,
        };

        if(!$self->{validate_ssl}) {
            Log::warning("SSL validation is not configured.");
        } elsif(!$self->{ssl_ca_file}) {
            Log::error("No SSL CA file has been provided.");
        }

        my $ref = bless $self, $class;

        if(!defined $token && !$no_auth_only) {
            # This will throw if we fail to initialize our session.
            $ref->_init_session(HSPV::Config::http_connect_timeout());
        }

        return $ref;
    }

    # Format a path to a full API URL.
    sub _format_url {
        my ($class, $path) = @_;

        use constant {
            SCHEME    => "https://",
            BASE_PATH => "/ConfigurationManager",
        };

        # If we're taking a URL from an actual API return value,
        # it will start with /ConfigurationManager/ already.
        my $url = SCHEME . $class->{address};
        if(Util::starts_with($path, BASE_PATH . "/")) {
            $url .= $path;
        } else {
            $url .= BASE_PATH . $path;
        }
        return $url;
    }

    sub _has_retry_ssb {
        my ($class, $result, $retry_on_ssb) = @_;

        if(defined $retry_on_ssb && $result->has_ssb()) {
            foreach my $ssb_pair (@$retry_on_ssb) {
                my ($ssb1, $ssb2) = @$ssb_pair;
                if($result->ssb1()==$ssb1 && $result->ssb2()==$ssb2) {
                    return 1;
                }
            }
        }

        return;
    }

    # Check to see if we need to do a retry and we're allowed to.
    # If we are allowed to, wait for our retry timer and then return
    # that we'd like to retry.
    sub _prepare_retry {
        my ($class, $result, $retry_context, $retry_on_ssb) = @_;

        my $should_retry;
        my $nowait;
        # If our result wants to retry, check to see if we have retries
        # remaining.  If we do, decrement our retries remaining and
        # set our should_retry flag.
        if($result->should_retry() ||
                $class->_has_retry_ssb($result, $retry_on_ssb)) {
            if($result->is_auth_fail() &&
                    $retry_context->{remaining_token_refresh_retries}>0) {
                $retry_context->{remaining_token_refresh_retries} =
                    $retry_context->{remaining_token_refresh_retries}-1;
                $should_retry = 1;
                $nowait = 1; # Don't wait for a token refresh.
            } elsif(!$result->is_auth_fail() &&
                    $retry_context->{remaining_retries}>0) {
                $retry_context->{remaining_retries} =
                    $retry_context->{remaining_retries}-1;
                $should_retry = 1;
            }
        }

        # If we're declaring we should retry, do a wait in seconds
        # before we retry.
        if($should_retry && !$nowait) {
            sleep($class->{retry_wait});
        }

        return $should_retry;
    }

    sub _is_admin_async_complete {
        my ($result) = @_;

        my $content = $result->{content};
        return (defined $content->{progress} &&
                $content->{progress} eq "completed" &&
                defined $content->{status} &&
                $content->{status} eq "normal");
    }

    # Wait out an admin async request. The result will have one or more
    # statusResource objects to wait for completion.
    # This code currently assumes only a single statusResource.
    # If we end up using APIs that return more it will have to be revisisted.
    # An error log will be produced if there are more or less than one status
    # resources.
    sub _wait_admin_async {
        my ($class, $result) = @_;

        my $status_resources = $result->admin_api_async_status_resources();
        if(@$status_resources != 1) {
            Log::error("Unexpected number of status resources returned: " .
                       "@$status_resources.");
        }

        my $status_resource = $status_resources->[0];
        my $new_result;
        do {
            if(defined $new_result) {
                Time::HiRes::sleep($class->{admin_async_wait_ms}/1000.0);
            }

            # An error will throw.
            $new_result = $class->_query_status_resource($status_resource);

        } while(!_is_admin_async_complete($new_result));

        return $new_result;
    }

    # Description: Make a HTTP request with error checking, retries, JSON
    #   handling, and PF-REST job/admin api "job" handling using a partial
    #   path.
    # Parameters:
    #   $method is a string.
    #   $path is a relative path to the API (part after base path).
    #       It may include parameters (or set params in %opts).
    #   %opts is an optional hash to additional options.
    #       Options:
    #           json: hash to convert to JSON
    #           params: hash of URL parameters (1:1) [default=undef]
    #           headers: hash of headers (1:1) [default=empty hash]
    #           timeout: Timeout value to use as an override
    #               [default=default class timeout]
    #           censor_keys: list of keys whose values need to be censored
    #               in return JSON. This currently only censors top-level
    #               keys [default=undef]
    #           async: boolean true to set headers for a PF-REST job
    #               [default=0].
    #           admin_async: boolean true to perform command status checks
    #               until admin API has completed [default=0]
    #           no_auth_retry: boolean true to disable auth retries,
    #               false to enable [default=0]
    #           basic_auth: boolean true to use basic auth. Otherwise session
    #               auth.  Ignored if noauth is true [default=0]
    #           noauth: boolean true to not specify any authorization header.
    #               If this is true and auth is provided, auth will be ignored.
    #               [default=0]
    #           retry_on_ssb: list of SSB pairs to retry on [default=undef]
    #           ignorable_errors: list of SSB pairs that are ignorable
    #               [default=undef]
    #           ignorable_codes: list of HTTP return codes thare are ignorable
    #               [default=undef]
    #           verbose_log: boolean true to log verbose on this request, false
    #                        to log debug [default=0]
    # Return Value: Our result object.
    # Notes: If this class is "no_auth_only", and a call that is not marked
    #   "noauth" is made then this subroutine will die.
    # If a non-ignorable error occurs, a string describing the error is
    #   "thrown".
    sub _http_request {
        my ($class, $method, $path, %opts) = @_;

        # Parse our options.
        my $json =             $opts{json};
        my $params =           $opts{params};
        my $headers =          $opts{headers}           // {};
        my $timeout =          $opts{timeout}           // $class->{timeout};
        my $censor_keys =      $opts{censor_keys};
        my $async =            $opts{async}             // 0;
        my $admin_async =      $opts{admin_async}       // 0;
        my $no_auth_retry =    $opts{no_auth_retry}     // 0;
        my $basic_auth =       $opts{basic_auth}        // 0;
        my $noauth =           $opts{noauth}            // 0;
        my $retry_on_ssb =     $opts{retry_on_ssb};
        my $ignorable_errors = $opts{ignorable_errors};
        my $ignorable_codes =  $opts{ignorable_codes};
        my $verbose_log =      $opts{verbose_log}       // 0;

        # If we're no_auth_only and haven't been given the noauth option,
        # bail out.
        if(!$noauth && $class->{no_auth_only}) {
            throw "This instance can only make unauthenticated calls.";
        }

        # Set our retry context.
        # _prepare_retry() will adjust the retry counts each time it requests a
        # retry.
        my %retry_context = (
            remaining_retries               => $class->{max_retries},
            remaining_token_refresh_retries =>
                $no_auth_retry ? 0 : $class->{max_token_refresh_retries},
        );

        # Build full URL.
        my $url = $class->_format_url($path);

        if(!defined $json) {
            # PF-REST complains if no content length is provided.
            # So, if we have no content, set it here.
            # http_request_json will set the content length if there is
            # content.
            $headers->{"Content-Length"} = 0;
        }

        # Create/update headers if $async is true.
        if($async) {
            $headers->{"Response-Job-Status"} = "Completed";
        }

        # Add authorization header if $noauth is false.
        if(!$noauth) {
            $headers->{Authorization} = $basic_auth ?
                $class->_create_basic_auth_string() :
                $class->_create_session_auth_string();
        }

        # Build request options for http_request_json.
        my %request_opts = (
            params => $params,
            headers => $headers,
            censor_keys => $censor_keys,
            validate_ssl => $class->{validate_ssl},
            ssl_ca_file => $class->{ssl_ca_file},
            timeout => $timeout,
            verbose_log => $verbose_log,
        );

        my $result;

        do {
            # If this is a retry and we failed with an authentication failure,
            # re-init our session.
            if(defined $result && $result->is_auth_fail()) {
                # This will throw if we couldn't refresh our session.
                # We can only try this once.
                $class->_init_session();
                # Update our token in our header.
                $headers->{Authorization} =
                    $class->_create_session_auth_string();
            }

            # Make request and parse response.
            my ($response, $json_content) =
                http_request_json($method, $url, $json, %request_opts);
            $result = HSPV::ApiClient::Result->new($response, $json_content);

            # Log any error.
            if($result->is_error($ignorable_errors, $ignorable_codes)) {
                # We had an error that was unignorable, so log it.
                Log::error($result->get_format_error_message());
            } elsif($result->is_error()) {
                # If we have an error ignoring ignorable stuff, it means we can
                # ignore this error and should log it as an info message.
                Log::debug("Ignorable error occurred: " .
                           "${ \$result->get_format_error_message() }");
            }

            # Retry if allowed.
        } while($class->_prepare_retry($result, \%retry_context,
                					   $retry_on_ssb));

        # If we resulted in an error, bail out now with our formatted message
        # as long as we weren't an ignorable error.
        if($result->is_error($ignorable_errors, $ignorable_codes)) {
            throw $result->get_format_error_message();
        }

        # Get admin async result if we succeeded and we expect adminasync.
        if($admin_async && $result->is_admin_async_reply()) {
			# If an error occurs, this will throw for us through recursion.
            $result = $class->_wait_admin_async($result);
        }

        # Return our result.
        return $result;
    }

    # Create a basic authentication header string.
    sub _create_basic_auth_string {
        my ($class) = @_;

        use constant {
            AUTH_SEPARATOR    => ':',
            BASIC_AUTH_HEADER => "Basic ",
        };

        my $b64 = encode_base64($class->{username} . AUTH_SEPARATOR .
            $class->{password});
        return BASIC_AUTH_HEADER . $b64;
    }

    # Create a session authentication header string.
    sub _create_session_auth_string {
        my ($class) = @_;

        use constant {
            SESSION_AUTH_HEADER => "Session ",
        };

        return SESSION_AUTH_HEADER . $class->{token};
    }

    # Initialize a session and save it to the persistent cache.
    sub _init_session {
        my ($class, $timeout) = @_;

        my %opts = (
            no_auth_retry      => 1,
            censor_keys        => ["token"],
            basic_auth         => 1,
        );

        if(defined $timeout) {
            $opts{timeout} = $timeout;
        }

        my $content =
            $class->_POST("/v1/objects/sessions", undef, %opts)->{content};
        $class->{token} = $content->{token};

        my $context = _create_token_context($class->{address},
            $class->{username}, $class->{password});
        if(!HSPV::PersistentCache::write_cache(
                                        _PERSISTENT_CACHE_TOKEN_CATEGORY,
                                        $context, $content, 1)) {
            Log::error("Failed to write token to cache.");
        }
    }

    # Get the result resource for a normal API call.
    sub _get_result_resource {
        my ($class, $result) = @_;

        # This only gets the first resource.
        # If we call functionality that might return more than 1 we will
        # have to revisit this.
        my @parts = split(/\//, $result->{content}->{affectedResources}->[0]);
        return $parts[-1];
    }

    # Query a resource returned from the admin API.
    sub _query_status_resource {
        my ($class, $resource) = @_;

        return $class->_GET($resource);
    }

    # Get generic request options from the given opts and return
    # a new hash with them.  If none are detected, the new hash will
    # exist but be empty.
    # Supported opts:
    #   timeout: Timeout value to use as an override
    #       [default=default class timeout]
    #   retry_on_ssb: list of SSB pairs to retry on [default=undef]
    #   ignorable_errors: list of SSB pairs that are ignorable
    #       [default=undef]
    #   ignorable_codes: list of HTTP return codes thare are ignorable
    #       [default=undef]
    #   verbose_log: boolean true to log verbose on this request, false
    #       to log debug [default=0]
    sub _get_generic_request_opts {
        my ($class, $opts_in) = @_;

        my %opts;
        $opts{timeout} = $opts_in->{timeout} if defined $opts_in->{timeout};
        $opts{retry_on_ssb} = $opts_in->{retry_on_ssb}
            if defined $opts_in->{retry_on_ssb};
        $opts{ignorable_errors} = $opts_in->{ignorable_errors}
            if defined $opts_in->{ignorable_errors};
        $opts{ignorable_codes} = $opts_in->{ignorable_codes}
            if defined $opts_in->{ignorable_codes};
        $opts{verbose_log} = $opts_in->{verbose_log}
            if defined $opts_in->{verbose_log};

        return \%opts;
    }

    # This appends an option to a potentially existing array.
    # If the array does not exist, one is created.
    # The result is returned.
    sub _append_array_opt {
        my ($class, $existing_array_or_undef, $value) = @_;

        if(defined $existing_array_or_undef) {
            push @$existing_array_or_undef, $value;
            return $existing_array_or_undef;
        }

        return [$value];
    }

    ######################
    # HTTP Request Methods
    ######################

    # Description: Make a POST request.
    # Parameters:
    #   $path is a relative path to the API (part after base path).
    #       It may include parameters (or set params in %opts).
    #   %opts is an optional hash to additional options.
    #       Options:
    #           json: hash JSON content to send [default=undef]
    #           params: hash of URL parameters (1:1) [default=undef]
    #           headers: hash of headers (1:1) [default=undef]
    #           noauth: specify true value to not use authorization [default=0]
    #       Generic options:
    #           See _get_generic_request_opts()
    # Return Value: Result object.
    # Dies: If unignorable error occurs.
    sub _GET {
        my ($class, $path, %opts) = @_;

        return $class->_http_request("GET", $path, %opts);
    }

    # Description: Make a POST request.
    # Parameters:
    #   $path is a relative path to the API (part after base path).
    #       It may include parameters (or set params in %opts).
    #   $json is the hash content to post as JSON. This may be undef.
    #   %opts is an optional hash to additional options.
    #       Options:
    #           params: hash of URL parameters (1:1) [default=undef]
    #           headers: hash of headers (1:1) [default=undef]
    #           sensitive_response: boolean true to obscure response JSON,
    #                               false to log it [default=0]
    #           async: boolean true to set headers for a PF-REST job
    #               [default=0].
    #           admin_async: boolean true to perform command status checks
    #               until admin API has completed [default=0]
    #           no_auth_retry: boolean true to disable auth retries,
    #               false to enable [default=0]
    #           basic_auth: boolean true to use basic auth. Otherwise session
    #               auth.  Ignored if noauth is true [default=0]
    #       Generic options:
    #           See _get_generic_request_opts()
    # Return Value: Result object.
    # Dies: If unignorable error occurs.
    sub _POST {
        my ($class, $path, $json, %opts) = @_;

        if(defined $json) {
            $opts{json} = $json;
        }

        return $class->_http_request("POST", $path, %opts);
    }

    # Description: Make a PUT request.
    # Parameters:
    #   $path is a relative path to the API (part after base path).
    #       It may include parameters (or set params in %opts).
    #   $json is the hash content to post as JSON. This may be undef.
    #   %opts is an optional hash to additional options.
    #       Options:
    #           params: hash of URL parameters (1:1) [default=undef]
    #           headers: hash of headers (1:1) [default=undef]
    #           async: boolean true to set headers for a PF-REST job
    #               [default=0].
    #           admin_async: boolean true to perform command status checks
    #               until admin API has completed [default=0]
    #       Generic options:
    #           See _get_generic_request_opts()
    # Return Value: Result object.
    # Dies: If unignorable error occurs.
    sub _PUT {
        my ($class, $path, $json, %opts) = @_;

        if(defined $json) {
            $opts{json} = $json;
        }

        return $class->_http_request("PUT", $path, %opts);
    }

    # Description: Make a PATCH request.
    # Parameters:
    #   $path is a relative path to the API (part after base path).
    #       It may include parameters (or set params in %opts).
    #   $json is the hash content to post as JSON. This may be undef.
    #   %opts is an optional hash to additional options.
    #       Options:
    #           params: hash of URL parameters (1:1) [default=undef]
    #           headers: hash of headers (1:1) [default=undef]
    #           async: boolean true to set headers for a PF-REST job
    #               [default=0].
    #           admin_async: boolean true to perform command status checks
    #               until admin API has completed [default=0]
    #       Generic options:
    #           See _get_generic_request_opts()
    # Return Value: Result object.
    # Dies: If unignorable error occurs.
    sub _PATCH {
        my ($class, $path, $json, %opts) = @_;

        if(defined $json) {
            $opts{json} = $json;
        }

        return $class->_http_request("PATCH", $path, %opts);
    }

    # Description: Make a DELETE request.
    # Parameters:
    #   $path is a relative path to the API (part after base path).
    #       It may include parameters (or set params in %opts).
    #   %opts is an optional hash to additional options.
    #       Options:
    #           json: hash JSON content to send [default=undef]
    #           params: hash of URL parameters (1:1) [default=undef]
    #           headers: hash of headers (1:1) [default=undef]
    #       Generic options:
    #           See _get_generic_request_opts()
    # Return Value: Result object.
    # Dies: If unignorable error occurs.
    sub _DELETE {
        my ($class, $path, %opts) = @_;

        return $class->_http_request("DELETE", $path, %opts);
    }

    #####################
    # API Constants
    #####################

    # Capacity Saving
    use constant {
        CSV_DISABLED                  => "disabled",
        CSV_COMPRESSION               => "compression",
        CSV_DEDUPLICATION_COMPRESSION => "deduplication_compression",
    };

    # Pair Status
    use constant {
        PAIRSTAT_SMPL => 'SMPL',
        PAIRSTAT_SMPP => 'SMPP',
        PAIRSTAT_COPY => 'COPY',
        PAIRSTAT_PAIR => 'PAIR',
        PAIRSTAT_PFUL => 'PFUL',
        PAIRSTAT_PSUS => 'PSUS',
        PAIRSTAT_PFUS => 'PFUS',
        PAIRSTAT_RCPY => 'RCPY',
        PAIRSTAT_PSUE => 'PSUE',
    };

    # Data Reduction Status
    use constant {
        DRSTAT_ENABLED     => "ENABLED",
        DRSTAT_DISABLED    => "DISABLED",
        DRSTAT_ENABLING    => "ENABLING",
        DRSTAT_REHYDRATING => "REHYDRATING",
        DRSTAT_DELETING    => "DELETING",
        DRSTAT_FAILED      => "FAILED",
        DRSTAT_CONVERTING  => "CONVERTING",
    };

    #####################
    # Return code constants
    #####################

    use constant {
        _HTTP_NOT_FOUND => 404,
    };

    #####################
    # Internal constants
    #####################

    use constant {
        _PF_SAVING_DEDUP_COMP => "compression_deduplication",
        _PF_SAVING_COMP       => "compression",
        _PF_SAVING_DISABLE    => "disabled",
    };

    use constant _NOT_SUPPORTED_MESSAGE =>
        "This API is not currently supported.";

    #####################
    # API Support Queries
    #####################

    # Whether or not this client has support for servers.
    sub has_server_support {
        my ($class) = @_;

        return 0;
    }

    # Whether or not this client has support for naming an LDEV during
    # LDEV creation.
    sub has_name_ldev_on_create_support {
        my ($class) = @_;

        return 0;
    }

    # Determine if querying all ports will return port IP information.
    sub has_ip_info_for_all_ports_query {
        my ($class) = @_;

        return 0;
    }

    #####################
    # API Implementations
    #####################

    # get_storage
    # Description: Get the storage associated with this object.
    # Parameters:
    #   %opts: an optional hash to additional options.
    #       Options:
    #           None
    #       Generic options:
    #           See _get_generic_request_opts()
    # Return: A hash containing storage information.
    # Result Hash:
    #   serial: The serial number of the storage.
    #   model: The storage model.
    #   storage_id: The storage ID.
    #   dkc_micro: The DKC microcode.
    #   ctl1_micro: The CTL1 microcode (or undef if none).
    #   ctl2_micro: The CTL2 microcode (or undef if none).
    sub get_storage {
        my ($class, %opts) = @_;

        my $request_opts = $class->_get_generic_request_opts(\%opts);

        my @storages;
        my $content = $class->_GET("/v1/objects/storages/instance",
                                   %$request_opts)->{content};
        return _convert_storage_pf($content);
    }

    # get_ports
    # Description: Get ports.
    # Parameters:
    #   %opts: an optional hash to additional options.
    #       Options:
    #           protocol: iSCSI or FC to get iSCSI or FC ports.
    #       Generic options:
    #           See _get_generic_request_opts()
    # Return: A list of port hashes.
    # Result Hashes:
    #   port: The port.
    #   protocol: The port protocol.
    #   wwn: The port WWN if FC.
    #   iqn: The port IQN if iSCSI.
    #   ipv4_address: The IPV4 address of the port if iSCSI. This is not
    #                 provided if has_ip_info_for_all_ports_query() is false.
    sub get_ports {
        my ($class, %opts) = @_;

        throw _NOT_SUPPORTED_MESSAGE;
    }

    # get_pools.
    # Description: Get pools.
    # Parameters:
    #   %opts: an optional hash to additional options.
    #       Options:
    #           name_hint: Text that should be included in the returned pool
    #                      name.  Does not only return exact matches.
    #           verbose_log: true to log verbose, false to log debug.
    #       Generic options:
    #           See _get_generic_request_opts()
    # Return: A list of pool hashes.
    # Result Hashes: See get_pool.
    sub get_pools {
        my ($class, %opts) = @_;

        my $name_hint = $opts{name_hint};

        my $request_opts = $class->_get_generic_request_opts(\%opts);

        my $content = $class->_GET('/v1/objects/pools',
                                   %$request_opts)->{content};

        my @pools;
        foreach my $pool (@{ $content->{data} } ) {
            if(!$name_hint || index($pool->{poolName}, $name_hint)!=-1) {
                push @pools, _convert_pool_pf($pool);
            }
        }

        return \@pools;
    }

    # get_pool
    # Description: Get a single pool by number.
    # Parameters:
    #   pool: The number of the pool to get.
    #   %opts: an optional hash to additional options.
    #       Options:
    #           None
    #       Generic options:
    #           See _get_generic_request_opts()
    # Return: A pool hash, or undef if the pool was not found.
    # Result Hash:
    #   id: The pool.
    #   name: The name of the pool.
    #   total_capacity: The total capacity of the pool in a
    #                   HSPV::Util::Capacity object.
    #   used_capacity: The used capacity of the pool in HSPV::Util::Capacity
    #                  object.
    #   free_capacity: The free capacity of the pool in HSPV::Util::Capacity
    #                  object.
    sub get_pool {
        my ($class, $pool, %opts) = @_;

        my $request_opts = $class->_get_generic_request_opts(\%opts);
        $request_opts->{ignorable_codes} =
            $class->_append_array_opt($request_opts->{ignorable_codes},
                                      _HTTP_NOT_FOUND);

        my $result = $class->_GET("/v1/objects/pools/$pool",
                                  %$request_opts);

        if($result->code()==_HTTP_NOT_FOUND) {
            return;
        }

        return _convert_pool_pf($result->{content});
    }

    # get_ldev
    # Description: Get a single LDEV using the normal API.
    # Parameters:
    #   $ldev: The LDEV number to retrieve.
    #   %opts: an optional hash to additional options.
    #       Options:
    #           None
    #       Generic options:
    #           See _get_generic_request_opts()
    # Return: A hash containing the LDEV information, or undef if the LDEV does
    #         not exist.
    # Result Hash:
    #   id: The LDEV identifier.
    #   name: The name of the LDEV, or empty if not named.
    #   pool: The pool identifier.
    #   total_capacity: The total capacity in a HSPV::Util::Capacity
    #                   object.
    #   used_capacity: The used capacity in a HSPV::Util::Capacity
    #                   object.
    #   is_drs: true if DRS
    #   csv: Capacity saving value (see CSV_* constants).
    #   is_vc: true if vClone child
    #   is_vcp: true if vClone parent
    #   parent_ldev: The parent LDEV identifier (or undef if no parent).
    #   data_reduction_status: The data reduction status
    #       (see DRSTAT_* constants).
    #   naa: The NAA ID of the LDEV, or undef if the LDEV is not on a port.
    #   is_on_port: true if this LDEV is on a port.
    sub get_ldev {
        my ($class, $ldev, %opts) = @_;

        my $request_opts = $class->_get_generic_request_opts(\%opts);
        $request_opts->{ignorable_codes} =
            $class->_append_array_opt($request_opts->{ignorable_codes},
                                _HTTP_NOT_FOUND);

        my $result = $class->_GET("/v1/objects/ldevs/$ldev",
                                  %$request_opts);

        if($result->code()==_HTTP_NOT_FOUND) {
            return;
        }

        return _convert_ldev_pf($result->{content});
    }

    # get_ldevs
    # Description: Get an array of LDEVs.
    # This will only retrieve virutal LDEVs.
    # Parameters:
    #   $name: The name of the LDEVs to retrieve.
    #   %opts: an optional hash to additional options.
    #       Options:
    #           filter: A filtering subroutine to filter out undesired LDEVs.
    #                   return 1 to filter the item out, undef/0 otherwise.
    #           name: The name to search for (substring match).
    #           start_ldev_id: The start LDEV to use for the search.
    #           end_ldev_id: The end LDEv to use for the search.
    #           pool: The pool to use for the search.
    #       Generic options:
    #           See _get_generic_request_opts()
    # Return: An array containing hashes of LDEV information.
    # Result Hashes: See get_ldev().
    sub get_ldevs {
        my ($class, %opts) = @_;

        # TODO: Make sure to filter by virtual only.
        throw _NOT_SUPPORTED_MESSAGE;
    }

    use constant {
        # Name must match exactly.
        LDEV_MATCH_EXACT => 0,
        # Name must match the start of the string (or exactly).
        LDEV_MATCH_START => 1,
        # Name must match the end of the string (or exactly).
        LDEV_MATCH_END   => 2,
        # Name may match substring in the string.
        LDEV_MATCH_ANY   => 3,
    };

    # get_ldevs_by_name
    # Description: Get an array of LDEVs by name.
    # This will only retrieve virtual LDEVs.
    # Parameters:
    #   $name: The name of the LDEV to retrieve.
    #   %opts: an optional hash to additional options.
    #       Options:
    #           match_type: The search type to perform. See LDEV_MATCH_*.
    #               [default=LDEV_MATCH_EXACT]
    #           start_ldev_id: The start LDEV to use for the search.
    #           end_ldev_id: The end LDEv to use for the search.
    #           pool: The pool to use for the search.
    #       Generic options:
    #           See _get_generic_request_opts()
    # Return: An array containing hashes of LDEV information.
    # Result Hashes: See get_ldev().
    sub get_ldevs_by_name {
        my ($class, $name, %opts) = @_;

        # TODO: Make sure to filter by virtual only.
        throw _NOT_SUPPORTED_MESSAGE;
    }

    # create_virtual_ldev
    # Description Create an LDEV on a DP pool.
    # Parameters:
    #   $pool_id: The ID (numeric) of the pool to use.
    #   $capacity: The capacity to use. This must be a
    #              HSPV::Util::Capacity object. It should be aligned to MB,
    #              but will not be checked.
    #   %opts: an optional hash to additional options.
    #       Options:
    #           ldev_id: the numeric LDEV ID to use. start_ldev and end_ldev
    #                    must not also be provided [default=undef]
    #           is_drs: boolean true if DRS, false otherwise [default=undef]
    #           csv: CSV mode (see CSV_* constants) [default=undef]
    #           start_ldev_id: first numeric LDEV ID to use in a selection
    #                          range. end_ldev_id must also be provided, and
    #                          ldev_id must not be [default=ldev_id || 0]
    #           end_ldev_id: last numeric LDEV ID to use in a selection range.
    #                        start_ldev_id must also be provided, and ldev_id
    #                        must not be [default=ldev_id || 65279]
    #           name: The name to set for the volume [default undef]
    #                 This is ignored if has_name_ldev_on_create_support()
    #                 returns false.
    #       Generic options:
    #           See _get_generic_request_opts()
    # Return value: The numeric LDEV that was created.
    sub create_virtual_ldev {
        my ($class, $pool_id, $capacity, %opts) = @_;

        throw _NOT_SUPPORTED_MESSAGE;
    }

    # resize_ldev
    # Description Resize a LDEV using the admin API.
    # Parameters:
    #   $ldev_id: The ID (numeric) of the ldev to resize.
    #   $add_capacity: The capacity to add. This must be a
    #                  HSPV::Util::Capacity object. It should be aligned to MB,
    #                  but will not be checked.
    #   %opts: an optional hash to additional options.
    #       Options:
    #           None
    #       Generic options:
    #           See _get_generic_request_opts()
    sub resize_ldev {
        my ($class, $ldev_id, $add_capacity, %opts) = @_;

        throw _NOT_SUPPORTED_MESSAGE;
    }

    # delete_ldev
    # Description Delete an LDEV using the admin API.
    # Parameters:
    #   $ldev_id: The ID (numeric) of the ldev to delete.
    #   %opts: an optional hash to additional options.
    #       Options:
    #           None
    #       Generic options:
    #           See _get_generic_request_opts()
    # Returns: 1 if the LDEV was deleted, undef if the LDEV did not exist.
    sub delete_ldev {
        my ($class, $ldev_id, %opts) = @_;

        throw _NOT_SUPPORTED_MESSAGE;
    }

    # get_snapshot
    # Description: Get a snapshot.
    # Parameters:
    #   $pvol: The LDEV number of the PVOL.
    #   $mu: The mirror unit of the snapshot.
    #   %opts: an optional hash to additional options.
    #       Options:
    #           Currently none.
    #       Generic options:
    #           See _get_generic_request_opts()
    # Return: A hash containing the snapshot information, or undef if the
    #         snapshot does not exist.
    # Result Hash:
    #   pvol: The PVOL LDEV identifier.
    #   svol: The SVOL LDEV identifier (or undef if no SVOL).
    #   mu: The mirror unit of the pair.
    #   snapshot_group: The snapshot group of the pair.
    #   pool: The pool of the pair.
    #   is_tia: True if the pair is TIA.
    #   is_cascade: True if thet pair has cascade enabled.
    #   is_vc: True if the PVOL is a virtual clone.
    #   is_vcp: True if the PVOL is a virtual clone parent.
    #   status: The pair status. See PAIRSTAT_* values.
    sub get_snapshot {
        my ($class, $pvol, $mu, %opts) = @_;

        my $request_opts = $class->_get_generic_request_opts(\%opts);
        $request_opts->{ignorable_codes} =
            $class->_append_array_opt($request_opts->{ignorable_codes},
                                      _HTTP_NOT_FOUND);

        my $result = $class->_GET("/v1/objects/snapshots/$pvol,$mu",
                                  %$request_opts);

        if($result->code()==_HTTP_NOT_FOUND) {
            return;
        }

        return _convert_snapshot_pf($result->{content});
    }

    # get_snapshot_family
    # Description: Get the snapshot family.
    # Parameters:
    #   $ldev: The LDEV number of a VC or VCP volume.
    #   %opts: an optional hash to additional options.
    #       Options:
    #           Currently none.
    #       Generic options:
    #           See _get_generic_request_opts()
    # Return: A hash containing the snapshot family information.
    # Result Hash:
    #   ldev: The LDEV entry
    #   is_vc: true if a vClone
    #   is_vcp: true if a vClone Parent
    #   parent_ldev: The parent LDEV.
    sub get_snapshot_family {
        my ($class, $ldev, %opts) = @_;

        my $request_opts = $class->_get_generic_request_opts(\%opts);
        $request_opts->{params} = {"ldevId" => $ldev};

        my $content = $class->_GET("/v1/objects/snapshot-family",
                                  %$request_opts)->{content};

        my @ssf;
        foreach my $snap (@{ $content->{data} }) {
            push @ssf, _convert_snapshot_family_pf($snap);
        }

        return \@ssf;
    }

    # create_snapshot
    # Description: Create a snapshot.
    # Parameters:
    #   $pvol: The LDEV number of the PVOL.
    #   $svol: The LDEV number of the SVOL (may be undef for non-TIA).
    #   $pool: The pool to use for snapshots.
    #   $snapshot_group: The name of the snapshot group to use.
    #   %opts: an optional hash to additional options.
    #       Options:
    #           is_csv: True if the LDEV(s) have CSV enabled [default=undef]
    #           is_cacade: True to create a cascading snapshot [default=undef]
    #       Generic options:
    #           See _get_generic_request_opts()
    # Return: The MU of the newly created snapshot.
    sub create_snapshot {
        my ($class, $pvol, $svol, $pool, $snapshot_group, %opts) = @_;

        my $is_csv = $opts{is_csv};
        my $is_cascade = $opts{is_cascade};

        my $request_opts = $class->_get_generic_request_opts(\%opts);
        $request_opts->{async} = 1;

        my %body;
        $body{pvolLdevId} = $pvol;
        if(defined $svol) {
            $body{svolLdevId} = $svol;
        }
        $body{snapshotPoolId} = $pool;
        $body{snapshotGroupName} = $snapshot_group;
        $body{isDataReductionForceCopy} = Util::json_bool($is_csv);
        $body{canCascade} = Util::json_bool($is_cascade);

        my $result = $class->_POST('/v1/objects/snapshots',
                                   \%body, %$request_opts);

        my $resource = $class->_get_result_resource($result);
        my @parts = split(/,/, $resource);
        return $parts[-1];
    }

    # delete_snapshot
    # Description: Delete a snapshot.
    # Parameters:
    #   $pvol: The LDEV number of the PVOL.
    #   $mu: The mirror unit.
    #   %opts: an optional hash to additional options.
    #       Options:
    #           Currently none.
    #       Generic options:
    #           See _get_generic_request_opts()
    # Returns: 1 if the snapshot was deleted, undef if the snapshot did not
    #          exist.
    sub delete_snapshot {
        my ($class, $pvol, $mu, %opts) = @_;

        my $request_opts = $class->_get_generic_request_opts(\%opts);
        $request_opts->{async} = 1;
        $request_opts->{ignorable_codes} =
            $class->_append_array_opt($request_opts->{ignorable_codes},
                                      _HTTP_NOT_FOUND);

        my $result = $class->_DELETE("/v1/objects/snapshots/$pvol,$mu",
                                     %$request_opts);

	    return $result->code()!=_HTTP_NOT_FOUND ? 1 : undef;
    }

    use constant {
        # Create a vClone (PAIR => vClone)
        VCLONE_CREATE => "create",
        # Convert to vClone (PSUS => vClone)
        VCLONE_CONVERT => "convert",
        # Restore vClone
        VCLONE_RESTORE => "restore",
    };

    # snapshot_vclone
    # Description: Create, convert, or restore a vClone.
    # Parameters:
    #   $pvol: The LDEV number of the PVOL.
    #   $mu: The mirror unit.
    #   $op: The operation to use (see VCLONE_*).
    #   $snapshot_group: The name of the snapshot group to use.
    #   %opts: an optional hash to additional options.
    #       Options:
    #           Currently none.
    #       Generic options:
    #           See _get_generic_request_opts()
    sub snapshot_vclone {
        my ($class, $pvol, $mu, $op, %opts) = @_;

        my $request_opts = $class->_get_generic_request_opts(\%opts);
        $request_opts->{async} = 1;

        my %body = (parameters => { operationType => $op });

        $class->_POST("/v1/objects/snapshots/$pvol,$mu" .
                      "/actions/virtual-clone/invoke",
                      \%body, %$request_opts);
        return;
    }

    use constant {
        SERVER_PROTOCOL_FC    => 'FC',
        SERVER_PROTOCOL_ISCSI => 'iSCSI',
    };

    use constant {
        SERVER_OS_LINUX   => 'Linux',
        SERVER_OS_HP_UX   => 'HP-UX',
        SERVER_OS_SOLARIS => 'Solaris',
        SERVER_OS_AIX     => 'AIX',
        SERVER_OS_VMWARE  => 'VMware',
        SERVER_OS_WINDOWS => 'Windows',
    };

    # get_server
    # Description: Get a single server.
    # Parameters:
    #   $server: The server number to retrieve.
    #   %opts: an optional hash to additional options.
    #       Options:
    #           None
    #       Generic options:
    #           See _get_generic_request_opts()
    # Return: A hash containing the server information, or undef if the server
    #         does not exist.
    # Result Hash:
    #   id: ID of the server.
    #   name: Name of the server
    #   protocol: Protocol of the server. See SERVER_PROTOCOL_*.
    #       If the server was created as reserved, this value may appear if
    #       host groups are not added yet: Undefined.
    #   host_mode: The host mode. see SERVER_OS_*.
    #       If the server was created as reserved, one of these values may
    #       appear instead: DeprecatedVMware, OpenVMS, Tru64, NetWare,
    #                       DeprecatedWindows, Undefined, Unknown
    #   hmo: Array of numeric host mode options.
    #   paths: array of paths consisting of:
    #       ports: array of ports
    #       wwn: WWN, or undefined if not FC
    #       iqn: iSCSI name, or undefined if not iSCSI
    sub get_server {
        my ($class, $server, %opts) = @_;

        throw _NOT_SUPPORTED_MESSAGE;
    }

    # get_server_by_name
    # Description: Get a server by name.
    # Parameters:
    #   $name: The server name.
    #   %opts: an optional hash to additional options.
    #       Options:
    #           None
    #       Generic options:
    #           See _get_generic_request_opts()
    # Return: A hash with the server information, or undef if the server
    #   does not exist.
    # Result Hash: See get_server(), but paths and hmo are not
    #                included.
    sub get_server_by_name {
        my ($class, $name, %opts) = @_;

        throw _NOT_SUPPORTED_MESSAGE;
    }

    # get_servers
    # Description: Get all servers.
    # Parameters:
    #   %opts: an optional hash to additional options.
    #       Options:
    #           None
    #       Generic options:
    #           See _get_generic_request_opts()
    # Return: An array of hashes containing the server information.
    # Result Hashes: See get_server(), but paths and hmo are not
    #                included.
    sub get_servers {
        my ($class, %opts) = @_;

        throw _NOT_SUPPORTED_MESSAGE;
    }

    # create_server
    # Description: Create a server.
    # Parameters:
    #   $nickname: The server nickname.
    #   $protocol: The server protocol (see SERVER_PROTOCOL_*).
    #   $host_mode: The host mode (see SERVER_OS_*).
    #   %opts: an optional hash to additional options.
    #       Options:
    #           hmo: Array of numeric HMO options.
    #       Generic options:
    #           See _get_generic_request_opts()
    # Return value: The numeric server that was created.
    sub create_server {
        my ($class, $nickname, $protocol, $host_mode, %opts) = @_;

        throw _NOT_SUPPORTED_MESSAGE;
    }

    # get_server_hbas
    # Description: Get the IQNs or WWNs currently registered to the server.
    # Parameters:
    #   $server: The server ID to get IQNs or WWNs for.
    #   %opts: An optional hash to additional options.
    #       Options:
    #           None
    #       Generic options:
    #           See _get_generic_request_opts()
    # Return: An array of hashes containing the HBA information,
    #         or undef if the server does not exist.
    # Result Hashes:
    #   wwn: The WWN for an FC configuration.
    #   iqn: The IQN for an iSCSI configuration.
    #   ports: The ports.
    sub get_server_hbas {
        my ($class, $server, %opts) = @_;

        throw _NOT_SUPPORTED_MESSAGE;
    }

    # add_server_hbas
    # Description: Add one or more IQNs or WWNs to a server.
    # Parameters:
    #   $server: The server ID.
    #   $iqns_or_wwns: A single IQN/WWN string, or an array of IQN/WWN strings.
    #   $is_fc: true if FC, false if iSCSI.
    #   %opts: an optional hash to additional options.
    #       Options:
    #           None
    #       Generic options:
    #           See _get_generic_request_opts()
    sub add_server_hbas {
        my ($class, $server, $iqns_or_wwns, $is_fc, %opts) = @_;

        throw _NOT_SUPPORTED_MESSAGE;
    }

    # remove_server_hba
    # Description: Remove a single server hba (IQN or WWN).
    # Parameters:
    #   $server: The server ID.
    #   $iqn_or_wwn: A single WWN or IQN string.
    #   %opts: an optional hash to additional options.
    #       Options:
    #           None
    #       Generic options:
    #           See _get_generic_request_opts()
    # Returns: 1 if the server HBA was removed, undef if the server HBA
    #          did not exist.
    sub remove_server_hba {
        my ($class, $server, $iqn_or_wwn, %opts) = @_;

        throw _NOT_SUPPORTED_MESSAGE;
    }

    # add_server_paths
    # Description: Add an IQN or WWN path on one or more ports to a server.
    # Parameters:
    #   $server: The server ID.
    #   $iqn: A single IQN or WWN string.
    #   $ports: A single port string, or an array of port strings.
    #   $is_fc: true if using FC protocol, false if iSCSI.
    #   %opts: an optional hash to additional options.
    #       Options:
    #           None
    #       Generic options:
    #           See _get_generic_request_opts()
    sub add_server_paths {
        my ($class, $server, $iqn_or_wwn, $ports, $is_fc, %opts) = @_;

        throw _NOT_SUPPORTED_MESSAGE;
    }

    # remove_server_path
    # Description: Remove a single server path (IQN or WWN).
    # Parameters:
    #   $server: The server ID.
    #   $iqn_or_wwn: A single WWN or IQN string.
    #   $port: A single port string.
    #   %opts: an optional hash to additional options.
    #       Options:
    #           None
    #       Generic options:
    #           See _get_generic_request_opts()
    # Returns: 1 if the path was removed, undef if the path did not exist.
    sub remove_server_path {
        my ($class, $server, $iqn_or_wwn, $port, %opts) = @_;

        throw _NOT_SUPPORTED_MESSAGE;
    }

    # get_server_port_iqns
    # Description: Get the IQNs of each port on the server.
    # Parameters:
    #   #server: The server ID.
    #   %opts: An optional hash to additional options.
    #       Options:
    #           None
    #       Generic options:
    #           See _get_generic_request_opts()
    # Return: An array of hashes containing the IQN information,
    #         or undef if the server does not exist.
    # Result Hashes:
    #   port: The port
    #   iqn: The IQN for the port.
    sub get_server_port_iqns {
        my ($class, $server, %opts) = @_;

        throw _NOT_SUPPORTED_MESSAGE;
    }

    # get_server_luns
    # Description: Get the LUNs of each port on the server.
    # Parameters:
    #   $server: The server ID to get LUNs for
    #   %opts: An optional hash to additional options.
    #       Options:
    #           None
    #       Generic options:
    #           See _get_generic_request_opts()
    # Return: An array of hashes containing the LUN information,
    #         or undef if the server does not exist.
    # Result Hashes: See get_server_ldev_luns_admin.
    sub get_server_luns {
        my ($class, $server, %opts) = @_;

        throw _NOT_SUPPORTED_MESSAGE;
    }

    # get_server_ldev_luns
    # Description: Get the LUN information for a single LDEV on a server.
    # Parameters:
    #   $server: The server ID to get LUNs for.
    #   $ldev: The LDEV to get LUNs for.
    #   %opts: An optional hash to additional options.
    #       Options:
    #           None
    #       Generic options:
    #           See _get_generic_request_opts()
    # Return: A hash containing the LUN information, or undef if the server
    #   did not exist, or the LDEV was not on the server.
    # Result Hash:
    #   ldev: The LDEV
    #   luns: array of lun information hashes:
    #       lun: LUN ID
    #       port: port
    sub get_server_ldev_luns {
        my ($class, $server, $ldev, %opts) = @_;

        throw _NOT_SUPPORTED_MESSAGE;
    }

    # add_server_luns
    # Description: Add LUNs to a server.
    # Parameters:
    #   $server: The ID of the server to add LUNs to.
    #   $ldevs: The LDEVs to present as LUNs. This may be a single LDEV or
    #       an array of LDEVS (not to exceed 1000).
    #   %opts: an optional hash to additional options.
    #       Options:
    #           None
    #       Generic options:
    #           See _get_generic_request_opts()
    sub add_server_luns {
        my ($class, $server, $ldevs, %opts) = @_;

        throw _NOT_SUPPORTED_MESSAGE;
    }

    # remove_server_luns
    # Description: Remove all LUNs for a specific LDEV from the server.
    # Parameters:
    #   $server: The ID of the server to add LUNs to.
    #   $ldev: The LDEV to remove LUNs for.
    #   %opts: an optional hash to additional options.
    #       Options:
    #           None
    #       Generic options:
    #           See _get_generic_request_opts()
    # Returns: 1 if the LUNs were removed, undef if the LUNs did not exist.
    sub remove_server_luns {
        my ($class, $server, $ldev, %opts) = @_;

        throw _NOT_SUPPORTED_MESSAGE;
    }

    # delete_server
    # Description: Delete a server.
    # Parameters:
    #   $server: The ID of the server to delete.
    #   %opts: an optional hash to additional options.
    #       Options:
    #           None
    #       Generic options:
    #           See _get_generic_request_opts()
    # Returns: 1 if the server was removed, undef if the server did not exist.
    sub delete_server {
        my ($class, $server, %opts) = @_;

        throw _NOT_SUPPORTED_MESSAGE;
    }

    ################
    # Data conversion
    #
    # NOTE: These conversions only return the data we want!
    # There is more data available in most or all cases.
    ################

    # Convert storage output by the admin API
    sub _convert_storage_pf {
        my ($data) = @_;

        my %output;
        $output{serial} = $data->{serialNumber};
        $output{model} = $data->{model};
        $output{storage_id} = $data->{storageDeviceId};
        $output{dkc_micro} = $data->{dkcMicroVersion};
        $output{ctl1_micro} = $data->{ctl1MicroVersion};
        $output{ctl2_micro} = $data->{ctl2MicroVersion};
        return \%output;
    }

    # Convert LDEV output from normal PF-REST API.
    sub _convert_ldev_pf {
        my ($data) = @_;

        my %pf_saving_to_csv = (
            _PF_SAVING_DEDUP_COMP() => CSV_DEDUPLICATION_COMPRESSION,
            _PF_SAVING_COMP()       => CSV_COMPRESSION,
            _PF_SAVING_DISABLE()    => CSV_DISABLED,
        );

        my %attr_map;
        if(defined $data->{attributes}) {
            %attr_map = map { $_ => 1 } @{$data->{attributes}};
        }

        my %output;
        $output{id} = $data->{ldevId};
        $output{name} = defined $data->{label} ? $data->{label} : "";
        $output{pool} = $data->{poolId};
        $output{total_capacity} = Capacity->new($data->{blockCapacity},
                                                Util::SIZE_BLOCK());
        $output{used_capacity} = defined $data->{numOfUsedBlock} ?
            Capacity->new($data->{numOfUsedBlock}, Util::SIZE_BLOCK()) :
            $output{total_capacity};
        $output{is_drs} = $attr_map{DRS} // 0;
        $output{csv} =
            $pf_saving_to_csv{$data->{dataReductionMode}} // CSV_DISABLED;
        $output{is_vc} = $attr_map{VC} // 0;
        $output{is_vcp} = $attr_map{VCP} // 0;
        $output{parent_ldev} = $data->{parentLdevId};
        $output{naa} = $data->{naaId};
        $output{data_reduction_status} = $data->{dataReductionStatus};
        $output{is_on_port} =
            (defined $data->{numOfPorts} && $data->{numOfPorts} > 0) ||
             defined $data->{namespaceId};

        return \%output;
    }

    # Convert pool output from normal PF-REST API.
    sub _convert_pool_pf {
        my ($data) = @_;

        my %output;
        $output{id} = $data->{poolId};
        $output{name} = $data->{poolName};
        $output{total_capacity} = Capacity->new($data->{totalPoolCapacity},
                                                Util::SIZE_MB());
        $output{free_capacity} =
            Capacity->new($data->{availableVolumeCapacity}, Util::SIZE_MB());
        $output{used_capacity} =
            Capacity->new($data->{totalPoolCapacity} -
                            $data->{availableVolumeCapacity},
                          Util::SIZE_MB());

        return \%output;
    }

    # Convert snapshot output from normal PF-REST API.
    sub _convert_snapshot_pf {
        my ($data) = @_;

        my %output;
        $output{pvol} = $data->{pvolLdevId};
        if(defined $data->{svolLdevId}) {
            $output{svol} = $data->{svolLdevId};
        }
        $output{mu} = $data->{muNumber};
        $output{snapshot_group} = $data->{snapshotGroupName};
        $output{pool} = $data->{snapshotPoolId};
        $output{is_tia} = $data->{isRedirectOnWrite};
        $output{is_cascade} = $data->{canCascade};
        $output{is_vc} = $data->{isVirtualCloneVolume};
        $output{is_vcp} = $data->{isVirtualCloneParentVolume};
        $output{status} = $data->{status};

        return \%output;
    }

    sub _convert_snapshot_family_pf {
        my ($data) = @_;

        my %output;
        $output{ldev} = $data->{ldevId};
        $output{is_vc} = $data->{isVirtualCloneVolume};
        $output{is_vcp} = $data->{isVirtualCloneParentVolume};
        $output{parent_ldev} = $data->{parentLdevId};

        return \%output;
    }
}

####################################################
# HSPV::ApiClientAdmin package
#
# See HSPV::ApiClient for API descriptions. Some
# extended descriptions may appear below.
####################################################

package HSPV::ApiClientAdmin {

    use strict;
    use warnings;

    BEGIN {
        *Log:: = *HSPV::Log::;
        *Util:: = *HSPV::Util::;
        *Capacity:: = *HSPV::Util::Capacity::;
        *throw = \&HSPV::Util::throw;
    }

    use base qw(HSPV::ApiClient);

    #####################
    # Internal helpers
    #####################

    # Get the result resource for an admin API call.
    sub _get_result_resource_admin {
        my ($class, $result) = @_;

        # Get a resource from an operational detail.
        # This only gets the first resource.  If we use functionality that
        # will return more than 1 we will have to revisit this.
        return $result->{content}->{operationDetails}->[0]->{resourceId};
    }

    #####################
    # Internal constants
    #####################

    use constant {
        _ADMIN_SAVING_DEDUP_COMP => "DEDUPLICATION_AND_COMPRESSION",
        _ADMIN_SAVING_COMP       => "COMPRESSION",
        _ADMIN_SAVING_DISABLE    => "DISABLE",
    };

    #####################
    # API Support Queries
    #####################

    # Whether or not this client has support for servers.
    sub has_server_support {
        my ($class) = @_;

        return 1;
    }

    # Whether or not this client has support for naming an LDEV during
    # LDEV creation.
    sub has_name_ldev_on_create_support {
        my ($class) = @_;

        return 1;
    }

    sub has_ip_info_for_all_ports_query {
        my ($class) = @_;

        return 1;
    }

    #####################
    # API Implementations
    #####################

    sub get_ports {
        my ($class, %opts) = @_;

        my $protocol = $opts{protocol};

        my $request_opts = $class->_get_generic_request_opts(\%opts);

        if(defined $protocol) {
            $request_opts->{params} = { protocol => $protocol };
        }

        my $content = $class->_GET('/simple/v1/objects/ports',
                                   %$request_opts)->{content};

        my @ports;
        foreach my $port (@{ $content->{data} }) {
            push @ports, _convert_port_admin($port);
        }

        return \@ports;
    }

    sub get_pools {
        my ($class, %opts) = @_;

        my $name_hint = $opts{name_hint};

        my $request_opts = $class->_get_generic_request_opts(\%opts);

        if(defined $name_hint) {
            $request_opts->{params} = {name => $name_hint};
        }

        my $content = $class->_GET('/simple/v1/objects/pools',
                                   %$request_opts)->{content};

        my @pools;
        foreach my $pool (@{ $content->{data} } ) {
            push @pools, _convert_pool_admin($pool);
        }

        return \@pools;
    }

    sub get_pool {
        my ($class, $pool, %opts) = @_;

        my $request_opts = $class->_get_generic_request_opts(\%opts);
        $request_opts->{ignorable_codes} =
            $class->_append_array_opt($request_opts->{ignorable_codes},
                                      HSPV::ApiClient::_HTTP_NOT_FOUND());

        my $result = $class->_GET("/simple/v1/objects/pools/$pool",
                                  %$request_opts);

        if($result->code()==HSPV::ApiClient::_HTTP_NOT_FOUND()) {
            return;
        }

        return _convert_pool_admin($result->{content});
    }

    # Note: Only retrieves virtual LDEVs (unless want_naa is true).
    #   %opts:
    #       Additional Values:
    #           want_naa: If present and true, the NAA will also be returned if
    #                     this LDEV is attached to a port.
    #   Notes:
    #       is_on_port: This only returns true if this LDEV is
    #           on a server. If it's not on a server or is on a namespace, this
    #           will be false.
    sub get_ldev {
        my ($class, $ldev, %opts) = @_;

        if($opts{want_naa}) {
            # Admin version doesn't return NAA, so call the super class in this
            # case.
            return $class->SUPER::get_ldev($ldev, %opts);
        }

        my $request_opts = $class->_get_generic_request_opts(\%opts);
        $request_opts->{ignorable_codes} =
            $class->_append_array_opt($request_opts->{ignorable_codes},
                                      HSPV::ApiClient::_HTTP_NOT_FOUND());

        my $result = $class->_GET("/simple/v1/objects/volumes/$ldev",
                                  %$request_opts);

        if($result->code()==HSPV::ApiClient::_HTTP_NOT_FOUND()) {
            return;
        }

        return _convert_ldev_admin($result->{content});
    }

    # Note: Only retrieves virtual LDEVs.
    sub get_ldevs {
        my ($class, %opts) = @_;

        my $filter =        $opts{filter};
        my $name =          $opts{name};
        my $start_ldev_id = $opts{start_ldev_id};
        my $end_ldev_id =   $opts{end_ldev_id};
        my $pool =          $opts{pool};

        my $request_opts = $class->_get_generic_request_opts(\%opts);

        use constant MAX_COUNT => 500;

        my %params;
        $params{poolId} = $pool if defined $pool;
        $params{nickname} = $name if defined $name;
        $params{startVolumeId} = $start_ldev_id if defined $start_ldev_id;
        if(defined $start_ldev_id && defined $end_ldev_id &&
                ($end_ldev_id-$start_ldev_id)<MAX_COUNT) {
            $params{count} = $end_ldev_id-$start_ldev_id+1;
        }
        $request_opts->{params} = \%params;

        my $content;
        my @ldevs;

        # We have to use this to calculate the next LDEV as the API will not
        # return the LDEVs in order (or the conversions sort them strange).
        my $next_ldev;
        while(1) {
            if(defined $content) {
                $params{startVolumeId} = $next_ldev+1;
                if(defined $end_ldev_id &&
                        ($end_ldev_id-$params{startVolumeId})<MAX_COUNT) {
                    $params{count} = $end_ldev_id-$params{startVolumeId}+1;
                }
                $request_opts->{params} = \%params;
            }

            $content = $class->_GET("/simple/v1/objects/volumes",
                                    %$request_opts)->{content};

            my $is_last=0;
            if($content->{count}>0) {
                foreach my $ldev (@{ $content->{data} }) {
                    if(defined $end_ldev_id && $ldev->{id}>$end_ldev_id) {
                        $is_last = 1;
                        #last; Do not exit here as LDEVs may be unordered.
                    }
                    if(!defined $filter || !$filter->($ldev)) {
                        push @ldevs, _convert_ldev_admin($ldev);
                    }
                    $next_ldev = $ldev->{id} if !defined $next_ldev ||
                                                    $ldev->{id}>$next_ldev;
                }
            }

            if($is_last) {
                last;
            }

            last unless $content->{hasNext};
        }

        return \@ldevs;
    }

    # Note: Virtual LDEVs only
    sub get_ldevs_by_name {
        my ($class, $name, %opts) = @_;

        my $match_type = $opts{match_type} //
            HSPV::ApiClient::LDEV_MATCH_EXACT();

        # If invalid value is passed, we'll use LDEV_MATCH_EXACT.
        my $filter = sub {
                my ($ldev) = @_;
                if(($ldev->{nickname} // '') ne $name) {
                    return 1;
                }
                return;
            };

        if($match_type==HSPV::ApiClient::LDEV_MATCH_START()) {
            $filter = sub {
                    my ($ldev) = @_;
                    if(!Util::starts_with($ldev->{nickname} // '', $name)) {
                        return 1;
                    }
                    return;
                };
        } elsif($match_type==HSPV::ApiClient::LDEV_MATCH_END()) {
            $filter = sub {
                    my ($ldev) = @_;
                    if(!Util::ends_with($ldev->{nickname} // '', $name)) {
                        return 1;
                    }
                    return;
                };
        } elsif($match_type==HSPV::ApiClient::LDEV_MATCH_ANY()) {
            $filter = undef;
        }

        $opts{name} = $name;
        $opts{filter} = $filter;

        # We must include a filter as partial names will also be
        # returned.
        return $class->get_ldevs(%opts);
    }

    sub create_virtual_ldev {
        my ($class, $pool_id, $capacity, %opts) = @_;

        my $ldev_id =       $opts{ldev_id};
        my $is_drs =        $opts{is_drs};
        my $csv =           $opts{csv};
        my $start_ldev_id = $opts{start_ldev_id} // 0;
        my $end_ldev_id =   $opts{end_ldev_id}   // 65279;
        my $name =          $opts{name};

        my $request_opts = $class->_get_generic_request_opts(\%opts);
        $request_opts->{admin_async} = 1;

        my %csv_to_admin_saving = (
            HSPV::ApiClient::CSV_DEDUPLICATION_COMPRESSION() =>
                _ADMIN_SAVING_DEDUP_COMP,
            HSPV::ApiClient::CSV_COMPRESSION()               =>
                _ADMIN_SAVING_COMP,
            HSPV::ApiClient::CSV_DISABLED()                  =>
                _ADMIN_SAVING_DISABLE,
        );

        my %body;

        if(defined $ldev_id) {
            $start_ldev_id = $ldev_id;
            $end_ldev_id = $ldev_id;
        }

        $body{poolId} = $pool_id;
        $body{capacity} = $capacity->as_mb();
        if(defined $is_drs) {
            $body{isDataReductionShareEnabled} = Util::json_bool($is_drs);
        }
        if(defined $csv) {
            $body{savingSetting} =
                $csv_to_admin_saving{$csv} // _ADMIN_SAVING_DISABLE;
        }
        $body{idRange}->{startId} = $start_ldev_id;
        $body{idRange}->{endId} = $end_ldev_id;
        if(defined $name) {
            $body{nicknameParam}->{baseName} = $name;
        }

        my $result = $class->_POST("/simple/v1/objects/volumes",
                                 \%body, %$request_opts);

        return $class->_get_result_resource_admin($result);
    }

    sub resize_ldev {
        my ($class, $ldev_id, $add_capacity, %opts) = @_;

        my $request_opts = $class->_get_generic_request_opts(\%opts);
        $request_opts->{admin_async} = 1;

        my %body;
        $body{capacity} = $add_capacity->as_mb();

        $class->_POST(
                "/simple/v1/objects/volumes/$ldev_id/actions/expand/invoke",
                \%body, %$request_opts);

        return;
    }

    sub delete_ldev {
        my ($class, $ldev_id, %opts) = @_;

        my $request_opts = $class->_get_generic_request_opts(\%opts);
        $request_opts->{admin_async} = 1;
        $request_opts->{ignorable_codes} =
            $class->_append_array_opt($request_opts->{ignorable_codes},
                                      HSPV::ApiClient::_HTTP_NOT_FOUND());

        my $result = $class->_DELETE("/simple/v1/objects/volumes/$ldev_id",
                                     %$request_opts);

	    return $result->code()!=HSPV::ApiClient::_HTTP_NOT_FOUND() ? 1 : undef;
    }

    sub get_server {
        my ($class, $server, %opts) = @_;

        my $request_opts = $class->_get_generic_request_opts(\%opts);
        $request_opts->{ignorable_codes} =
            $class->_append_array_opt($request_opts->{ignorable_codes},
                                      HSPV::ApiClient::_HTTP_NOT_FOUND());

        my $result = $class->_GET("/simple/v1/objects/servers/$server",
                                  %$request_opts);

        if($result->code()==HSPV::ApiClient::_HTTP_NOT_FOUND()) {
            return;
        }

        return _convert_server_admin($result->{content}, 1);
    }

    sub get_server_by_name {
        my ($class, $name, %opts) = @_;

        my $request_opts = $class->_get_generic_request_opts(\%opts);

        my $content = $class->_GET(
                    "/simple/v1/objects/servers?nickname=$name",
                    %$request_opts)->{content};

        if($content->{count}==0) {
            return undef;
        }
        if($content->{count}>1) {
            throw "Expected 1 server, but got $content->{count}.";
        }

        return _convert_server_admin($content->{data}->[0], 0)
    }

    sub get_servers {
        my ($class, %opts) = @_;

        my $request_opts = $class->_get_generic_request_opts(\%opts);

        my $content = $class->_GET("/simple/v1/objects/servers",
                                   %$request_opts)->{content};

        my @servers;
        if($content->{count}>0) {
            foreach my $server (@{ $content->{data} }) {
                push @servers, _convert_server_admin($server, 0);
            }
        }
        return \@servers;
    }

    sub create_server {
        my ($class, $nickname, $protocol, $host_mode, %opts) = @_;

        my $hmo = $opts{hmo};

        my $request_opts = $class->_get_generic_request_opts(\%opts);
        $request_opts->{admin_async} = 1;

        my %body = (
            serverNickname => $nickname,
            protocol       => $protocol,
            osType         => $host_mode,
        );

        if(defined $hmo) {
            $body{osTypeOptions} = $hmo;
        }

        my $result = $class->_POST("/simple/v1/objects/servers", \%body,
                                   %$request_opts);

        return $class->_get_result_resource_admin($result);
    }

    sub get_server_hbas {
        my ($class, $server, %opts) = @_;

        my $request_opts = $class->_get_generic_request_opts(\%opts);
        $request_opts->{ignorable_codes} =
            $class->_append_array_opt($request_opts->{ignorable_codes},
                                      HSPV::ApiClient::_HTTP_NOT_FOUND());

        my $result = $class->_GET(
            "/simple/v1/objects/servers/$server/hbas",
            %$request_opts);

        if($result->code()==HSPV::ApiClient::_HTTP_NOT_FOUND()) {
            return;
        }

        my $content = $result->{content};

        my @hbas;
        if($content->{count}>0) {
            foreach my $hba (@{ $content->{data} }) {
                push @hbas, _convert_server_hba_admin($hba);
             }
        }
        return \@hbas;
    }

    sub add_server_hbas {
        my ($class, $server, $iqns_or_wwns, $is_fc, %opts) = @_;

        my $hba_name = $is_fc ? 'hbaWwn' : 'iscsiName';

        my $request_opts = $class->_get_generic_request_opts(\%opts);
        $request_opts->{admin_async} = 1;

        my @hba_list;
        if(Util::is_array_ref($iqns_or_wwns)) {
            foreach my $iqn_or_wwn (@$iqns_or_wwns) {
                push @hba_list, { $hba_name => $iqn_or_wwn };
            }
        } else {
            push @hba_list, { $hba_name => $iqns_or_wwns };
        }

        my %body = (
            hbas => \@hba_list,
        );

        $class->_POST("/simple/v1/objects/servers/$server/hbas", \%body,
                      %$request_opts);

        return;
    }

    sub remove_server_hba {
        my ($class, $server, $iqn_or_wwn, %opts) = @_;

        my $request_opts = $class->_get_generic_request_opts(\%opts);
        $request_opts->{admin_async} = 1;
        $request_opts->{ignorable_codes} =
            $class->_append_array_opt($request_opts->{ignorable_codes},
                                      HSPV::ApiClient::_HTTP_NOT_FOUND());

        my $result = $class->_DELETE(
            "/simple/v1/objects/servers/$server/hbas/$iqn_or_wwn",
            %$request_opts);

    	return $result->code()!=HSPV::ApiClient::_HTTP_NOT_FOUND() ? 1 : undef;
    }

    sub add_server_paths {
        my ($class, $server, $iqn_or_wwn, $ports, $is_fc, %opts) = @_;

        my $request_opts = $class->_get_generic_request_opts(\%opts);
        $request_opts->{admin_async} = 1;

        my @port_list;
        if(Util::is_array_ref($ports)) {
            @port_list = @$ports;
        } else {
            push @port_list, $ports;
        }

        my $hba_name = $is_fc ? 'hbaWwn' : 'iscsiName';
        my %body = (
            $hba_name => $iqn_or_wwn,
            portIds   => \@port_list,
        );

        $class->_POST("/simple/v1/objects/servers/$server/paths", \%body,
                      %$request_opts);

        return;
    }

    sub remove_server_path {
        my ($class, $server, $iqn_or_wwn, $port, %opts) = @_;

        my $request_opts = $class->_get_generic_request_opts(\%opts);
        $request_opts->{admin_async} = 1;
        $request_opts->{ignorable_codes} =
            $class->_append_array_opt($request_opts->{ignorable_codes},
                                      HSPV::ApiClient::_HTTP_NOT_FOUND());

        my $result = $class->_DELETE(
            "/simple/v1/objects/servers/$server/paths/$iqn_or_wwn,$port",
            %$request_opts);

        return $result->code()!=HSPV::ApiClient::_HTTP_NOT_FOUND() ? 1 : undef;
    }

    sub get_server_port_iqns {
        my ($class, $server, %opts) = @_;

        my $request_opts = $class->_get_generic_request_opts(\%opts);
        $request_opts->{ignorable_codes} =
            $class->_append_array_opt($request_opts->{ignorable_codes},
                                      HSPV::ApiClient::_HTTP_NOT_FOUND());

        my $result = $class->_GET(
            "/simple/v1/objects/servers/$server/target-iscsi-ports",
            %$request_opts);

        if($result->code()==HSPV::ApiClient::_HTTP_NOT_FOUND()) {
            return;
        }

        my $content = $result->{content};

        my @iqns;
        if($content->{count}>0) {
            foreach my $tn (@{ $content->{data} }) {
                push @iqns, _convert_server_port_iqn_admin($tn);
            }
        }

        return \@iqns;
    }

    sub get_server_luns {
        my ($class, $server, %opts) = @_;

        my $request_opts = $class->_get_generic_request_opts(\%opts);
        $request_opts->{ignorable_codes} =
            $class->_append_array_opt($request_opts->{ignorable_codes},
                                      HSPV::ApiClient::_HTTP_NOT_FOUND());

        my $result = $class->_GET(
            "/simple/v1/objects/volume-server-connections?serverId=$server",
            %$request_opts);

        if($result->code()==HSPV::ApiClient::_HTTP_NOT_FOUND()) {
            return;
        }

        my $content;
        my @luns;

        # We have to use this to calculate the next LDEV as the API will not
        # return the LDEVs in order (or the conversions sort them strange).
        my $next_ldev;
        do {
            if(defined $content) {
                $next_ldev += 1;
                $content = $class->_GET(
                    "/simple/v1/objects/volume-server-connections?" .
                    "serverId=$server&startVolumeId=$next_ldev")->{content};
            } else {
                $content = $result->{content};
            }

            if($content->{count}>0) {
                foreach my $luns (@{ $content->{data} }) {
                    push @luns, _convert_server_luns_admin($luns);
                    $next_ldev = $luns->{volumeId} if !defined $next_ldev ||
                                                $luns->{volumeId}>$next_ldev;
                }
            }

        } while($content->{hasNext});

        return \@luns;
    }

    sub get_server_ldev_luns {
        my ($class, $server, $ldev, %opts) = @_;

        my $request_opts = $class->_get_generic_request_opts(\%opts);
        $request_opts->{ignorable_codes} =
            $class->_append_array_opt($request_opts->{ignorable_codes},
                                      HSPV::ApiClient::_HTTP_NOT_FOUND());

        my $result = $class->_GET(
            "/simple/v1/objects/volume-server-connections/$ldev,$server",
            %$request_opts);

        if($result->code()==HSPV::ApiClient::_HTTP_NOT_FOUND()) {
            return;
        }

        return _convert_server_luns_admin($result->{content});
    }

    sub add_server_luns {
        my ($class, $server, $ldevs, %opts) = @_;

        my $request_opts = $class->_get_generic_request_opts(\%opts);
        $request_opts->{admin_async} = 1;

        my @volumes;
        if(Util::is_array_ref($ldevs)) {
            @volumes = @$ldevs;
        } else {
            push @volumes, $ldevs;
        }
        my @servers = ($server);

        my %body = (
            volumeIds => \@volumes,
            serverIds => \@servers,
        );

        $class->_POST("/simple/v1/objects/volume-server-connections", \%body,
                      %$request_opts);
        return;
    }

    sub remove_server_luns {
        my ($class, $server, $ldev, %opts) = @_;

        my $request_opts = $class->_get_generic_request_opts(\%opts);
        $request_opts->{admin_async} = 1;
        $request_opts->{retry_on_ssb} = [[0x2EAD, 0xB104]];
        $request_opts->{ignorable_codes} =
            $class->_append_array_opt($request_opts->{ignorable_codes},
                                      HSPV::ApiClient::_HTTP_NOT_FOUND());

        my $result = $class->_DELETE(
            "/simple/v1/objects/volume-server-connections/$ldev,$server",
            %$request_opts);

        return $result->code()!=HSPV::ApiClient::_HTTP_NOT_FOUND() ? 1 : undef;
    }

    sub delete_server {
        my ($class, $server, %opts) = @_;

        my $request_opts = $class->_get_generic_request_opts(\%opts);
        $request_opts->{admin_async} = 1;
        $request_opts->{ignorable_codes} =
            $class->_append_array_opt($request_opts->{ignorable_codes},
                                      HSPV::ApiClient::_HTTP_NOT_FOUND());

        my $result = $class->_DELETE("/simple/v1/objects/servers/$server",
                        %$request_opts);

        return $result->code()!=HSPV::ApiClient::_HTTP_NOT_FOUND() ? 1 : undef;
    }

    ################
    # Data conversion
    #
    # NOTE: These conversions only return the data we want!
    # There is more data available in most or all cases.
    ################

    use constant {
        _ADMIN_VOLTYPE_VC        => "VClone",
        _ADMIN_VOLTYPE_VCP       => "VClone Parent",
    };

    # Convert port output by the admin API (only the values we want).
    sub _convert_port_admin {
        my ($data) = @_;

        my %output;
        $output{port} = $data->{id};
        $output{protocol} = $data->{protocol};
        if($data->{protocol} eq 'FC' && defined $data->{fcInformation} &&
                $data->{fcInformation}->{portMode} eq 'NVME') {
            $output{protocol} = 'NVME_FC';
        }
        if(defined $data->{portWwn}) {
            $output{wwn} = $data->{portWwn};
        }
        if(defined $data->{portIscsiName}) {
            $output{iqn} = $data->{portIscsiName};
        }
        if(defined $data->{iscsiInformation}) {
            $output{ipv4_address} =
                $data->{iscsiInformation}->{ipv4Information}->{address};
            $output{tcp_port} =
                $data->{iscsiInformation}->{tcpPort};
        }
        if(defined $data->{nvmeTcpInformation}) {
            $output{ipv4_address} =
                $data->{nvmeTcpInformation}->{ipv4Information}->{address};
            $output{tcp_port} =
                $data->{nvmeTcpInformation}->{tcpPort};
        }
        if(defined $data->{portSecurity}) {
            $output{security} = $data->{portSecurity} ? 1 : 0;
        }

        # This is the default if no attribute member has been provided.
        $output{attributes} = ['TAR', 'MCU', 'RCU', 'ELUN'];
        if(defined $data->{attribute}) {
            if($data->{attribute} eq 'TARGET') {
                $output{attributes} = ['TAR'];
            } elsif($data->{attribute} eq 'BIDIRECTIONAL') {
                # Uses default.
            } else {
                # 'Unknown' from admin API, which could mean other things.
                $output{attributes} = [];
            }
        }

        return \%output;
    }

    # Convert pool output by the admin API (only the values we want).
    sub _convert_pool_admin {
        my ($data) = @_;

        my %output;
        $output{id} = $data->{id};
        $output{name} = $data->{name};
        $output{total_capacity} = Capacity->new($data->{totalCapacity},
                                                Util::SIZE_MB());
        $output{used_capacity} = Capacity->new($data->{usedCapacity},
                                               Util::SIZE_MB());
        $output{free_capacity} = Capacity->new($data->{freeCapacity},
                                               Util::SIZE_MB());

        return \%output;
    }

    # Convert LDEV output by the admin API (only the values we want).
    sub _convert_ldev_admin {
        my ($data) = @_;

        my %admin_saving_to_csv = (
            _ADMIN_SAVING_DEDUP_COMP() =>
                HSPV::ApiClient::CSV_DEDUPLICATION_COMPRESSION(),
            _ADMIN_SAVING_COMP()       => HSPV::ApiClient::CSV_COMPRESSION(),
            _ADMIN_SAVING_DISABLE()    => HSPV::ApiClient::CSV_DISABLED(),
        );

        my %output;
        $output{id} = $data->{id};
        $output{name} = defined $data->{nickname} ? $data->{nickname} : "";
        $output{pool} = $data->{poolId};
        $output{total_capacity} = Capacity->new($data->{totalCapacity},
                                                Util::SIZE_MB());
        $output{used_capacity} = Capacity->new($data->{usedCapacity},
                                               Util::SIZE_MB());
        $output{is_drs} = defined $data->{isDataReductionShareEnabled} ?
            $data->{isDataReductionShareEnabled} : Util::json_bool(0);
        $output{csv} =
            $admin_saving_to_csv{$data->{savingSetting}} //
                HSPV::ApiClient::CSV_DISABLED();
        $output{is_vc} = 0;
        $output{is_vcp} = 0;
        foreach my $attr (@{ $data->{volumeTypes} }) {
            if($attr eq _ADMIN_VOLTYPE_VC) {
                $output{is_vc} = 1;
            } elsif($attr eq _ADMIN_VOLTYPE_VCP) {
                $output{is_vcp} = 1;
            }
        }
        $output{parent_ldev} = $data->{parentVolumeId};
        # Admin DR status is the same as PF, only not upper case.
        $output{data_reduction_status} = uc($data->{capacitySavingStatus});
        $output{is_on_port} = defined $data->{numberOfConnectingServers} &&
                              $data->{numberOfConnectingServers} > 0;

        return \%output;
    }

    # Convert server output by the admin API (only the values we want).
    sub _convert_server_admin {
        my ($data, $include_paths) = @_;

        my %output;
        $output{id} = $data->{id};
        $output{name} = $data->{nickname};
        $output{protocol} = defined $data->{protocol} &&
                    $data->{protocol} ne "Undefined" ? $data->{protocol} : "";
        $output{host_mode} = $data->{osType};
        $output{hmo} = $data->{osTypeOptions} if
            defined $data->{osTypeOptions};
        if($include_paths) {
            $output{paths} = [];
            foreach my $path (@{$data->{paths}}) {
                my %path_hash;
                $path_hash{ports} = $path->{portIds};
                $path_hash{wwn} = $path->{hbaWwn} if defined $path->{hbaWwn};
                $path_hash{iqn} = $path->{iscsiName} if
                    defined $path->{iscsiName};
                push @{$output{paths}}, \%path_hash;
            }
        }

        return \%output;
    }

    # Convert a server port's IQNs.
    sub _convert_server_port_iqn_admin {
        my ($data) = @_;

        my %output = (
            port => $data->{portId},
            iqn  => $data->{targetIscsiName},
        );

        return \%output;
    }

    sub _convert_server_luns_admin {
        my ($data) = @_;

        my @luns;
        foreach my $lun (@{$data->{luns}}) {
            push @luns, { lun=>$lun->{lun}, port=>$lun->{portId} };
        }

        my %output = (
            ldev => $data->{volumeId},
            luns => \@luns,
        );

        return \%output;
    }

    sub _convert_server_hba_admin {
        my ($data) = @_;

        my %output;
        if(defined $data->{hbaWwn}) {
            $output{wwn} = $data->{hbaWwn};
        } elsif(defined $data->{iscsiName}) {
            $output{iqn} = $data->{iscsiName};
        }

        my @ports;
        foreach my $port (@{$data->{portIds}}) {
            push @ports, $port;
        }
        $output{ports} = \@ports;

        return \%output;
    }
}

####################################################
# HSPV::ApiClient::Result package
####################################################

package HSPV::ApiClient::Result {

    use strict;
    use warnings;

    # If no error JSON is detected, this subroutine will return undef.
    # Error content will exist as follows:
    #   message => error message
    #   ssb1 => SSB1 [optional]
    #   ssb2 => SSB2 [optional]
    #   solution_type => value [optional]
    # Both SSB codes will be provided or not provided. If, for some reason,
    # only a single SSB code was in the error content, the other SSB code
    # will be set to 0.
    sub _parse_error_content {
        my ($content) = @_;

        if(!defined $content) {
            return;
        }

        # Error formats:
        #   1. normal error
        #       message:             "message"
        #       SSB codes (opt):     "errorCode" => "SSB1", "SSB2"
        #       solution type (opt): n/a
        #   2. PF-REST job error
        #       message:             "error" => "message"
        #       SSB codes (opt):     "error" => "errorCode" => "SSB1", "SSB2"
        #       solution type (opt): "solutionType"
        #   3. Admin API async error
        #       message:             "errorMessage"
        #       SSB codes (opt):     "errorCode" => "SSB1", "SSB2"
        #       solution type (opt): n/a

        my $parse_content = $content;
        if(defined $content->{error}) {
            $parse_content = $content->{error};
        }

        if(defined $parse_content->{message} ||
            defined $parse_content->{errorMessage}) {

            my %error_content = ();
            if(defined $parse_content->{message}) {
                $error_content{message} = $parse_content->{message};
            } else { # errorMessage
                $error_content{message} = $parse_content->{errorMessage};
            }

            if(defined $parse_content->{errorCode}) {
                $error_content{ssb1} =
                    $parse_content->{errorCode}->{SSB1} // 0;
                $error_content{ssb2} =
                    $parse_content->{errorCode}->{SSB2} // 0;
            }

            if(defined $parse_content->{solutionType}) {
                $error_content{solution_type} = $parse_content->{solutionType};
            }

            return \%error_content;
        }

        return;
    }

    # If JSON was provided, parse admin status resources.
    # If no status resources were found, this method returns undef.
    sub _parse_admin_status_resources {
        my ($content) = @_;

        if(!defined $content) {
            return;
        }

        # { "statusResource": "example" }
        # OR
        # "data": [ { "statusResource": "example" } ]

        # If we're just a statusResource object, set it into a new array and
        # return it.
        if(defined $content->{statusResource}) {
            my @statusResources = ($content->{statusResource});
            return \@statusResources;
        }

        # If we're an array of objects contianing statusResource,
        # iterate each one and add it to a new array and then return it.
        if(defined $content->{data} && Util::is_array_ref($content->{data}) &&
                @{$content->{data}}>0) {

            # We should never get a mix of elements, so we'll just check the
            # first one.
            if(Util::is_hash_ref($content->{data}->[0]) &&
                    defined $content->{data}->[0]->{statusResource}) {
                my @statusResourceii = ();
                foreach my $i (@{$content->{data}}) {
                    # Despite that we should not get a mix, we'll still make
                    # sure each one contains a "statusResource".
                    if(defined $i->{statusResource}) {
                        push @statusResourceii, $i->{statusResource};
                    }
                }
                return \@statusResourceii;
            }
        }

        # No status resources.
        return;
    }

    # Create a new response object with the response and JSON content (if any).
    sub new {
        my ($class, $response, $json_content) = @_;

        # If the JSON content is an array, we will place it inside of
        # a "data" element.  This ensures that we always have a hash for
        # our content.
        # We use 'data' as it is a common element used for housing arrays
        # in the API.  Only, sometimes it's not used.
        if(defined $json_content && Util::is_array_ref($json_content)) {
            my %new_json_content = ("data" => $json_content);
            $json_content = \%new_json_content;
        }

        my $error_content = _parse_error_content($json_content);
        my $admin_status_resources =
            _parse_admin_status_resources($json_content);

        my $self = {
            response                => $response,
            content                 => $json_content,
            error_content           => $error_content,
            admin_status_resources  => $admin_status_resources,
        };

        return bless $self, $class;
    }

    # Determine if the response was a 200 error with empty response.
    # This is tagged as error as per documentation saying a retry is needed
    # under this condition.
    # This does not apply if discarding sessions.
    sub _is_200_empty_response_error {
        my ($class) = @_;

        if($class->{response}->code==200 && !defined $class->{content}) {

            # If we're discarding sessions, this rule does not apply.
            my $request = $class->{response}->{request};
            if(defined $request && $request->method eq "DELETE" &&
                    "${ \$request->uri() }" =~ /sessions/) {
                return;
            }
            return 1;
        }

        return;
    }

    # Determine if the response was 500 and the content was HTML.
    sub _is_html_with_500_error {
        my ($class) = @_;

        return $class->{response}->code==500 &&
            $class->{response}->content_type =~ m{^text/html}i;
    }

    # Defermine if the response was an error.
    # Parameters:
    #   $ignorable_errors: List of SSB pairs to ignore (or undef).
    #   $ignorable_codes: List of HTTP codes to ignore (or undef).
    sub is_error {
        my ($class, $ignorable_errors, $ignorable_codes) = @_;

        # If we've been given ignorable errors and our error is one of them,
        # return undef to declare no error.
        if(defined $ignorable_errors && defined $class->{error_content} &&
            $class->has_ssb()) {

           foreach my ($ssb1, $ssb2) (@$ignorable_errors) {
                if($class->ssb1()==$ssb1 && $class->ssb2()==$ssb2) {
                    return;
                }
            }
        }

        # If we've been given ignorable HTTP status codes and our code is
        # one of them, return undef and declare no error.
        if(defined $ignorable_codes && $class->{response}->is_error()) {
            foreach my $code (@$ignorable_codes) {
                if($class->{response}->code==$code) {
                    return;
                }
            }
        }

        # Do not need to check _is_html_with_500_error() as 500 will be
        # an error already.
        return defined $class->{error_content} ||
            $class->{response}->is_error() ||
            $class->_is_200_empty_response_error();
    }

    # Determine if the response was an authentication failure.
    sub is_auth_fail {
        my ($class) = @_;

        return $class->{response}->code()==401;
    }

    # Get the response code.
    sub code {
        my ($class) = @_;

        return $class->{response}->code();
    }

    # Determine if the reply was an admin asynchronous reply that needs
    # to be followed up.
    sub is_admin_async_reply {
        my ($class) = @_;

        return defined $class->{admin_status_resources};
    }

    # Returns 1 or more statusResource values as returned from
    # admin API.  This will always appear as an array if not undef.
    # If no status resources were found, this subroutine returns undef.
    sub admin_api_async_status_resources {
        my ($class) = @_;

        if(!defined $class->{admin_status_resources}) {
            return;
        }

        return $class->{admin_status_resources};
    }

    sub _is_solution_type_retry {
        my ($class) = @_;

        return defined $class->{error_content} &&
               defined $class->{error_content}->{solution_type} &&
               $class->{error_content}->{solution_type} eq 'RETRY';
    }

    # Determine if this result is a retryable result.
    # If this is not a retryable result, this subroutine returns undef.
    sub should_retry {
        my ($class) = @_;

        if($class->is_error()) {
            # Retry on auth failure.
            if($class->is_auth_fail()) {
                return 1;
            }

            # Retry on 503.
            if($class->{response}->code()==503) {
                return 1;
            }

            # Retry on empty response with 200.
            if($class->_is_200_empty_response_error()) {
                return 1;
            }

            # Retry on 500 with HTML format.
            if($class->_is_html_with_500_error()) {
                return 1;
            }

            # Retry if we got an error object with a solution type and
            # the solution type was RETRY.
            if($class->_is_solution_type_retry()) {
                return 1;
            }
        }

        return;
    }

    # Get a formatted error message:
    # 1. If a JSON error was returned: the message followed by the SSB codes.
    # 2. If no JSON error, but 401 was returned: "Authorization failed".
    # 3. Otherwise "Success.".
    sub get_format_error_message {
        my ($class) = @_;

        my $message = $class->error_message();
        if(defined $class->{error_content}) {
            if($class->has_ssb()) {
            $message .= " [SSB1=0x${ \$class->ssb1() }, " .
                        "SSB2=0x${ \$class->ssb2() }]";
            }
        } elsif($class->is_auth_fail()) {
            $message = "Authorization failed.";
        }

        return $message;
    }

    # Get the error message.
    # If no error occurred, this subroutine returns "Success.".
    sub error_message {
        my ($class) = @_;

        my $message = "Success.";
        if(defined $class->{error_content}) {
            $message = $class->{error_content}->{message};
        } elsif(($class->{response}->header('Client-Warning') // '') eq
            'Internal response') {
            # This is Perl's internal way of declaring an error outside
            # of an actual response, such as a timeout.
            $message = $class->{response}->message;
        } elsif($class->{response}->is_error()) {
            $message = $class->{response}->status_line();
        }

        return $message;
    }

    # Defermine if this object has SSB codes.
    sub has_ssb {
        my ($class) = @_;

        return defined $class->{error_content} &&
            defined $class->{error_content}->{ssb1};
    }

    # Get the returned SSB1 code (or 0 if only SSB2 was provided).
    # Otherwise undef.
    sub ssb1 {
        my ($class) = @_;

        if(!$class->has_ssb()) {
            return;
        }

        return $class->{error_content}->{ssb1};
    }

    # Get the returned SSB2 code (or 0 if only SSB1 was provided).
    # Otherwise undef.
    sub ssb2 {
        my ($class) = @_;

        if(!$class->has_ssb()) {
            return;
        }

        return $class->{error_content}->{ssb2};
    }

    # Determine if there was returned JSON content.
    sub has_content {
        my ($class) = @_;

        return defined $class->{content};
    }

    # Gets a hash of the returned JSON content if there was any, o
    # therwise undef.
    sub content {
        my ($class) = @_;

        return $class->{content};
    }

}

####################################################
# HSPV::Util package
####################################################

package HSPV::Util {

    use strict;
    use warnings;
    use JSON;
    use JSON::XS  qw(decode_json encode_json);
    use PVE::Cluster;
    use PVE::INotify;
    use PVE::Tools;

    # Log the object and perform a die.
    sub throw {
        my ($obj) = @_;

        #my $filename = (caller(0))[1]; - Always same file.
        my $line = (caller(0))[2];
        my $subroutine = (caller(1))[3];


        #"Exception (at $filename, line $line [$subroutine]): $obj"
        my $msg = "Exception (at line $line [$subroutine]): $obj";

        if(Log::is_debug_enabled()) {
            my $stack_trace = get_stack_trace(2, "\t");
            chomp($msg);
            Log::error("$msg\n$stack_trace");
        } else {
            Log::error($msg);
        }

        # Make sure we don't strip our type if we're a reference type.
        if(ref($obj)) {
            die $obj;
        }

        die "$obj\n";
    }

    # Untaint a value from an external source.  This will also strip out
    # anything that isn't alphanumeric, or '.', '_', '-', ':'.
    # Note that this returns undef if illegal characters are found.
    sub untaint {
        my ($tainted_value) = @_;

        if (!defined $tainted_value) {
            throw "Invalid value for untainting (undefined).";
        }

        # Untaint value
        # Values build externally are tainted under -T.
        # The name by this untaint can only ever contains alphanumeric chars,
        # dots, dashes, underscores, and colons.
        my ($untainted_value) = ($tainted_value =~ /\A([A-Za-z0-9._\-:]+)\z/);

        if(!defined $untainted_value) {
            throw "Could not untaint $tainted_value as it contains " .
                  " unexpected characters.";
        }
        return $untainted_value;
    }

    # This validates that the given name is in the correct format
    # with only allowable characters. It does not validate length.
    # This aims to make sure the name is an allowable filename/storage name.
    # Requirements:
    #   - First character is alpha.
    #   - Middle characters contain only alphanumeric, dash, underscore, and
    #     period
    #   - Last character is alphanumeric.
    #   - Lower or upper case is allowed.
    sub is_name_valid {
        my ($name) = @_;

        if($name !~ m/^[a-z][a-z0-9\-\_\.]*[a-z0-9]$/i) {
            return;
        }
        return 1;
    }

    # Returns 1 if numeric, undef otherwise.
    sub is_numeric {
        my ($test_value) = @_;

        use constant {
            NUMERIC_REGEX => "[0-9]+",
        };

        my $numeric_regex = NUMERIC_REGEX; # can't use constant directly.
        return $test_value =~ /\A$numeric_regex\z/;
    }

    # Returns 1 if the reference is an array reference, undef otherwise.
    sub is_array_ref {
        my ($check) = @_;

        return ref($check) eq 'ARRAY';
    }

    # Returns 1 if the reference is a hash reference, undef otherwise.
    sub is_hash_ref {
        my ($check) = @_;

        return ref($check) eq 'HASH';
    }

    # Returns the json representation for a boolean (true or false).
    sub json_bool {
        my ($value) = @_;

        return $value ? JSON::true : JSON::false;
    }

    # Strip newlines from the given string.
    sub strip_newlines {
        my ($str) = @_;
        $str =~ s/[\n\r]//g;
        return $str;
    }

    sub default_censor_string {
        return "********";
    }

    # Censor the values for a given list of keys in a list.
    # This only does top-level censorship.
    sub censor_hash {
        my ($hash, $censor_keys) = @_;

        foreach my $item (@$censor_keys) {
            if(exists $hash->{$item}) {
                $hash->{$item} = default_censor_string();
            }
        }
    }

    # Censor the values for a given list of keys in a JSON string.
    # This only does top-level censorship.
    sub censor_json_string {
        my ($json_str, $censor_keys) = @_;

        # Re-decode the JSON, censor any sensitive keys,
        # and re-encode it.  Then log.
        my $json = decode_json($json_str);
        censor_hash($json, $censor_keys);
        return encode_json($json);
    }

    sub json_to_str {
        my ($json) = @_;
        return encode_json($json);
    }

    # Convert the given string to a hex string.
    sub str_to_hex {
        my ($str) = @_;
        return unpack('H*', $str);
    }

    # Conver the given hex string to a string.
    sub hex_to_str {
        my ($hex_str) = @_;
        return pack('H*', $hex_str);
    }

    # Determines if the given string starts with the given prefix.
    sub starts_with {
        my ($str, $prefix) = @_;
        return index($str, $prefix)==0;
    }

    # Determines if the given string ends with the given prefix.
    sub ends_with {
        my ($str, $suffix) = @_;
        return rindex($str, $suffix)==(length($str)-length($suffix));
    }

    # Convert from the given capacity to the given capacity.
    use constant {
        SIZE_TB    => 40,
        SIZE_GB    => 30,
        SIZE_MB    => 20,
        SIZE_KB    => 10,
        SIZE_BLOCK => 9,
        SIZE_B     => 0,
    };
    sub convert_capacity {
        my ($capacity, $size_from, $size_to) = @_;

        my $shift = $size_from-$size_to;
        if($shift<0) {
            return $capacity >> abs($shift);
        }
        return $capacity << $shift;
    }

    sub is_capacity_aligned {
        my ($capacity, $size_at, $size_align) = @_;

        my $align = convert_capacity($capacity, $size_at, $size_align);
        return $capacity==convert_capacity($align, $size_align, $size_at);

    }

    # Print the given JSON (debug).
    sub print_json {
        my ($hash_or_array) = @_;

        print encode_json($hash_or_array), "\n";
    }

    sub get_stack_trace {
        my ($skip_levels, $line_prefix) = @_;

        my $i = 0;
        my $trace = '';

        my $skip = $skip_levels // 0;
        $i += $skip;

        my $prefix = $line_prefix // '';

        while (my @c = caller($i++)) {
            $trace .= sprintf(
                "%s#%d %s called from %s line %d\n",
                $prefix,
                $i - 1 - $skip,
                ($c[3] || 'main'),
                $c[1],
                $c[2]
            );
        }

        return $trace;
    }

    ####################################################
    # Project-specific utiltiies.
    ####################################################

    # Get the IP of the current proxmox node or undef if not found.
    sub get_current_node_ip {

        # Get current hostname.
        my $nodename = PVE::INotify::nodename();

        # Resolve cluser IP for this node.
        my ($node_ip) = PVE::Cluster::remote_node_ip($nodename);

        return $node_ip;
    }

    sub check_disk_file_exist {
        my ($file_path, $timeout) = @_;

        # Return 0 immediately if file_path is undefined or empty
        return 0 unless defined $file_path && length $file_path;

        # Assign default value 1 if timeout is undefined
        $timeout = 1 unless defined $timeout;

        # Track the elapsed time
        my $elapsed = 0;
        my $interval = 1;

        while ($elapsed < $timeout) {
            if (-e $file_path) {
                return 1;
            }

            sleep($interval);
            $elapsed += $interval;
        }

        # Return 0 if the file does not appear before the timeout
        return 0;
    }
}

####################################################
# HSPV::Util::Capacity (object) package
####################################################

package HSPV::Util::Capacity {

    use strict;
    use warnings;
    use Scalar::Util;

    BEGIN {
        *Util:: = *HSPV::Util::;
        *throw = \&HSPV::Util::throw;
        *Log:: = *HSPV::Log::;
    }

    use overload
        '+' => '_add',
        '-' => '_sub',
        '<' => '_lt',
        '>' => '_gt',
        '==' => '_eq',
        '""' => 'to_string';

    # Create a new capacity object.
    # size_at should be one of the convert_capacity values in
    # HSPV::Util.  size_at my be undef for bytes.
    sub new {
        my ($class, $size, $size_at) = @_;

        if($size<0) {
            eval {
                # Note: we do these shenanigans to get a stack trace in the
                # log in case this ever happens.
                throw "Detected negative capacity value!";
            } or do {
                $size = 0;
            };
        }

        my $self = {
            size_bytes => Util::convert_capacity($size,
                                                 $size_at // Util::SIZE_B(),
                                                 Util::SIZE_B()),
        };

        return bless $self, $class;
    }

    sub aligned_block {
        my ($class) = @_;
        return Util::is_capacity_aligned($class->{size_bytes},
                                      Util::SIZE_B(),
                                      Util::SIZE_BLOCK());
    }
    sub aligned_kb {
        my ($class) = @_;
        return Util::is_capacity_aligned($class->{size_bytes},
                                      Util::SIZE_B(),
                                      Util::SIZE_KB());
    }
    sub aligned_mb {
        my ($class) = @_;
        return Util::is_capacity_aligned($class->{size_bytes},
                                      Util::SIZE_B(),
                                      Util::SIZE_MB());
    }
    sub aligned_gb {
        my ($class) = @_;
        return Util::is_capacity_aligned($class->{size_bytes},
                                      Util::SIZE_B(),
                                      Util::SIZE_GB());
    }
    sub aligned_tb {
        my ($class) = @_;
        return Util::is_capacity_aligned($class->{size_bytes},
                                      Util::SIZE_B(),
                                      Util::SIZE_TB());
    }

    sub as_bytes { my ($class) = @_; return $class->{size_bytes}; }
    sub as_block {
        my ($class) = @_;
        return Util::convert_capacity($class->{size_bytes},
                                      Util::SIZE_B(),
                                      Util::SIZE_BLOCK());
    }
    sub as_kb {
        my ($class) = @_;
        return Util::convert_capacity($class->{size_bytes},
                                      Util::SIZE_B(),
                                      Util::SIZE_KB());
    }
    sub as_mb {
        my ($class) = @_;
        return Util::convert_capacity($class->{size_bytes},
                                      Util::SIZE_B(),
                                      Util::SIZE_MB());
    }
    sub as_gb {
        my ($class) = @_;
        return Util::convert_capacity($class->{size_bytes},
                                      Util::SIZE_B(),
                                      Util::SIZE_GB());
    }
    sub as_tb {
        my ($class) = @_;
        return Util::convert_capacity($class->{size_bytes},
                                      Util::SIZE_B(),
                                      Util::SIZE_TB());
    }

    sub _add {
        my ($class, $capacity) = @_;

        return __PACKAGE__->new($class->as_bytes()+$capacity->as_bytes());
    }

    sub _sub {
        my ($class, $capacity) = @_;

        return __PACKAGE__->new($class->as_bytes()-$capacity->as_bytes());
    }

    sub _lt {
        my ($class, $capacity) = @_;

        return $class->as_bytes() < $capacity->as_bytes();
    }

    sub _gt {
        my ($class, $capacity) = @_;

        return $class->as_bytes() > $capacity->as_bytes();
    }

    sub _eq {
        my ($class, $capacity) = @_;

        return $class->as_bytes() == $capacity->as_bytes();
    }

    sub to_string {
        my ($class, $capacity) = @_;

        my $suffix;
        my $value;
        if($class->as_bytes() == 0 ) {
            $value = 0;
            $suffix = "KB";
        } elsif($class->aligned_tb()) {
            $value = $class->as_tb();
            $suffix = "TB";
        } elsif($class->aligned_gb()) {
            $value = $class->as_gb();
            $suffix = "GB";
        } elsif($class->aligned_mb()) {
            $value = $class->as_mb();
            $suffix = "MB";
        } elsif($class->aligned_kb()) {
            $value = $class->as_kb();
            $suffix = "KB";
        } else {
            $value = $class->as_bytes();
            $suffix = " bytes";
        }

        return "$value$suffix";
    }
}

####################################################
# HSPV::Util::BlockDevice package
####################################################

package HSPV::Util::BlockDevice {

    use strict;
    use warnings;

    BEGIN { *Log:: = *HSPV::Log::; }

    #####################
    # FC
    #####################
    sub get_local_node_active_wwpns {
        my @wwn_list;
        my @files = glob('/sys/class/fc_host/host*/port_name');

        ## no critic (InputOutput::RequireBriefOpen)
        foreach my $file (@files) {
            # Derive the port_state path from the port_name path.
            (my $state_file = $file) =~ s{/port_name\z}{/port_state};

            # Only include ports that are Online.
            my $state = '';
            if (open(my $sfh, '<', $state_file)) {
                $state = <$sfh>;
                chomp($state) if defined $state;
                $state =~ s/^\s+|\s+$//g if defined $state;
                $state //= '';
                close($sfh);
            } else {
                Log::info("Could not read file $state_file: $!");
            }

            if ($state ne 'Online') {
                Log::debug("get_local_node_active_wwpns: skipping $file " .
                           "(port_state='$state').");
                next;
            }

            if (open(my $fh, '<', $file)) {
                while (my $line = <$fh>) {
                    chomp($line);
                    $line =~ s/^\s+|\s+$//g;
                    $line =~ s/^0x//i; # remove leading 0x if present
                    push(@wwn_list, $line) if $line ne '';
                }
                close($fh);
            } else {
                Log::info("Could not read file $file: $!");
            }
        }

        return \@wwn_list;
    }

    # Trigger a FC scan on the local Fibre Channel host adapters so the
    # kernel discovers newly-mapped LUNs.  Writes "- - -" to each
    # /sys/class/scsi_host/hostN/scan file that corresponds to an FC HBA
    # (identified by /sys/class/fc_host/hostN being present).
    # $hbas: optional arrayref of WWPNs (as returned by
    #        get_local_node_active_wwpns) to restrict the rescan to only
    #        those HBAs. If undef, all local FC HBAs are rescanned.
    # Returns 1 if all hosts were scanned successfully, 0 if any failed.
    sub fc_rescan {
        my ($hbas) = @_;

        my %hba_lookup;
        if(defined $hbas) {
            %hba_lookup = map { lc($_) => 1 } @$hbas;
        }

        my @fc_hosts = glob('/sys/class/fc_host/host*');
        if (!@fc_hosts) {
            Log::warning("fc_rescan: no FC host adapters found.");
            return 0;
        }

        my $ok = 1;
        foreach my $fc_host (@fc_hosts) {
            my ($host_name) = ($fc_host =~ m{(host\d+)\z});
            next unless defined $host_name;

            if(defined $hbas) {
                my $wwn = '';
                if(open(my $wfh, '<', "$fc_host/port_name")) {
                    $wwn = <$wfh>;
                    chomp($wwn) if defined $wwn;
                    $wwn =~ s/^\s+|\s+$//g if defined $wwn;
                    $wwn =~ s/^0x//i if defined $wwn;
                    close($wfh);
                }
                if(!exists $hba_lookup{lc($wwn // '')}) {
                    Log::debug("fc_rescan: skipping $host_name, WWN " .
                               "'$wwn' not in requested HBA list.");
                    next;
                }
            }

            my $scan_path = "/sys/class/scsi_host/$host_name/scan";
            eval {
                open(my $fh, '>', $scan_path)
                    or die "Cannot open $scan_path: $!";
                print $fh "- - -\n";
                close($fh);
            };
            if ($@) {
                my $err = $@;
                chomp($err) if defined $err;
                Log::error("fc_rescan($host_name). Failed reason: $err");
                $ok = 0;
            } else {
                Log::debug("fc_rescan: triggered scan on $host_name.");
            }
        }

        return $ok;
    }

    #####################
    # iSCSI
    #####################

    sub iscsi_login {
        my ($target_iqn, $portal) = @_;

        eval {
            PVE::Tools::run_command([
                'iscsiadm', '--mode', 'node',
                '--targetname', $target_iqn,
                '--portal',     $portal,
                '--login',
            ]);
        };
        if ($@) {
            my $err = $@;
            chomp($err) if defined $err;
            Log::error("iscsi_login. Failed reason: $err");
            # exit code 15 = ISCSI_ERR_SESS_EXISTS:
            # session already present, treat as success
            # see "EXIT STATUS" in "man iscsiadm"
            return 1 if $err =~ /exit code 15/;
            return 0;
        }
        return 1;
    }

    sub iscsi_discover {
        my ($portal) = @_;

        eval {
            PVE::Tools::run_command([
                'iscsiadm', '--mode', 'discovery',
                '--type',   'sendtargets',
                '--portal', $portal,
            ],
            outfunc => sub {
                my ($line) = @_;
                Log::info("iscsi_discover($portal): $line");
            },
            errfunc => sub {
                my ($line) = @_;
                Log::error("iscsi_discover($portal): $line");
            });
        };
        if ($@) {
            my $err = $@;
            chomp($err) if defined $err;
            Log::error("iscsi_discover($portal). Failed reason: $err");
            return 0;
        }
        return 1;
    }

    sub iscsi_rescan {
        # if call this function without any parameters, it will rescan all
        # targets and portals. So, below command still works:
        # iscsiadm --mode node --targetname "" --portal "" --rescan
        my ($target_iqn, $portal) = @_;

        eval {
            PVE::Tools::run_command([
                'iscsiadm', '--mode', 'node',
                '--targetname', $target_iqn,
                '--portal',     $portal,
                '--rescan',
            ]);
        };
        if ($@) {
            my $err = $@;
            chomp($err) if defined $err;
            Log::error("iscsi_rescan. Failed reason: $err");
            return 0;
        }
        return 1;
    }

    # Returns 1 if a session exists for target+portal, 0 otherwise.
    sub iscsi_session_exists {
        my ($target_iqn, $portal) = @_;

        my @output;
        eval {
            PVE::Tools::run_command([
                'iscsiadm', '--mode', 'session',
            ],
            outfunc => sub {
                my ($line) = @_;
                push @output, $line;
            },
            errfunc => sub {
                my ($line) = @_;
                push @output, $line;
            });
        };
        if($@) {
            my $err = $@;
            chomp($err) if defined $err;

            # No active sessions should not be treated as an error.
            if($err =~ /No active sessions|exit code 21/i) {
                return 0;
            }

            Log::error("iscsi_session_exists. Failed reason: $err");
            return 0;
        }

        foreach my $line (@output) {
            if(index($line, $target_iqn)>=0 && index($line, $portal)>=0) {
                return 1;
            }
        }

        return 0;
    }

    # Cache a volume path into the persistent cache.
    # If path is undef, this subroutine will remove it from the cache.
    sub _cache_volume_path {
        my ($class, $storeid, $volname, $path) = @_;

        my $callback = sub {
            my ($data, $update_data) = @_;

            my $volname = $update_data->{volname};
            my $path = $update_data->{path};

            if(!defined $path) {
                delete $data->{filesystem_paths}->{$volname};
            } else {
                $data->{filesystem_paths}->{$volname} = $path;
            }
            return 1;
        };

        my $pkg = 'PVE::Storage::Custom::HitachiHSPVPlugin';
        my $category = $pkg->PERSISTENT_CACHE_CACHING_CATEGORY();
        return PersistentCache::update_cache(
                $category, $storeid, { volname=>$volname, path=>$path },
                $callback, 0);

    }

    # Get the iSCSI intiator name or undef if not found.
    sub get_local_node_iscsi_initiator_name {

        my $iqn;
        my $file = '/etc/iscsi/initiatorname.iscsi';
        eval {
            open(my $fh, '<', $file) or die "Cannot open $file: $!";
            while (my $line = <$fh>) {
                chomp $line;
                if ($line =~ /^InitiatorName=(.+)$/) {
                    $iqn = $1;
                    last;
                }
            }
            close($fh);
        };
        if ($@) {
            my $err = $@;
            chomp($err) if defined $err;
            Log::error("get_local_node_iscsi_initiator_name. " .
                       "Failed reason: $err");
            return;
        }
        return $iqn;
    }

    ####################
    # Generic
    ####################

    # Wait for udev to process device events after iSCSI changes.
    sub udev_settle {
        my ($timeout) = @_;
        $timeout = 10 if !defined $timeout;

        eval {
            PVE::Tools::run_command([
                'udevadm', 'settle', "--timeout=$timeout",
            ]);
        };
        if($@) {
            my $err = $@;
            chomp($err) if defined $err;
            Log::error("udev_settle. Failed reason: $err");
            return 0;
        }

        return 1;
    }

    # Nudge multipathd to pick up newly-discovered paths without disrupting
    # existing multipath maps.  'multipathd reconfigure' re-reads the config
    # and checks for new/changed paths but does NOT force-reload DM maps,
    # unlike 'multipath -r' which reloads all maps and can cause transient
    # I/O pauses on currently-active multipath devices.
    # Returns 1 on success, 0 on failure.
    sub multipath_reload {
        eval {
            PVE::Tools::run_command(['multipathd', 'reconfigure']);
        };
        if ($@) {
            my $err = $@;
            chomp($err) if defined $err;
            Log::error("multipath_reload. Failed reason: $err");
            return 0;
        }
        return 1;
    }

    # Remove any partition holder dm devices (e.g. mpathX-part1/2/3, created
    # by kpartx for a partitioned VM disk) for the multipath map identified
    # by WWID.  These holders keep the parent dm device open, so
    # 'multipathd del map' fails with "map in use" until they are torn down.
    # 'dmsetup remove -f --deferred' is used instead of a plain remove so that
    # a holder that is still momentarily busy is scheduled for removal on
    # last close rather than causing a hard failure here.
    # Returns 1 if all holders were removed (or none existed), 0 otherwise.
    sub _remove_multipath_subpartitions {
        my ($safe_wwid) = @_;

        my $dm_link = "/dev/disk/by-id/dm-uuid-mpath-$safe_wwid";
        my $dm_target = readlink($dm_link);
        if(!defined $dm_target) {
            # No dm device to resolve; nothing to clean up.
            return 1;
        }

        my ($dm_name) = ($dm_target =~ m{([^/]+)\z});
        if(!defined $dm_name || $dm_name !~ /\Adm-\d+\z/) {
            Log::warning("_remove_multipath_subpartitions: unexpected dm " .
                         "target '$dm_target'.");
            return 0;
        }

        my %visited;
        my $ok = 1;

        # Example:
        #   dm-0
        #   ├── dm-1
        #   │   └── dm-3
        #   └── dm-2
        #
        # DFS removes holders in post-order: dm-3, dm-1, dm-2.
        # The root dm-0 is NOT removed in here.
        # Upper multipath_del_map() will delete later
        my $dfs;
        $dfs = sub {
            my ($current_dm) = @_;

            # Prevent processing duplicate or cycling holders.
            return if $visited{$current_dm};
            $visited{$current_dm} = 1;

            # 1. First, visit all downstream holders (go deeper).
            my $holders_dir = "/sys/block/$current_dm/holders";
            if (opendir(my $dh, $holders_dir)) {
                my @direct_holders = grep { /\Adm-\d+\z/ } readdir($dh);
                closedir($dh);

                foreach my $holder (@direct_holders) {
                    # Untaint holder name before recursion.
                    my ($safe_holder) = ($holder =~ /\A(dm-\d+)\z/);
                    if (defined $safe_holder) {
                        $dfs->($safe_holder);
                    }
                }
            } else {
                Log::warning("_remove_multipath_subpartitions: failed to" .
                    "open $holders_dir: $!");
            }

            # 2. Skip removal for the root multipath target device itself.
            return if $current_dm eq $dm_name;

            # 3. remove the holder after all its sub-holders are gone.
            eval {
                PVE::Tools::run_command(
                    ['dmsetup', 'remove', '--force', '--deferred',
                     "/dev/$current_dm"]);
            };
            if ($@) {
                my $err = $@;
                chomp($err) if defined $err;
                Log::warning("_remove_multipath_subpartitions: failed to " .
                    "remove partition holder $current_dm for $safe_wwid: $err" .
                    "... If error is 'exit code 1', the subpartition will be" .
                    " automatically deleted soon.");
                $ok = 0;
            } else {
                Log::debug("_remove_multipath_subpartitions: deferred removal"
                    . "of partition holder $current_dm for $safe_wwid.");
            }
        };

        # Start DFS traversal from the root device.
        $dfs->($dm_name);

        return $ok;
    }
    # Remove a single multipath map identified by WWID without affecting
    # any other mpath devices.  Partition holders are removed first, then
    # the master dm node itself is removed directly via 'dmsetup remove
    # --force --deferred'.  This is used instead of 'multipathd del map'
    # because dmsetup supports --force/--deferred (queues removal instead
    # of failing with "map in use"); multipathd picks up the removal via
    # udev/dm events on its own, so no separate daemon call is needed.
    # $wwid: the multipath WWID string (e.g. '3<naa>').
    # Returns 1 on success, 0 on failure.
    sub multipath_del_map {
        my ($wwid) = @_;
        my $dflog = Log->function();

        # Untaint $wwid: Perl taint mode forbids passing tainted strings to
        # exec().  A multipath WWID is always a hex string (e.g. '3<naa>'),
        # so validate and re-extract via regex to produce an untainted copy.
        my ($safe_wwid) = ($wwid =~ /^([0-9a-fA-F]+)$/);
        if (!defined $safe_wwid) {
            Log::error("multipath_del_map: invalid/unexpected WWID '$wwid'");
            return 0;
        }

        Log::info("SafeWWID: '$safe_wwid'. WWID: '$wwid'.");

        # Partitioned disks (kpartx mpathX-partN mappings) keep the parent
        # map open; clear them out first so the removal below can succeed.
        if(!_remove_multipath_subpartitions($safe_wwid)) {
            Log::warning("multipath_del_map($safe_wwid): failed to remove " .
                         "one or more partition holders; map removal may " .
                         "still fail with 'map in use'.");
            # if fail with 'map in use', subpartition will be automatically
            # deleted after "reference counter" (in OS kernel) decrease to 0.
        }

        my $dm_link = "/dev/disk/by-id/dm-uuid-mpath-$safe_wwid";
        my $dm_target = readlink($dm_link);
        if(!defined $dm_target) {
            Log::debug("multipath_del_map($safe_wwid): map already " .
                       "removed (no dm-uuid symlink).");
            return 1;
        }

        my ($dm_name) = ($dm_target =~ m{([^/]+)\z});
        if(!defined $dm_name || $dm_name !~ /\Adm-\d+\z/) {
            Log::error("multipath_del_map($safe_wwid): unexpected dm " .
                       "target '$dm_target'.");
            return 0;
        }

        my @daemon_output;
        eval {
            PVE::Tools::run_command(
                ['dmsetup', 'remove', '--force', '--deferred',
                 "/dev/$dm_name"],
                outfunc => sub { push @daemon_output, $_[0]; },
                errfunc => sub { push @daemon_output, $_[0]; },
            );
        };
        if ($@) {
            my $err = $@;
            chomp($err) if defined $err;
            my $detail = @daemon_output ? join('; ', @daemon_output)
                                         : 'no daemon output captured';

            # Idempotent: the map is already gone.
            if ($detail =~ /not found|no such/i || $err =~ /not found|no such/i) {
                Log::debug("multipath_del_map($safe_wwid): map already " .
                           "removed ($detail).");
                return 1;
            }

            Log::error("multipath_del_map($safe_wwid). Failed reason: " .
                "$err. Daemon output: $detail.");
            return 0;
        }

        Log::debug("multipath_del_map($safe_wwid): removed master dm " .
                   "device $dm_name.");
        return 1;
    }

    # Return the list of bare sdX device names that are slaves of the
    # multipath dm device identified by WWID.
    # Reads /sys/block/dm-N/slaves/ after resolving the dm-uuid symlink.
    # Returns a (possibly empty) list of device names, e.g. ('sdb', 'sdc').
    sub get_dm_slaves {
        my ($wwid) = @_;

        my $dm_link = "/dev/disk/by-id/dm-uuid-mpath-$wwid";
        my $dm_target = readlink($dm_link);
        if(!defined $dm_target) {
            Log::warning("get_dm_slaves: could not resolve $dm_link.");
            return ();
        }

        # readlink returns e.g. '../../dm-3'; extract the device name.
        my ($dm_name) = ($dm_target =~ m{([^/]+)\z});
        if(!defined $dm_name || $dm_name !~ /\Adm-\d+\z/) {
            Log::warning("get_dm_slaves: unexpected dm target '$dm_target'.");
            return ();
        }

        my $slaves_dir = "/sys/block/$dm_name/slaves";
        my @slaves;
        eval {
            opendir(my $dh, $slaves_dir)
                or die "Cannot open $slaves_dir: $!";
            while(my $entry = readdir($dh)) {
                next if $entry eq '.' || $entry eq '..';
                push @slaves, $entry;
            }
            closedir($dh);
        };
        if($@) {
            my $err = $@;
            chomp($err) if defined $err;
            Log::warning("get_dm_slaves: $err");
            return ();
        }

        return @slaves;
    }

    # Cleanly remove a SCSI block device from the kernel by writing '1' to
    # its sysfs delete attribute.  This is the correct way to retire a
    # /dev/sdX without leaving a zombie device node.
    # $dev_name: bare device name, e.g. 'sdb' (NOT '/dev/sdb').
    # Returns 1 on success, 0 on failure.
    sub remove_dev_disk {
        my ($dev_name) = @_;

        # Validate and untaint: capture produces a taint-clean copy.
        # Reject anything that doesn't look like a plain sd* name to
        # prevent path traversal into arbitrary sysfs locations.
        my ($safe_dev) = ($dev_name =~ /\A(sd[a-z]+)\z/);
        if(!defined $safe_dev) {
            Log::error("remove_dev_disk: invalid device name '$dev_name'.");
            return 0;
        }

        Log::info("del_disk: safe_dev=$safe_dev; dev_name=$dev_name.");

        my $delete_path = "/sys/block/$safe_dev/device/delete";
        eval {
            open(my $fh, '>', $delete_path)
                or die "Cannot open $delete_path: $!";
            print $fh "1\n";
            close($fh);
        };
        if($@) {
            my $err = $@;
            chomp($err) if defined $err;
            Log::error("remove_dev_disk($safe_dev). Failed reason: $err");
            return 0;
        }

        Log::debug("remove_dev_disk: removed $safe_dev.");
        return 1;
    }

    # Resolve a /dev/disk/by-id symlink to the bare block device name
    # (e.g. 'sdb').  Returns undef if the symlink cannot be read.
    sub resolve_block_device {
        my ($symlink_path) = @_;

        my $target = readlink($symlink_path);
        return unless defined $target;

        # target is e.g. '../../sdb'
        my ($dev_name) = ($target =~ m{([^/]+)\z});
        return $dev_name;
    }

    sub clean_iscsi_session_and_node {
        my ($target_iqn, $portal) = @_;
        my $dflog = Log->function();

        # Steps:
        # 1. Search all directories under /sys/class/iscsi_session/ to find
        #    the directory where sessionXYZ/targetname matches $target_iqn
        # 2. Once found, if there are no sub directories matching the pattern
        #    "targetXYZ:0:0", it indicates that $target_iqn has no active
        #    LUNs remaining.
        # 3. In this case, run:
        #    "iscsiadm -m node -T <target_name> --logout"
        #    "iscsiadm -m node -T <target_name> -o delete"


        my $iscsi_session_dir = "/sys/class/iscsi_session";
        return if ! -d $iscsi_session_dir;

        opendir(my $dh, $iscsi_session_dir) or return;
        my @sessions = readdir($dh);
        closedir($dh);

        foreach my $sess (grep { /^session\d+$/ } @sessions) {
            my $targetname_file = "$iscsi_session_dir/$sess/targetname";
            next if ! -f $targetname_file;

            open(my $fh, '<', $targetname_file) or next;
            chomp(my $current_iqn = <$fh>);
            close($fh);

            # Skip if this session's IQN does not match the target IQN
            next if $current_iqn ne $target_iqn;

            my $device_dir = "$iscsi_session_dir/$sess/device";
            my @scsi_targets = grep { -d $_ } glob("$device_dir/target*");

            # no targetXYZ:A:B directory means that all LUNs are gone
            if (scalar(@scsi_targets) == 0) {
                Log::info("No active LUNs found for $target_iqn in $sess." .
                          " Safely logging out and deleting the iSCSI node.");

                # clean it
                my $success = 1;
                eval {
                    PVE::Tools::run_command(['iscsiadm', '-m', 'node', '-T',
                        $target_iqn, '-p', $portal, '--logout']);
                };
                if ($@) {
                    $success = 0;
                    Log::warning("Failed to logout $target_iqn: $@");
                }

                if ($success) {
                    eval {
                        PVE::Tools::run_command(['iscsiadm', '-m', 'node',
                            '-T', $target_iqn,
                            '-p', $portal, '-o', 'delete']);
                    };
                    if ($@) {
                        $success = 0;
                        Log::warning("Failed to del iSCSI node for ".
                                     " $target_iqn: $@");
                    }
                }

                if ($success) {
                    Log::info("Successfully logged out and deleted iSCSI" .
                               " node for $target_iqn.");
                } else {
                    Log::error("Failed to clean iSCSI target $target_iqn." .
                               " or delete the iSCSI node on $portal.");
                    return 0;
                }
            } else {
                Log::info("Target $target_iqn has " . scalar(@scsi_targets) .
                          " active LUNs. no clean");
            }

            last; # quit the loop after we find the target IQN and process
        }
    }
    return 1;
}

####################################################
# HSPV::PersistentCache package
####################################################

package HSPV::PersistentCache {

    use strict;
    use warnings;
    use File::Path qw(make_path);
    use PVE::Cluster;
    use PVE::Tools;
    use JSON::PP qw(decode_json encode_json);

    BEGIN { *throw = \&HSPV::Util::throw; }

    use constant {
        _CACHE_LOCATION => "/etc/pve/priv/hspv",
        _LOCK_TIMEOUT   => 5,
    };

    sub _is_valid_context {
        my ($context) = @_;

        if(!defined $context || $context eq "") {
            return 0;
        }

        # Reject path separators and parent-dir tokens to avoid traversal.
        if($context =~ m{[\\/]} || $context =~ /\.\./) {
            return 0;
        }

        # Keep contexts filename-safe and predictable.
        return $context =~ /\A[A-Za-z0-9._-]+\z/;
    }

    sub _is_valid_category {
        my ($category) = @_;

        if(!defined $category) {
            return 1;
        }

        # We use the same rules as the context,
        # except we're allowed to be undef.
        return _is_valid_context($category);
    }

    sub _is_valid_category_and_context {
        my ($category, $context) = @_;

        return _is_valid_category($category) && _is_valid_context($context);
    }

    sub _cache_dir {
        my ($category) = @_;
        return defined $category ?
            _CACHE_LOCATION . "/$category" :
            _CACHE_LOCATION;
    }

    sub _cache_file_name {
        my ($category, $context) = @_;
        return _cache_dir($category) . "/$context.json";
    }

    sub read_cache {
        my ($category, $context, $out_data, $sensitive, $nolock) = @_;

        my $read_file = sub {
            my ($file) = @_;

            open(my $handle, '<', $file) or die "Failed to open $file: $!";
            my $json = do {
                local $/; # slurp mode
                <$handle>
            };
            close($handle);

            return $json;
       };

        if(!_is_valid_category_and_context($category, $context)) {
            return 0;
        }
        if(!defined $out_data || ref($out_data) ne 'HASH') {
            return 0;
        }

        eval {
            my $file = _cache_file_name($category, $context);
            my $json;

            if($nolock) {
                $json = $read_file->($file);
            } else {
                PVE::Cluster::cfs_lock_domain($context, _LOCK_TIMEOUT, sub {
                    $json = $read_file->($file);
                });
            }

            my $parsed = {};
            if(defined $json && $json ne "") {
                $parsed = decode_json($json);
                if(ref($parsed) ne 'HASH') {
                    die "Cache data in $file is not a JSON object.";
                }
            }

            %$out_data = %$parsed;
        };

        if($@) {
            my $err = $@;
            chomp($err) if defined $err;
            Log::error(
                "read_cache. Failed for context '$context'. Reason: $err"
            );
            return 0;
        }

        if ($sensitive) {
            Log::verbose(
                "read_cache. context='$context' (sensitive, data omitted)."
            );
        } else {
            Log::verbose(
                "read_cache. context='$context'; data=" .
                encode_json($out_data),
            );
        }

        return 1;
    }

    sub write_cache {
        my ($category, $context, $data, $sensitive, $nolock) = @_;

        if(!_is_valid_category_and_context($category, $context)) {
            return 0;
        }
        if(!defined $data || ref($data) ne 'HASH') {
            return 0;
        }

        eval {
            my $dir = _cache_dir($category);
            make_path($dir);
            my $file = _cache_file_name($category, $context);
            my $json = encode_json($data);

            if($nolock) {
                PVE::Tools::file_set_contents($file, $json);
            } else {
                PVE::Cluster::cfs_lock_domain($context, _LOCK_TIMEOUT, sub {
                    PVE::Tools::file_set_contents($file, $json);
                });
            }
        };

        if($@) {
            my $err = $@;
            chomp($err) if defined $err;
            Log::error(
                "write_cache. Failed for context '$context'. Reason: $err",
            );
            return 0;
        }

        if ($sensitive) {
            Log::verbose(
                "write_cache. context='$context' (sensitive, data omitted)."
            );
        } else {
            Log::verbose(
                "write_cache. context='$context'; data=" . encode_json($data)
            );
        }

        return 1;
    }

    sub update_cache {
        my ($category, $context, $update_data, $callback, $sensitive) = @_;

        if(!_is_valid_category_and_context($category, $context)) {
            return 0;
        }

        my $file = _cache_file_name($category, $context);

        my $callback_success = 0;

        eval {
            my $dir = _cache_dir($category);
            make_path($dir);

            PVE::Cluster::cfs_lock_domain($context, _LOCK_TIMEOUT, sub {

                # Read the existing cache, or start with an empty hash.
                my %data = ();
                if(-e $file) {
                    eval {
                        open(my $handle, '<', $file)
                            or die "Failed to open $file: $!";
                        my $json = do { local $/; <$handle> };
                        close($handle);
                        if(defined $json && $json ne "") {
                            my $parsed = decode_json($json);
                            if(ref($parsed) ne 'HASH') {
                                die "Cache data in $file is not JSON object.";
                            }
                            %data = %$parsed;
                        }
                    };
                    if($@) {
                        die $@;
                    }
                }

                # Call the callback
                $callback_success = $callback->(\%data, $update_data);

                # Write back only if the callback reported success.
                if($callback_success) {
                    my $json = encode_json(\%data);
                    PVE::Tools::file_set_contents($file, $json);
                }
            });
        };

        if($@) {
            my $err = $@;
            chomp($err) if defined $err;
            Log::error(
                "update_cache. Failed for context '$context'. Reason: $err",
            );
            return 0;
        }

        if($callback_success) {
            my $category_str = defined $category ?
                "category='$category'; " : "";
            if($sensitive) {
                Log::verbose(
                    "update_cache. ${category_str}context='$context' " .
                    "(sensitive, data omitted)."
                );
            } else {
                Log::verbose(
                    "update_cache. ${category_str}context='$context'; " .
                    "data=" . encode_json($update_data)
                );
            }
        }

        return $callback_success ? 1 : 0;
    }

    sub delete_cache {
        my ($category, $context, $nolock) = @_;

        if(!_is_valid_category_and_context($category, $context)) {
            return 0;
        }

        eval {
            my $file = _cache_file_name($category, $context);

            if($nolock) {
                if(-e $file) {
                    unlink($file) or die "Failed to delete $file: $!";
                }
            } else {
                PVE::Cluster::cfs_lock_domain($context, _LOCK_TIMEOUT, sub {
                    if(-e $file) {
                        unlink($file) or die "Failed to delete $file: $!";
                    }
                });
            }
        };

        if($@) {
            my $err = $@;
            chomp($err) if defined $err;
            Log::error(
                "delete_cache. Failed for context '$context'. Reason: $err"
            );
            return 0;
        } else {
            Log::info("delete_cache. Deleted cache for context '$context'.");
        }

        return 1;
    }

    sub read_cache_timestamp {
        my ($category, $context) = @_;

        if(!_is_valid_category_and_context($category, $context)) {
            return ();
        }

        my @time_array = eval {
            my $file = _cache_file_name($category, $context);
            my $mtime;

            PVE::Cluster::cfs_lock_domain($context, _LOCK_TIMEOUT, sub {
                return if !-e $file;
                $mtime = (stat($file))[9];
            });

            my @values;
            @values = localtime($mtime) if defined $mtime;
            @values;
        };

        if($@) {
            my $err = $@;
            chomp($err) if defined $err;
            Log::error(
                "read_cache_timestamp. Failed for context '$context'. " .
                "Reason: $err",
            );
            return ();
        }

        if(@time_array < 6) {
            return ();
        }

        return @time_array[0..5];
    }
}

####################################################
# HSPV::Config package
####################################################

package HSPV::Config {

    use strict;
    use warnings;
    use JSON::PP qw(decode_json);

    use constant {
        _LOCAL_CONFFILE  => '/etc/hspv/hspv.json',
        _SHARED_CONFFILE => '/etc/pve/priv/hspv/hspv.json',
    };
    my $_conf;

    # Read the config from the given file.
    # The file should exist.
    sub _read_config_from {
        my ($file) = @_;

        my $conf = {};
        my $json;
        eval {
            my $success = open(my $handle, '<', $file);
            if(defined $success) {
                $json = do {
                    local $/; # slurp mode
                    <$handle>
                };
                close($handle);
            };
            1;
        };

        if(defined $json) {
            eval {
                $conf = decode_json($json);
            }
        }

        return $conf;
    }

    sub _read_config {

        my $conf = {};
        # Try to read local file first.
        if(-e _LOCAL_CONFFILE) {
            $conf = _read_config_from(_LOCAL_CONFFILE);
        } elsif(-e _SHARED_CONFFILE) {
            $conf = _read_config_from(_SHARED_CONFFILE);
        }

        return $conf;
    }

    sub _get_config {
        my ($config_name, $default) = @_;

        if(!defined $_conf) {
            $_conf = _read_config();
        }

        return defined $_conf->{$config_name} ?
            $_conf->{$config_name} : $default;
    }

    use constant {
        _NAME_HMO                  => 'hmo',
        _NAME_DEBUG                => 'debug',
        _NAME_LOG_TYPE             => 'log_type',
        _NAME_VALIDATE_SSL         => 'validate_ssl',
        _NAME_SSL_CA_FILE          => 'ssl_ca_file',
        _NAME_HTTP_CONNECT_TIMEOUT => 'http_connect_timeout',
        _NAME_HTTP_TIMEOUT         => 'http_timeout',
        _NAME_MAX_HTTP_RETRIES     => 'max_http_retries',
        _NAME_HTTP_RETRY_WAIT      => 'http_retry_wait',
        _NAME_ADMIN_ASYNC_WAIT_MS  => 'admin_async_wait_ms',
    };

    use constant {
        _DEFAULT_HMO                  => [91],
        _DEFAULT_DEBUG                => 0, # HSPV::LOG::_DEBUG_LEVEL_NONE
        _DEFAULT_LOG_TYPE             => 'SYSLOG', # HSPV_LOG::_LOGTYPE_SYSLOG
        _DEFAULT_VALIDATE_SSL         => 1,
        _DEFAULT_SSL_CA_FILE          => '',
        _DEFAULT_HTTP_CONNECT_TIMEOUT => 120,
        _DEFAULT_HTTP_TIMEOUT         => 600,
        _DEFAULT_MAX_HTTP_RETRIES     => 5,
        _DEFAULT_HTTP_RETRY_WAIT      => 30,
        _DEFAULT_ADMIN_ASYNC_WAIT_MS  => 1000,
    };

    sub hmo() {
        return _get_config(_NAME_HMO, _DEFAULT_HMO);
    }
    sub debug() {
        return _get_config(_NAME_DEBUG, _DEFAULT_DEBUG);
    }
    sub log_type() {
        return _get_config(_NAME_LOG_TYPE, _DEFAULT_LOG_TYPE);
    }
    sub validate_ssl() {
        return _get_config(_NAME_VALIDATE_SSL, _DEFAULT_VALIDATE_SSL);
    }
    sub ssl_ca_file() {
        return _get_config(_NAME_SSL_CA_FILE, _DEFAULT_SSL_CA_FILE);
    }
    sub http_connect_timeout() {
        return _get_config(_NAME_HTTP_CONNECT_TIMEOUT,
                           _DEFAULT_HTTP_CONNECT_TIMEOUT);
    }
    sub http_timeout() {
        return _get_config(_NAME_HTTP_TIMEOUT, _DEFAULT_HTTP_TIMEOUT);
    }
    sub max_http_retries() {
        return _get_config(_NAME_MAX_HTTP_RETRIES, _DEFAULT_MAX_HTTP_RETRIES);
    }
    sub http_retry_wait() {
        return _get_config(_NAME_HTTP_RETRY_WAIT, _DEFAULT_HTTP_RETRY_WAIT);
    }
    sub admin_async_wait_ms() {
        return _get_config(_NAME_ADMIN_ASYNC_WAIT_MS,
                           _DEFAULT_ADMIN_ASYNC_WAIT_MS);
    }

}

####################################################
# HSPV::NotFoundException package
####################################################

# This allows us to determine if an object wasn't found that we
# expected to be there.  By default it will just percolate up to proxmox and
# be converted to a string, but by using this class we can detect this
# situation if necessary for proper handling.
package HSPV::NotFoundException {
    use strict;
    use warnings;

    # This will use to_string() as a string conversion.
    use overload (
        '""'     => \&to_string,
        fallback => 1,
    );

    sub new {
        my ($class, $message) = @_;

        my $self = {
            message => $message,
        };

        return bless $self, $class;
    }

    sub to_string {
        my ($class) = @_;

        # Note: \n lets the message print out pretty.
        return "$class->{message}\n";
    }
}

####################################################
# HSPV::Log package
####################################################

package HSPV::Log {

    use strict;
    use warnings;
    use threads;
    use PVE::SafeSyslog qw(syslog);
    use Sys::Syslog qw(:macros);
    use File::Copy;

    use constant {
        _LOG_ERROR   => 'ERROR',
        _LOG_WARNING => 'WARN',
        _LOG_INFO    => 'INFO',
        _LOG_DEBUG   => 'DEBUG',
        _LOG_VERBOSE => 'VERBOSE',
    };

    use constant {
        _DEBUG_LEVEL_NONE => 0,
        _DEBUG_LEVEL_DEBUG => 1,
        _DEBUG_LEVEL_VERBOSE => 2,
    };

    use constant {
        _LOGTYPE_SYSLOG => 'SYSLOG',
        _LOGTYPE_FILE   => 'FILE',
        _LOGTYPE_PRINT  => 'PRINT',
        _LOGTYPE_NONE   => 'NONE',
    };

    use constant {
        _LOGFILE                   => '/var/log/hspv.log',
        _LOGFILE_ROTATE            => '/var/log/hspv1.log',
        _LOGFILE_ROTATE_AFTER_SIZE => 20971520,
    };

    my $_id;

    # Set the ID for the current script iteration.
    # This allows the log to set the context for the logging.
    sub set_id {
        my ($id) = @_;
        $_id = $id;
    }

    # Logging per log level.
    sub verbose { my ($message) = @_; _log(_LOG_VERBOSE, $message) }
    sub debug { my ($message) = @_; _log(_LOG_DEBUG, $message) }
    sub info { my ($message) = @_; _log(_LOG_INFO, $message) }
    sub warning { my ($message) = @_; _log(_LOG_WARNING, $message) }
    sub error { my ($message) = @_; _log(_LOG_ERROR, $message) }

    sub is_debug_enabled {
        return _is_log_level_enabled(HSPV::Config::debug(), _LOG_DEBUG);
    }
    sub is_verbose_enabled {
        return _is_log_level_enabled(HSPV::Config::debug(), _LOG_VERBOSE);
    }

    # Perform log rotation if necessary on the log file.
    sub _rotate_log_if_required {
        if(-s _LOGFILE > _LOGFILE_ROTATE_AFTER_SIZE) {
            copy(_LOGFILE, _LOGFILE_ROTATE);
            truncate(_LOGFILE, 0);
        }
    }

    # Log to the file.
    sub _log_to_file {
        my ($level, $logmsg) = @_;

        _rotate_log_if_required();

        my $success = open(my $handle, '>>', _LOGFILE);
        if(!defined $success) {
            # Fall back to syslog if file fails to open.
            _log_to_syslog(_LOG_ERROR, "Failed to open _LOGFILE.");
            _log_to_syslog($level, $logmsg);
        } else {
            print($handle $logmsg, "\n");
            close($handle);
        }
    }

    # Log to the syslog.
    sub _log_to_syslog {
        my ($level, $logmsg) = @_;

        # Default to error as anything else besides the below
        # should not occur.
        my $priority = LOG_ERR;
        if($level eq _LOG_ERROR) {
            $priority = LOG_ERR;
        }
        elsif($level eq _LOG_WARNING ) {
            $priority = LOG_WARNING;
        }
        elsif($level eq _LOG_INFO ) {
            $priority = LOG_INFO;
        }
        elsif($level eq _LOG_DEBUG || $level eq _LOG_VERBOSE) {
            $priority = LOG_DEBUG;
        }
        syslog($priority, $logmsg);
    }

    # Determine if the given log level is enabled.
    # (All non-debug/verbose log levels are always enabled).
    sub _is_log_level_enabled {
        my ($debug, $level) = @_;

        my $is_verbose = $level eq _LOG_VERBOSE;
        my $is_debug = $level eq _LOG_DEBUG;

        if($debug == _DEBUG_LEVEL_NONE && ($is_verbose || $is_debug)) {
            return 0;
        } elsif($debug == _DEBUG_LEVEL_DEBUG && $is_verbose) {
            return 0;
        }

        return 1;
    }

    # Write to the log
    sub _log {
        my ($level, $message) = @_;

        if(!_is_log_level_enabled(HSPV::Config::debug(), $level) ||
            (HSPV::Config::log_type() eq _LOGTYPE_NONE)) {
            # Skip logs if not enabled.
            return;
        }

        use POSIX qw(strftime);
        my $time = strftime "%Y-%m-%d %H:%M:%S", localtime;
        my $tid = threads->tid();
        my $pid = $$;
        my $id = "";
        if(defined $_id) {
            $id = " $_id";
        }
        my $logmsg = "$time [$level] <$pid,$tid>$id: $message";

        if(HSPV::Config::log_type() eq _LOGTYPE_FILE) {
            # Output the message to _LOGFILE.
            _log_to_file($level, $logmsg);
        } elsif(HSPV::Config::log_type() eq _LOGTYPE_PRINT) {
            # Print the message.
            print($logmsg, "\n");
        } else {
            # Output the message to the syslog (default).
            _log_to_syslog($level, $logmsg);
        }
    }

    # Write the function log according to the desired level.
    sub _logf {
        my ($message, $dbg_level) = @_;

        if($dbg_level==_DEBUG_LEVEL_VERBOSE) {
            verbose($message);
        } elsif($dbg_level==_DEBUG_LEVEL_DEBUG) {
            debug($message);
        } else {
            info($message);
        }
    }

    # Create a function logger object that logs on construction and
    # destruction.
    # Note that the caller must save the return value in order for the
    # destructor to not be called immediately.
    sub function {
        my ($class, $dbg_level) = @_;

        if(!defined($dbg_level)) {
            $dbg_level = 0;
        }

        my $self = {
            filename => (caller(0))[1],
            line => (caller(0))[2],
            subroutine => (caller(1))[3],
            debug_level => $dbg_level,
        };

        my $apiver = PVE::Storage::APIVER();
        my $apiage = PVE::Storage::APIAGE();
        my $api = PVE::Storage::Custom::HitachiHSPVPlugin::api();
        my $plugin_version =
            PVE::Storage::Custom::HitachiHSPVPlugin::HSPV_PLUGIN_VERSION();
        #my $filename = (caller(0))[1]; - always same file.
        my $line = (caller(0))[2];
        my $subroutine = (caller(1))[3];
        #_logf("[PVE$apiver] Entering $filename($line): $subroutine().",
        #      $dbg_level);
        _logf("[PVE$apiver|age:$apiage|supported:$api|plugin:$plugin_version" .
              "] Entering ($line): $subroutine().", $dbg_level);

        return bless $self, $class;
    }

    # The Destructor for the function logger.
    sub DESTROY {
        my ($self) = @_;
        #my $filename = $self->{filename}; - always same file.
        my $line = $self->{line};
        my $subroutine = $self->{subroutine};
        my $dbg_level = $self->{debug_level};
        #_logf("Exiting $filename($line): $subroutine().", $dbg_level);
        _logf("Exiting ($line): $subroutine().", $dbg_level);
    }
}

1;
